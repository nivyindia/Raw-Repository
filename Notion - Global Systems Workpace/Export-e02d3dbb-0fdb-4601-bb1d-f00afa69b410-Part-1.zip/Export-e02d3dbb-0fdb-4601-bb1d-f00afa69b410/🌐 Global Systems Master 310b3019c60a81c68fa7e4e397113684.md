# 🌐 Global Systems Master

---

## 🧠 THE ONLY MODEL YOU NEED (MEMORISE THIS)

### **3 QUESTIONS DECIDE EVERYTHING**

For **any document, system, page, or idea**, ask:

1. **WHY does the company exist & what rules never change?**
2. **HOW does the company run repeatedly?**
3. **WHAT is happening today / this week?**

Your answer = where it lives.

---

## 🧱 1️⃣ BUSINESS FOUNDATION → **WHY & RULES**

### **Purpose**

Defines **direction, boundaries, and truth**.

This is the *brain + constitution*.

### **What goes here**

- Business Plan
- Business Model
- Brand Strategy
- Pricing logic
- Partner & client contracts
- Legal documents
- What we do / don’t do

### **Key test**

> “If this changes daily → ❌ NOT here”
> 

### **Example**

- “We only serve Indian MSMEs” → Foundation
- “This month’s campaign” → ❌

---

## ⚙️ 2️⃣ COMPANY OPERATING SYSTEM (COS) → **HOW IT RUNS**

### **Purpose**

Defines **repeatable execution**.

This is the *engine*.

### **What goes here**

- Sales system
- Marketing system
- Delivery system
- Hiring system
- Growth engine
- Automation & data scraping systems
- SOPs
- KPIs
- Tools & workflows

### **Key test**

> “If this can be repeated, automated, or taught → COS”
> 

### **Example**

- “How leads are generated” → COS
- “How onboarding works” → COS
- “Automation for scraping leads” → COS

---

## 🚀 3️⃣ EXECUTION LAYER → **WHAT IS HAPPENING NOW**

### **Purpose**

Tracks **live work only**.

This is the *factory floor*.

### **What goes here**

- Tasks
- Projects
- Live clients
- Campaigns
- Sales pipeline
- Weekly reviews

### **Key test**

> “If this finishes or expires → Execution layer”
> 

### **Example**

- “Client A onboarding” → Execution
- “March campaign” → Execution

---

## 🌐 GLOBAL vs BRAND (ONE SIMPLE RULE)

### **Global**

> “Is this reusable by 2+ brands?”
> 

✔ YES → Global

❌ NO → Brand

### **Brand**

> “Is this specific to one company’s market?”
> 

✔ YES → Brand

❌ NO → Global

---

## 🔁 PUTTING IT TOGETHER (ONE TABLE)

| Item | Where it goes | Why |
| --- | --- | --- |
| Business Plan | Foundation | Direction |
| Partner Contract | Foundation | Legal rule |
| Sales SOP | COS | Repeatable |
| Lead scraping system | COS | Automatable |
| Growth Engine logic | COS | Scalable |
| Client list | Execution | Live |
| Campaign | Execution | Temporary |
| Brand pricing | Brand Foundation | Market-specific |
| Automation framework | Global COS | Reusable |

---

## 🧠 ONE SENTENCE THAT ENDS CONFUSION

> **Foundation decides**
> 
> 
> **COS executes**
> 
> **Execution shows reality**
> 

If you want, next I can:

- Give a **1-page cheat sheet**
- Map **your existing Notion pages into correct buckets**
- Build a **“Where does this go?” decision tree**

Just tell me 👍

GLOBAL WORKSPACE (ONE-TIME SETUP)

GLOBAL ECOSYSTEM
│
├── 00 – Global Business Philosophy
│   ├── Vision & Beliefs
│   ├── Founder Principles
│   ├── Non-Negotiables
│
├── 01 – Global Business Foundation
│   ├── Global Business Plan
│   ├── Global Business Model
│   ├── Brand Creation Rules
│   ├── Pricing Philosophy
│   ├── Risk & Governance
│   ├── Legal Templates (Master)
│   │   ├── Client Contracts
│   │   ├── Partner Agreements
│   │   ├── NDAs
│   │   └── Vendor Contracts
│
├── 02 – Global Company Operating System (COS)
│   ├── 02.1 – Core Systems Map
│   │
│   ├── 02.2 – Growth Engine (Master)
│   │   ├── Acquisition Framework
│   │   ├── Conversion Framework
│   │   ├── Retention & Expansion Logic
│   │   └── Experimentation Rules
│   │
│   ├── 02.3 – Marketing System (Framework)
│   ├── 02.4 – Sales System (Framework)
│   ├── 02.5 – Delivery System (Framework)
│   ├── 02.6 – People System (Framework)
│   ├── 02.7 – Partner System (Framework)
│   ├── 02.8 – Finance & Control System
│   ├── 02.9 – Legal & Compliance System (Process)
│   ├── 02.10 – Data & Analytics System
│   ├── 02.11 – Technology & Tool Stack
│   ├── 02.12 – Automation Architecture
│   │   ├── Automation Rules
│   │   ├── n8n Workflows
│   │   ├── Python Scripts
│   │   └── API Integrations
│   │
│   ├── 02.13 – Data Collection & Scraping Systems
│   │   ├── Web Scraping Framework
│   │   ├── Directory Mining
│   │   ├── Social Data Extraction
│   │   ├── Data Cleaning & Enrichment
│   │   └── Data Storage Rules
│   │
│   ├── 02.14 – SOP Templates (Blank)
│   ├── 02.15 – KPI & Metrics Definitions
│   └── 02.16 – Tool Governance & Access Rules
│
└── 03 – Global Templates & Assets
├── SOP Templates
├── Proposal Templates
├── Email Scripts
├── Automation Snippets
├── Dashboard Templates
└── Brand Asset Kits

NIVY EMPIRES – GLOBAL SYSTEM
│
├── 01_GLOBAL_CONTROL_CENTER
│   ├── Group Vision & Mission
│   ├── Empire Roadmap (5–10 Years)
│   ├── Active Brands Dashboard
│   ├── Global KPIs & Scorecards
│   ├── Capital Allocation Overview
│   ├── Risk & Critical Issues Log
│   └── Founder / Board Review Notes
│
├── 02_GLOBAL_BUSINESS_FOUNDATION
│   ├── Group Business Philosophy
│   ├── Brand Creation Criteria
│   ├── Brand Exit / Kill Framework
│   ├── Market Expansion Logic
│   ├── Standard Business Models Library
│   ├── Pricing & Profitability Principles
│   └── Growth Engine Blueprint
│
├── 03_GLOBAL_COMPANY_OPERATING_SYSTEM (GCOS)
│   │
│   ├── 00_GCOS_MASTER_MAP
│   │   ├── System Registry (Defined / Active / Dormant)
│   │   ├── Activation Rules & Triggers
│   │   └── Review & Governance Rules
│   │
│   ├── 01_REVENUE_SYSTEMS
│   │   ├── Lead Generation System (Master Framework)
│   │   ├── Sales Conversion System (Master Framework)
│   │   ├── Upsell & Retainer System (Master Framework)
│   │   └── Growth Engine Integration (Global Funnel)
│   │
│   ├── 02_MARKETING_SYSTEMS
│   │   ├── Brand Messaging Framework
│   │   ├── Content System Blueprint
│   │   ├── Campaign System Blueprint
│   │   ├── Distribution Channels Playbook
│   │   └── Growth Engine Marketing Channels
│   │
│   ├── 03_DELIVERY_SYSTEMS
│   │   ├── Client Onboarding System
│   │   ├── Service Delivery Standards
│   │   ├── Quality Control System
│   │   └── Client Support & Escalation
│   │
│   ├── 04_PEOPLE_SYSTEMS
│   │   ├── Org Structure & Role Levels
│   │   ├── Hiring & Onboarding System
│   │   ├── Training & Certification System
│   │   ├── Performance Review Framework
│   │   └── Incentive & Commission Logic
│   │
│   ├── 05_PARTNER_SYSTEMS
│   │   ├── Partner Types & Tiering
│   │   ├── Partner Acquisition System
│   │   ├── Partner Onboarding System
│   │   ├── Partner Payout Logic
│   │   └── Partner Dispute Resolution
│   │
│   ├── 06_FINANCE_CONTROL_SYSTEMS
│   │   ├── Accounting Standards
│   │   ├── Budgeting & Forecasting
│   │   ├── Approval Authority Matrix
│   │   ├── Inter-Brand Transactions
│   │   └── Financial Reporting Templates
│   │
│   ├── 07_LEGAL_COMPLIANCE_SYSTEMS
│   │   ├── Compliance Calendar Framework
│   │   ├── Risk Management System
│   │   ├── Audit & Review SOPs
│   │   └── Regulatory Monitoring
│   │
│   ├── 08_DATA_ANALYTICS_SYSTEMS
│   │   ├── KPI Definitions Library
│   │   ├── Dashboard Templates
│   │   ├── Reporting Cadence
│   │   └── Data Quality Rules
│   │
│   ├── 09_TECHNOLOGY_AUTOMATION
│   │   ├── Approved Tool Stack
│   │   ├── Automation Blueprints
│   │   ├── Integration Rules
│   │   └── Data Backup & Security
│   │
│   ├── 10_GOVERNANCE_DECISION_SYSTEMS
│   │   ├── Decision Rights Matrix
│   │   ├── Escalation Framework
│   │   ├── Crisis & Contingency Plans
│   │   └── Exception Handling Rules
│   │
│   ├── 11_CULTURE_LEADERSHIP_SYSTEMS
│   │   ├── Core Values & Behaviors
│   │   ├── Leadership Playbooks
│   │   ├── Communication Etiquette
│   │   └── Recognition & Rewards
│   │
│   ├── 12_INNOVATION_EVOLUTION_SYSTEMS
│   │   ├── Market & Trend Scanning
│   │   ├── Experimentation Framework
│   │   ├── New Brand Launch SOP
│   │   └── Scale & Replication Playbook
│   │
│   └── 13_SECURITY_ACCESS_SYSTEMS
│       ├── Access Control Policy
│       ├── Password & Asset Ownership
│       ├── Offboarding & Exit SOP
│       └── IP Protection Rules
│
├── 04_GLOBAL_LEGAL_VAULT (LOCKED)
│   ├── Holding Company Documents
│   ├── Master NDA Templates
│   ├── Partner Agreement Templates
│   ├── Client Contract Templates
│   ├── Vendor Agreement Templates
│   └── IP Ownership & Licensing Docs
│
├── 05_GLOBAL_FINANCE_CONTROL
│   ├── Group Budgets
│   ├── Investment & Capital Allocation
│   ├── Cost Control Rules
│   ├── Profit Distribution Logic
│   └── Audit & Compliance Reports
│
├── 06_GLOBAL_PEOPLE_HUB
│   ├── Role Definitions & Levels
│   ├── Compensation Bands
│   ├── Hiring Scorecards
│   ├── Performance Benchmarks
│   └── Freelancer & Partner Tiering
│
├── 07_GLOBAL_TECH_STACK
│   ├── Notion Architecture Standards
│   ├── CRM & ERP Rules
│   ├── Automation Tools (Zapier/Make)
│   ├── Communication Tools
│   └── Backup & Security Standards
│
├── 08_GLOBAL_KNOWLEDGE_LIBRARY
│   ├── Best Practices (Cross-Brand)
│   ├── Lessons Learned
│   ├── Failure & Recovery Logs
│   ├── Training Material
│   └── Playbooks & SOP Archives
│
└── 09_GLOBAL_REVIEW_AUDIT
├── Quarterly Reviews
├── Brand Health Scorecards
├── Compliance Audits
└── Founder / Board Notes

TECHNOLOGY & AUTOMATION
│
├── 01_AUTOMATION_ARCHITECTURE
│   ├── Automation Philosophy (What to automate / What not)
│   ├── Tool Stack (Open-source first)
│   ├── Security & Ethics Rules
│   └── Automation Approval Process
│
├── 🤖 02_DATA_COLLECTION_ENGINE (AUTOMATED)
│   ├── Lead Data Sources Registry
│   │   ├── Websites
│   │   ├── Directories
│   │   ├── Marketplaces
│   │   ├── Social Platforms
│   │   └── APIs
│   │
│   ├── Web Scraping Framework
│   │   ├── Scraping SOP
│   │   ├── Robots.txt Rules
│   │   ├── Rate Limits
│   │   └── IP / Proxy Strategy
│   │
│   ├── Scraper Templates
│   │   ├── Static Websites
│   │   ├── Dynamic Websites
│   │   ├── Form-based Sites
│   │   └── Paginated Data
│   │
│   └── Data Ingestion Pipelines
│       ├── Raw Data Storage
│       ├── Cleaned Data Storage
│       └── Error Logs
│
├── 🤖 03_DATA_CLEANING_ENRICHMENT (AUTOMATED)
│   ├── Duplicate Removal Logic
│   ├── Email / Phone Validation
│   ├── Geo / Industry Tagging
│   ├── Company Size Estimation
│   └── Data Quality Scoring
│
├── 🤖 04_DATA_STORAGE_SYSTEM (AUTOMATED)
│   ├── Master Lead Database
│   ├── Brand-wise Views
│   ├── Partner-wise Views
│   ├── Permission Controls
│   └── Backup & Versioning
│
├── 🤖 05_OUTREACH_AUTOMATION_ENGINE
│   ├── Email Sending Logic
│   ├── Follow-up Sequences
│   ├── Throttling Rules
│   ├── Inbox Rotation Rules
│   └── Bounce / Reply Tracking
│
├── 🤖 06_TASK_PROCESS_AUTOMATION
│   ├── Auto Task Creation
│   ├── SLA Breach Alerts
│   ├── Auto Assignments
│   └── Escalation Rules
│
├── 🤖 07_REPORTING_ANALYTICS_AUTOMATION
│   ├── Daily Reports
│   ├── Weekly Summaries
│   ├── Funnel Analytics
│   └── Performance Alerts
│
└── 08_AUTOMATION_LIBRARY
├── Reusable Scripts
├── n8n Workflows
├── Python Scripts
├── API Integrations
└── Cron Jobs

### Explanation of Each Section:

1. **Global Control Center**
    
    This is the top-level CEO dashboard for the entire empire. It keeps track of the big picture—vision, KPIs, capital distribution, active brands, and critical risks. This is your strategic command center.
    
2. **Global Business Foundation**
    
    The core "why" of the empire. It houses the business philosophy, rules for brand creation and exit, and the overarching growth engine blueprint. It sets the foundation for how every brand is created, scaled, or shut down.
    
3. **Global Company Operating System (GCOS)**
    
    This is the "how" layer. All systems (revenue, marketing, delivery, finance, people, legal, etc.) live here. Each system is defined globally with master frameworks, templates, and SOPs. Brands will inherit these, customize them as needed, and execute on them. The Growth Engine fits naturally inside this structure—especially in revenue and marketing systems—because it provides a repeatable model for scaling across brands.
    
4. **Global Legal Vault (Locked)**
    
    This is your legally sensitive library—templates, contracts, NDAs, agreements, and IP documents. These don’t change unless law or global policy changes. Brands inherit templates but don’t modify core legal language.
    
5. **Global Finance Control**
    
    The financial backbone of the empire—budgeting, investment logic, profit distribution, and capital allocation rules. It ensures financial consistency across brands and sets benchmarks for all finance functions.
    
6. **Global People Hub**
    
    Role definitions, compensation frameworks, hiring scorecards, and performance benchmarks live here. This ensures that no matter the brand, the organization structure and people management standards remain consistent.
    
7. **Global Tech Stack**
    
    The global approved toolset (CRM, automation platforms like Zapier, security, data backups). This ensures consistency in tools, integrations, and how technology drives efficiency and automation across the brands.
    
8. **Global Knowledge Library**
    
    This is the cross-brand learning and best practice repository. It houses lessons learned, failure logs, playbooks, and SOPs that span all brands. This is your knowledge capital—ensuring all brands share insights and avoid repeating mistakes.
    
9. **Global Review & Audit**
    
    Regular reviews—quarterly, annual—of brand health, financial audits, compliance, and board-level discussions. These ensure you’re always aligned with the empire’s goals, and any risks or opportunities are caught early.
    

---

### Growth Engine Integration:

Growth Engine fits naturally inside the Global Business Foundation and Global COS. Here’s why:

- In **Global Business Foundation**, you define the overarching blueprint for how you plan to grow (e.g., market expansion logic, growth playbooks, customer acquisition models).
- In **Global COS (Revenue and Marketing Systems)**, you integrate the actual growth tactics: lead generation systems, marketing campaigns, performance tracking, and funnel metrics. This ensures each brand has a global growth template that they adapt to their own market, but all brands are following the same scalable engine.

---

### How Brands Fit Into This Structure

Each brand workspace will mirror this structure but be more granular:

- Each brand inherits from the Global COS.
- The brand-specific business foundation will define its vision, market, and offerings.
- The brand will activate specific systems from the GCOS (e.g., the lead generation system, marketing campaigns) but only customize what is unique to them.
- Legal, finance, and people rules come from the global system; brand layers focus on execution (e.g., specific campaigns, client projects, and day-to-day operations).

### Explanation of Each Section:

1. **Global Control Center**
    
    This is the top-level CEO dashboard for the entire empire. It keeps track of the big picture—vision, KPIs, capital distribution, active brands, and critical risks. This is your strategic command center.
    
2. **Global Business Foundation**
    
    The core "why" of the empire. It houses the business philosophy, rules for brand creation and exit, and the overarching growth engine blueprint. It sets the foundation for how every brand is created, scaled, or shut down.
    
3. **Global Company Operating System (GCOS)**
    
    This is the "how" layer. All systems (revenue, marketing, delivery, finance, people, legal, etc.) live here. Each system is defined globally with master frameworks, templates, and SOPs. Brands will inherit these, customize them as needed, and execute on them. The Growth Engine fits naturally inside this structure—especially in revenue and marketing systems—because it provides a repeatable model for scaling across brands.
    
4. **Global Legal Vault (Locked)**
    
    This is your legally sensitive library—templates, contracts, NDAs, agreements, and IP documents. These don’t change unless law or global policy changes. Brands inherit templates but don’t modify core legal language.
    
5. **Global Finance Control**
    
    The financial backbone of the empire—budgeting, investment logic, profit distribution, and capital allocation rules. It ensures financial consistency across brands and sets benchmarks for all finance functions.
    
6. **Global People Hub**
    
    Role definitions, compensation frameworks, hiring scorecards, and performance benchmarks live here. This ensures that no matter the brand, the organization structure and people management standards remain consistent.
    
7. **Global Tech Stack**
    
    The global approved toolset (CRM, automation platforms like Zapier, security, data backups). This ensures consistency in tools, integrations, and how technology drives efficiency and automation across the brands.
    
8. **Global Knowledge Library**
    
    This is the cross-brand learning and best practice repository. It houses lessons learned, failure logs, playbooks, and SOPs that span all brands. This is your knowledge capital—ensuring all brands share insights and avoid repeating mistakes.
    
9. **Global Review & Audit**
    
    Regular reviews—quarterly, annual—of brand health, financial audits, compliance, and board-level discussions. These ensure you’re always aligned with the empire’s goals, and any risks or opportunities are caught early.
    

---

### Growth Engine Integration:

Growth Engine fits naturally inside the Global Business Foundation and Global COS. Here’s why:

- In **Global Business Foundation**, you define the overarching blueprint for how you plan to grow (e.g., market expansion logic, growth playbooks, customer acquisition models).
- In **Global COS (Revenue and Marketing Systems)**, you integrate the actual growth tactics: lead generation systems, marketing campaigns, performance tracking, and funnel metrics. This ensures each brand has a global growth template that they adapt to their own market, but all brands are following the same scalable engine.

---

### How Brands Fit Into This Structure

Each brand workspace will mirror this structure but be more granular:

- Each brand inherits from the Global COS.
- The brand-specific business foundation will define its vision, market, and offerings.
- The brand will activate specific systems from the GCOS (e.g., the lead generation system, marketing campaigns) but only customize what is unique to them.
- Legal, finance, and people rules come from the global system; brand layers focus on execution (e.g., specific campaigns, client projects, and day-to-day operations).

[🏷️ Brand Systems Framework](%F0%9F%8F%B7%EF%B8%8F%20Brand%20Systems%20Framework%20310b3019c60a81fea81af212babc415b.md)

[Final Systems](Final%20Systems%20310b3019c60a8172b142e51c5e527940.md)

[🏛️ 01 — Business Foundation](%F0%9F%8F%9B%EF%B8%8F%2001%20%E2%80%94%20Business%20Foundation%20335b3019c60a8154957fe1780e373ef2.md)

[⚙️ 02 — Company Operating System (COS)](%E2%9A%99%EF%B8%8F%2002%20%E2%80%94%20Company%20Operating%20System%20(COS)%20335b3019c60a81028acfc04a2ea48125.md)

[📣 03 — Sales, Marketing & Growth](%F0%9F%93%A3%2003%20%E2%80%94%20Sales,%20Marketing%20&%20Growth%20335b3019c60a81dcab2fe553b1416056.md)

[🎓 04 — VA Department & Training](%F0%9F%8E%93%2004%20%E2%80%94%20VA%20Department%20&%20Training%20335b3019c60a810884f6d0f40f02426f.md)

[🔥 05 — Execution & Live Work](%F0%9F%94%A5%2005%20%E2%80%94%20Execution%20&%20Live%20Work%20335b3019c60a81cb8495c6f811f392da.md)