# Layla Summer

Action Required: Build All Platforms
Assigned VA: Unassigned
FB Status: ❌ Missing
ID: P036
IG Status: ❌ Missing
Issue Summary: Not built.
LinkedIn Status: ❌ Missing
Location: Gold Coast, Queensland
Overall Status: 🔴 Empty
Priority: 🟠 High
Recovery Email: nivyindia@gmail.com
Region: 🇦🇺 Australia
X Status: ❌ Missing