# Create PeoplePerHour profile

Deadline: June 23, 2026
KPI / Target: Live, complete profile
Owner: You (Founder)
Phase: Phase 0 - Setup
Priority: P1 - High
Start Date: June 22, 2026
Status: 🔴 Pending