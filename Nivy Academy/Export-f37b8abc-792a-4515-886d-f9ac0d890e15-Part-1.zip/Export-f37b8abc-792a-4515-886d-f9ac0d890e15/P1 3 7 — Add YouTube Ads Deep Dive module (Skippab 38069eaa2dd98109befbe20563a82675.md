# P1.3.7 — Add YouTube Ads Deep Dive module (Skippable, Non-skippable, Bumper, Masthead, In-feed ads, targeting strategy)

Module: P1.3 PPC
Owner: PPC Faculty
Phase: 1
Phase Name: Depth Enhancement — Existing Courses
Priority: Medium
Source Page: https://app.notion.com/p/37f69eaa2dd980a299bec10b7737ff4d
Status: 🔴 Pending
Target Date: July 24, 2026
Task ID: P1.3.7
Wave: Wave 1