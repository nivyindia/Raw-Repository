# Billion Dreams United — AI Company OS
## Repo Skeleton (Stage A.1)

**Step:** A.1
**Deliverable:** Folder structure committed
**Depends on:** —
**Status:** ✅ Done

This is the empty folder skeleton for the full implementation repository, as defined in
`Billion-Dreams-United-Implementation-Plan-v2-Granular-Steps.md` (Stage A) and
`Missing-Layers-Review.md` (Phase 1 — Master Registries / Final Control Repository).

Every folder currently contains only a `.gitkeep` placeholder (or subfolders) —
**no content has been created yet**. Per the project rule:

> Ek step tabhi "done" mana jayega jab uska actual file/artifact exist kare.

A.1's actual artifact is this committed folder structure — nothing more.

---

## Folder Map

| Folder | Purpose | Filled in Stage |
|---|---|---|
| `00-governance/` | Master index, completion matrix, ADRs, build rules, change mgmt | A |
| `01-company/` | Business model, brands, departments, services, ICP, KPIs | A/B |
| `02-agents/` | Agent registry + per-department agent definitions (A001–A087) | C, F |
| `03-skills/` | Reusable skill library | C |
| `04-tools/` | Tool registry + tool wrappers (Odoo, GitHub, email, browser...) | C |
| `05-workflows/` | n8n / LangGraph / Dify workflow specs | C, G |
| `06-data/` | Canonical data model, state machines, event schemas | B |
| `07-policies/` | Permission matrix, risk policy, approval specs, IAM baseline | D |
| `08-evaluation/` | Golden datasets, test cases, regression, results | H |
| `09-observability/` | Logging, metrics, tracing, alerting, dashboards | I |
| `10-infrastructure/` | Docker/compose, dev/staging/prod envs, backups, DR | E |
| `11-integrations/` | External system integration configs | E, G |
| `12–18` | Sales / Marketing / Delivery / CS / Finance / HR / Legal engines | F, K |
| `19-testing/` | Cross-system test suites | H |
| `20-runbooks/` | Operational runbooks | I |
| `21-incidents/` | Incident logs + postmortems | I |
| `99-docs/` | General documentation | ongoing |

---

## Next step

**A.2** — Extract every existing ID (87 agents + 48 WF + 26 MW + 15 XW = 176 items)
into a single CSV/YAML list, ID + name only → `id-master-list.yaml`.
