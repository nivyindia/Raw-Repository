# Batch 1 — Files to Replace

17 files total, all inside the `Growth-Engine/` folder in this zip, mirroring your existing repo structure exactly. Drop `Growth-Engine/` on top of your existing `Growth-Engine/` folder and overwrite when prompted — every path below already matches where the file lives today.

## 1. Index file (§0 reference collection added)
- `Growth-Engine/Sales Funnel/N8N-AUTOMATION-INDEX.md`
  → replaces `Sales Funnel/N8N-AUTOMATION-INDEX.md`
  → ⚠️ **See note below — `nivyindia/all_n8n_templates_collection` doesn't appear to exist.**

## 2. Sales Funnel stage `automation.md` files (11 stages)
- `Growth-Engine/Sales Funnel/06 Lead Extraction/automation.md`
- `Growth-Engine/Sales Funnel/08 Lead Enrichment/automation.md`
- `Growth-Engine/Sales Funnel/13 CRM Setup and Data Structuring/automation.md`
- `Growth-Engine/Sales Funnel/16 Email Outreach/automation.md`
- `Growth-Engine/Sales Funnel/19 WhatsApp Outreach/automation.md`
- `Growth-Engine/Sales Funnel/25 Reply Handling and Triage/automation.md`
- `Growth-Engine/Sales Funnel/33 Proposal Creation/automation.md`
- `Growth-Engine/Sales Funnel/39 Payment and Invoicing/automation.md`
- `Growth-Engine/Sales Funnel/40 Client Onboarding/automation.md`
- `Growth-Engine/Sales Funnel/46 Support and Issue Resolution/automation.md`
- `Growth-Engine/Sales Funnel/51 Customer Feedback and NPS/automation.md`

Each replaces the `automation.md` already sitting in that same stage folder.

## 3. Marketing module `automation.md` files (5 modules)
- `Growth-Engine/Marketing/M09 Long-Form Content Production/automation.md`
- `Growth-Engine/Marketing/M10 Content Repurposing and Distribution Engine/automation.md`
- `Growth-Engine/Marketing/M11 LinkedIn Organic Engine/automation.md`
- `Growth-Engine/Marketing/M17 Email Newsletter and Lead Nurture/automation.md`
- `Growth-Engine/Marketing/M20 Partnerships, Co-Marketing and PR/automation.md`

Each replaces the `automation.md` already sitting in that same module folder. (Note: M20's is still the 8-line placeholder stub — Batch 0/5 haven't been run yet — so I added the template line inside the existing stub rather than writing the full module.)

---

## What actually got added, per the plan's own checklist

| Stage/Module | Template(s) added | Verified live? |
|---|---|---|
| Sales 06/08 | Qualify new leads in Google Sheets via OpenAI's GPT-4 | ✅ n8n.io, fetched and confirmed |
| Sales 13 | Chat with Postgresql Database + Generate SQL queries from schema only | ✅ both n8n.io, confirmed |
| Sales 16 | LeadPilot Lite – AI Cold Email Writer | ✅ GitHub source confirmed |
| Sales 19 | WhatsApp category (Evolution API pattern) | ⚠️ No single stable template found — linked category browse instead, same fallback the index itself already prescribes |
| Sales 25 | Auto-label incoming Gmail messages / InboxZero Lite | ✅ both confirmed |
| Sales 33 | Invoice data extraction with LlamaParse and OpenAI | ✅ confirmed (linked as an adapted pattern, not a drop-in — noted in the file) |
| Sales 39 | Airtable to Google Sheets Auto-Sync + Stripe/Odoo pattern | ⚠️ No single stable template under that name — linked category browse + the index's existing Stripe/QuickBooks reference instead |
| Sales 40 | Streamline Client Onboarding with PDF, Trello, Slack, Gmail and Airtable | ✅ n8n.io, fetched and confirmed — exact title match |
| Sales 46 | Customer Support Channel and Ticketing (Slack+Linear) / Sentiment Analysis Tracking | ✅ both confirmed |
| Sales 51 | Add positive feedback messages to a table in Notion | ✅ confirmed |
| Marketing M09/M10 | Automate Blog Creation in Brand Voice with AI / Write a WordPress post with AI | ✅ both confirmed |
| Marketing M11 | AI-Powered Social Media Amplifier | ✅ confirmed |
| Marketing M17 | Daily Email Notification (Ollama digest) | ⚠️ Not found under that name — closest match is an **unmerged** GitHub PR (#107) as of this pass. Linked the Ollama integration page instead and flagged the PR to re-check later. |
| Marketing M20 | Automate Competitor Research with Exa.ai, Notion and AI Agents | ✅ confirmed |

**11 of 14 lines got a real, checked, clickable link. 3 (Sales 19, Sales 39, Marketing M17) didn't resolve to one stable named template** — rather than invent a URL, I used the exact fallback the index already documents ("if a direct link 404s, use the category link") and said so plainly in each file.

## One thing you should decide before this goes further

The plan's Batch 1 task list says to add `nivyindia/all_n8n_templates_collection` to the index as your curated second source. **I searched for that repo and it doesn't appear to exist publicly on GitHub.** All 11 of the confirmed links above that came from "the collection" actually resolve to **`enescingoz/awesome-n8n-templates`** (280+ templates, the real repo those specific files live in) — that's what I linked in the index instead, with a note explaining the swap. If `nivyindia/...` is a private fork of that repo, or was renamed, just update that one line in the index — nothing else depends on the exact repo name.
