# M20 — Partnerships, Co-Marketing and PR: Automation

**Phase:** G — Community & Partners
**Status:** 🟡 Skeleton — not yet built to pilot depth.

This file is a placeholder. Content for **automation.md** has not been written yet — see the top-level `IMPLEMENTATION-PLAN.md` §4 (Build Order & Batching Strategy) for when this stage is scheduled to be built, and §5 for the per-stage build checklist this file will be filled against.

**n8n template(s) (pre-loaded ahead of full build-out):** [Automate Competitor Research with Exa.ai, Notion and AI Agents](https://github.com/enescingoz/awesome-n8n-templates/blob/main/Notion/Automate%20Competitor%20Research%20with%20Exa.ai,%20Notion%20and%20AI%20Agents.json) — builds a research agent that finds similar companies via Exa.ai, has AI agents compile overviews/offerings/reviews, and writes the report into a Notion table; the closest real match for this stage's partner/co-marketing prospect research once it's built out. Verified 23 Jul 2026.

No fabricated tool claims, invented case studies, or invented metrics will be added here — where existing Growth Engine raw material covers this stage, it will be mined and cited; where it doesn't, this will be written fresh and marked as such.
