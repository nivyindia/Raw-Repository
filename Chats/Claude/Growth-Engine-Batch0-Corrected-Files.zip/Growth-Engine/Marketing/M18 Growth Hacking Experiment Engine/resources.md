# M18 — Resources

## Tactic Bank (Mined from Existing Growth Hacking Master List)

This is the full tactic bank mined from your existing internal "Growth Hacking Master List (100+ Tactics)" doc (Section SD-06), carried over category-by-category rather than re-invented. Each tactic still needs to be scored (Impact × Effort) and hypothesis-framed per `methods.md`/`templates.md` before it's run — this list is the idea bank, not a pre-approved queue.

### LinkedIn Growth Tactics

Post a controversial opinion in your niche; share an "I wish someone told me this" list; write a carousel on a common mistake your ICP makes; post a before/after client result; comment on 10 posts by ideal clients daily; send 20 personalized connection requests daily; publish a LinkedIn article for SEO value; run a poll on a hot topic; tag clients/partners in milestone posts; post behind-the-scenes content; share a stat with a hot take; create a "day in the life" reel; run a monthly LinkedIn Live Q&A; feature a client spotlight; repost a client win with commentary; write a "10 things I learned" post; ask a question your ICP is Googling; post a system/framework as a visual; write about a failure and the lesson; build a niche resource list.

### Email & Outbound Tactics

A/B test two subject lines per campaign; add a P.S. with a lead magnet link to every cold email; send a break-up email to cold leads at day 14; re-engage cold leads with a new angle every 90 days; send a no-CTA "value bomb" email; use Loom video in outreach to top prospects; run a 5-day email challenge; segment the list by ICP for tailored sequences; send a monthly case-study email to warm leads; use WhatsApp voice notes for warm prospects; follow up every proposal within 48 hours; send a "one year from now" visioning email to cold leads; send a monthly "results roundup" email; personalize email openers using AI (recent post, news); test plain text vs. formatted emails.

### Content & SEO Tactics

Repurpose every blog article into 5 LinkedIn posts (overlaps M10); turn LinkedIn posts into newsletter content (overlaps M10/M17); answer 5 Quora questions weekly with a link back to the blog; create and share a free Notion template; publish an "Ultimate Guide" to a core service (overlaps M09); build a long-tail FAQ page; write guest posts on DA 30+ blogs (overlaps M07); create a YouTube Short from every LinkedIn post (overlaps M13); build a public resource hub; publish an annual "State of [industry]" report; build a comparison page (brand vs. alternatives); build a glossary page targeting definition keywords; run a podcast tour (pitch 5 shows/month, overlaps M20); syndicate blog content to Medium/LinkedIn Articles; create a "swipe file" resource for the ICP.

### Community & Network Tactics

Join 5 relevant Facebook Groups; engage authentically for 30 days before pitching; host a free monthly webinar; create a WhatsApp community for the ICP (overlaps M19); attend one virtual networking event monthly; partner with complementary providers (overlaps M20); build a referral network from past clients (overlaps M20); request LinkedIn recommendations from every client; feature partners in content so they reshare it; sponsor or speak at niche events; start a Slack/Discord community (overlaps M19); participate in Twitter/X Spaces; build relationships with podcast hosts before pitching; offer free audits to community members as a top-of-funnel hook; create a free accountability group for the ICP.

### Automation & Leverage Tactics

Auto-share new blog posts to LinkedIn via n8n; automated welcome email for every new subscriber; auto-tag CRM leads by source using form UTMs; a website chatbot capturing leads 24/7; auto-send a review request 30 days after onboarding; a re-engagement automation for 90-day cold leads; auto-notify the team when a new form lead arrives; push WhatsApp leads into the CRM via n8n; a LinkedIn auto-post scheduler; automated monthly reporting dashboards; deal-stage notifications in the CRM; auto-assign leads to sequences by ICP type; abandoned-booking recovery (email if a Calendly slot isn't completed); a client check-in automation at day 7/30/60; auto-create a task when a new client is won.

### Partnership & Collaboration Tactics

Partner with web design agencies whose clients need this service; partner with accountants/CFOs serving the same SMEs; partner with business coaches whose clients match the ICP; offer co-branded lead magnets with partners; run a joint webinar with a complementary provider; build a white-label offering for agencies; approach HR/recruitment firms for referrals; build relationships with coworking spaces; partner with SaaS tools serving the same ICP for co-marketing; build a partner directory with mutual linking (overlaps M20 in full — see M20 for the deeper partnership process).

### Paid & Distribution Tactics

Run LinkedIn Lead Gen retargeting ads to warm audiences; boost top-performing LinkedIn posts ($10–30/post); run Google Ads on high-intent keywords; run a retargeting pixel campaign for website visitors; sponsor a relevant niche newsletter; list on directories like Clutch/GoodFirms/DesignRush (free and paid tiers); run a limited-time offer campaign; test Facebook/Instagram ads to founder audiences; pay for a feature in a founder-focused newsletter; run a referral contest.

## Internal Cross-References

- `IMPLEMENTATION-PLAN.md` (repo root) — shared free/OSS tool stack, standing QC rules
- Existing internal "Growth Hacking Master List (100+ Tactics)" doc, Section SD-06 — the source this tactic bank is mined from in full
- M09–M17 — the execution home for any tactic once it graduates from experiment to standing practice
- M19 — Community Building; tactics tagged "overlaps M19" above are sourced here but built out in that stage
- M20 — Partnerships, Co-Marketing & PR; tactics tagged "overlaps M20" above are sourced here but built out in that stage

## Further Reading (General, Not Tool-Specific)

- Standard Impact × Effort / ICE (Impact, Confidence, Ease) prioritization frameworks — the scoring method above is a two-factor variant of this common growth/product prioritization approach.
