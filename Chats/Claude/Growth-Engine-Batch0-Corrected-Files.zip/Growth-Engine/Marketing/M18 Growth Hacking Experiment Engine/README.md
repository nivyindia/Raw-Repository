# M18 — Growth Hacking Experiment Engine

**Phase:** F — Growth Experiments
**Status:** ✅ Built to pilot depth (2026-07-23)
**Feeds from:** M09–M17 (every content/channel stage is a source of tactics to test) and M04–M07 (SEO tactics)
**Feeds into:** M21 (Marketing Analytics & Reporting) — every experiment's result is a reporting input; winning tactics get folded back into the relevant M09–M17 stage's `methods.md` as a standing practice

---

## 1. What This Stage Covers

M18 is not a channel — it's the **testing discipline that sits across every other Track M stage**. Where M11 (LinkedIn) or M17 (Email) each own a channel's day-to-day execution, M18 owns the process of picking which new tactic to try next, running it as a bounded experiment, scoring the result, and deciding whether it graduates into a standing practice (folded back into that channel's own `methods.md`) or gets killed.

This stage exists because a 150+ tactic idea bank (mined from your existing Growth Hacking Master List) is only useful with a forcing function around it — otherwise it's a list nobody works through. M18 is that forcing function: the Impact × Effort scoring method, the monthly tactic-selection cadence, and the Experiment Tracker that turns "try some growth hacks" into a repeatable system.

## 2. Sub-Stages

1. **Tactic sourcing** — pull candidate tactics from the master list (see `resources.md`) or propose new ones.
2. **Scoring & selection** — score each candidate Impact (1–5) × Effort (1–5); pick 3–5 per month per the source doc's own cadence.
3. **Hypothesis framing** — write each selected tactic as a testable hypothesis with a defined success metric before running it.
4. **Execution** — run the tactic for a fixed window (see `checklists.md` for the 30-day default).
5. **Measurement** — log the result in the Experiment Tracker (`templates.md`).
6. **Decision** — scale (fold into the owning channel stage), iterate (adjust and re-test), or kill.
7. **Handoff** — scaled tactics get written into the relevant M09–M17 stage as a standing method; killed tactics stay logged as a record of what didn't work, so it isn't re-tested blind in six months.

## 3. Relationship to the Channel Stages (M09–M17)

M18 does not duplicate channel-specific execution detail already owned elsewhere:

- LinkedIn-specific tactics (post types, connection cadence) are sourced here but *executed* per M11's own playbook once they graduate.
- Email tactics (subject line testing, break-up sequences) are sourced here but *executed* per M17.
- Content/SEO tactics (repurposing angles, guest posts) are sourced here but *executed* per M09/M10/M07.

M18's own files stay focused on the **scoring, testing, and decision framework** — not on how to write a LinkedIn post or send an email, which those stages already cover.

## 4. Cross-References

- **Growth Hacking Master List (100+ Tactics)** — the existing internal doc this stage's tactic bank is mined from (see `resources.md` for full attribution)
- **M09–M17** — every channel/content stage is both a source of tactics and the eventual home for anything that graduates from experiment to standing practice
- **M04–M07** — SEO-specific tactics in the master list map to this range
- **M19** — Community Building; several growth-hacking tactics (group seeding, ambassador loops) overlap with community mechanics and are cross-referenced rather than duplicated
- **M20** — Partnerships; the master list's partnership tactics are sourced here but executed per M20's own process
- **M21** — Marketing Analytics & Reporting; the Experiment Tracker is a direct reporting input once M21 is built
- **Sales Funnel** — no direct stage feed; graduated tactics reach Sales Funnel Stage 06 only indirectly, through whichever M09–M17 stage they get folded into

## 5. What's Not Built Yet

This stage covers the 9 standard files to pilot depth. The Experiment Tracker in `templates.md` is a reusable structure, not a populated log — real experiment rows get added once tactics are actually run against a live channel. The tactic bank in `resources.md` is mined in full from your existing Growth Hacking Master List; no new tactics were invented to pad the count.
