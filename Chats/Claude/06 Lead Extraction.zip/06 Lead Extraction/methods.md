# Stage 06 — Methods

Coverage: traditional, modern, AI-assisted, manual, automated, API-based, browser-automation, scraping, public-database, government, and community/referral extraction methods.

## 1. Traditional / Manual

- **Manual directory browsing** — industry association member directories, chamber-of-commerce listings, trade-show exhibitor lists. Slow but very high ICP-match rate since these lists are usually already curated.
- **LinkedIn manual search + copy-paste** — searching by title/industry/geography and manually noting company + contact name. No automation risk, but low throughput (~20–40 rows/hour).

## 2. Semi-Automated

- **CSV export from B2B databases** (Apollo, ZoomInfo, Lusha) — apply filters in-platform, export directly. This is the primary method for most batches: fast, ToS-compliant, and already includes firmographic fields.
- **Sales Navigator list export via approved connectors** (e.g. via CRM integrations rather than raw scraping) — safer than scripted scraping of the LinkedIn UI.

## 3. API-Based

- **Apollo.io API** / **Hunter.io Domain Search API** — programmatic pulls filtered by industry/size/geography, useful when a campaign needs recurring, scheduled extraction rather than a one-off export.
- **Government/trade registry APIs** where available (e.g. company registries that expose open-data APIs) — high trust, zero cost, but coverage varies heavily by country.

## 4. Browser Automation

- Tools like Phantombuster or similar can automate LinkedIn search-result scraping. **Use with caution** — this is the method most likely to trigger platform bans; always run at low volume/session with randomized delays, and prefer official export paths (Sales Navigator's own list-export feature) wherever one exists.

## 5. Web Scraping (General)

- Directory and marketplace scraping (e.g. Yellow Pages-style directories, sector-specific marketplaces) using standard scraping tools. Always check `robots.txt` and the site's terms before scraping; some directories explicitly prohibit bulk extraction.

## 6. Public Database / Government Sources

- Company registries (e.g. import/export trade data portals, customs data providers, national business registries) are a strong source for **International** B2B targeting specifically, since they surface verified trading companies with actual shipment/trade history — much higher signal than a generic directory listing.

## 7. Community / Referral

- Existing client referrals, partner-network introductions, and industry Slack/Discord/association communities. Lowest volume, highest ICP-match and highest close-rate downstream — worth tracking separately so its performance isn't averaged away by high-volume low-quality sources.

## 8. AI-Assisted

- Using an LLM to generate/refine Boolean search strings for a given ICP before running them in Apollo/Sales Navigator/directories, and to do a first-pass ICP-match scoring on a sample of extracted rows before full committal to a source.

## Choosing a Method for a Given Batch

| If the source is... | Prefer |
|---|---|
| A licensed B2B database (Apollo, ZoomInfo, Lusha) | Direct export or API |
| LinkedIn / Sales Navigator | Official export features first; browser automation only as fallback, throttled |
| A directory or marketplace | Scraping (ToS-permitting) or manual for small volumes |
| A government/trade registry | API if available, otherwise manual/bulk-download |
| Referral/community | Manual — these are low-volume by nature |
