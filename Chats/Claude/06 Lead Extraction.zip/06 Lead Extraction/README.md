# Stage 06 — Lead Extraction

> Pilot stage. This file (and its companion files in this folder) sets the quality bar and 13-section spec that every other stage in the 54-stage International B2B Sales Knowledge Base follows.

---

## 1. Stage Overview & Objective

Lead Extraction is the process of pulling raw prospect and company records out of external sources — B2B databases, LinkedIn, business directories, government/trade registries, and public web sources — into a structured, usable format before any enrichment, cleaning, or verification happens.

**Objective:** produce a raw lead list (company + contact-level records) that is complete enough in its core fields (company name, domain, industry, size, location, and where available a named contact) to feed into Stage 07 (Contact Discovery) and Stage 08 (Lead Enrichment).

This stage answers: *"Where do we get the raw names from, and how do we pull them out at volume without breaking terms of service or drowning in junk records?"*

## 2. Complete Sub-Stages

1. **Source Selection Confirmation** — confirm which of the sources shortlisted in Stage 05 (Lead Source Selection) will actually be used for this batch/campaign.
2. **Search & Filter Construction** — build the Boolean/filter logic (industry, headcount, geography, keyword) inside each source.
3. **Extraction Execution** — run the manual export, browser-automation, or API pull.
4. **Raw Format Normalization** — bring exports from different sources into one common column schema.
5. **De-duplication Pass (raw)** — remove obvious duplicate company/domain rows before handoff.
6. **Volume & Quality Spot-Check** — sample-check the pull against the ICP before it moves downstream.
7. **Handoff Packaging** — package the raw list for Stage 07/08 with a source tag on every row.

## 3. Success Metrics / KPIs

| Metric | Target | Notes |
|---|---|---|
| ICP-match rate (sampled) | ≥ 70% | % of a random 50-row sample that clearly fits the Stage 02 ICP |
| Duplicate rate (raw, pre-cleaning) | < 15% | Measured after the raw de-dup pass in Sub-Stage 5 |
| Fields populated (company name, domain, industry, geography) | 100% | These four are non-negotiable minimums; rows missing any are rejected at extraction, not pushed downstream |
| Extraction throughput | Source-dependent | e.g. Apollo/Sales Navigator exports: 500–2,500 rows/session; directory scraping: varies by site pagination |
| Source ToS compliance | 100% | No extraction method used may violate the source platform's terms of service |

## 4. Methods

See [`methods.md`](methods.md) for the full breakdown across manual, semi-automated, API-based, and browser-automation extraction methods, plus source-specific notes (LinkedIn/Sales Navigator, Apollo, business directories, government/trade registries).

## 5. Tools

See [`tools.md`](tools.md) for the tool library (databases, scraping tools, browser-automation tools) with approximate pricing (flagged "verify before use"), free/OSS alternatives, and API availability.

## 6. Automation

See [`automation.md`](automation.md) for the manual → semi-automated → fully-automated → AI-assisted progression for each extraction method.

## 7. Quality Checklists

See [`checklists.md`](checklists.md) for the QC gates applied before a raw list is allowed to leave this stage.

## 8. Templates

See [`templates.md`](templates.md) for the raw-list column schema, Boolean search-string templates, and handoff-packaging template.

## 9. Resources / Vendor Library

See [`resources.md`](resources.md) for the source/vendor website library used in this stage.

## 10. Common Pitfalls & Risks

- **ToS violations from aggressive scraping** — LinkedIn in particular actively detects and bans accounts running unmanaged automation; always throttle and prefer official export/API paths first.
- **Over-broad filters** producing high volume but low ICP-match rate, which just pushes cleanup cost downstream to Stage 09/10.
- **Treating "extracted" as "verified"** — extraction only pulls the data out; it does not confirm accuracy. That's Stage 10's job.
- **No source tagging** — if you don't tag which source a row came from, you lose the ability to measure which sources are actually worth paying for.

## 11. Handoff / Cross-References

- **Feeds from:** Stage 05 (Lead Source Selection) — determines which sources are in scope.
- **Feeds into:** Stage 07 (Contact Discovery), Stage 08 (Lead Enrichment).
- **Related:** Stage 02 (ICP Definition) — the filter/match criteria used in Sub-Stage 2 and the KPI in Section 3 both come directly from the ICP.

## 12. FAQ

See [`faq.md`](faq.md).

## 13. References

See [`references.md`](references.md).
