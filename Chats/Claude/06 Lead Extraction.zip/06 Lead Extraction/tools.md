# Stage 06 — Tools

> All pricing below is approximate and should be verified on the vendor's site before use — SaaS pricing changes frequently.

| Tool | Type | Approx. Pricing (verify current) | API? | Free/OSS Alternative |
|---|---|---|---|---|
| Apollo.io | B2B contact/company database | Free tier available; paid plans roughly $49–$99+/user/month | Yes | Hunter.io free tier (limited searches/month) |
| ZoomInfo | B2B contact/company database (enterprise-grade) | Custom/enterprise pricing, typically higher than Apollo | Yes | Apollo, Lusha |
| Lusha | Contact/company data, browser extension | Free tier + paid credit-based plans | Yes | Hunter.io |
| Sales Navigator (LinkedIn) | Prospecting search + list export | Paid subscription, roughly $99+/month | No public API for extraction; export features only | Manual LinkedIn free-tier search (low volume) |
| Hunter.io | Domain/email search | Free tier (limited); paid plans from ~$49/month | Yes | — |
| Phantombuster | Browser-automation scraping | Paid, credit-based, roughly $30–$70+/month | Automation-focused, not a data API | Manual export where the source offers one |
| Snov.io | Contact database + email finder | Free tier; paid plans from ~$30/month | Yes | Hunter.io |
| Government/trade registry portals | Public company/trade data | Free (public data) or nominal fee for bulk export in some countries | Varies by country | — |
| Industry association directories | Curated member lists | Usually free to browse; membership sometimes required | Rarely | — |

## Selection Notes

- Start with whichever database is already licensed for the account (per Stage 05's source-selection decision) rather than adding a new tool per stage.
- Prefer tools with an official API/export over browser-automation tools — the latter carry account-ban risk on LinkedIn specifically.
- For international targeting, government/trade-data portals are often the highest-signal *free* source and are underused relative to paid databases.
