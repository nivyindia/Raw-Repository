# Stage 06 — Quality Checklists

## Pre-Extraction Checklist

- [ ] Source confirmed against Stage 05's shortlist for this campaign
- [ ] Filter/Boolean logic reviewed against the current ICP (Stage 02) before running
- [ ] Extraction method confirmed as ToS-compliant for this source
- [ ] Expected volume estimated (so a wildly-off actual result gets caught immediately)

## Post-Extraction Checklist (before handoff to Stage 07/08)

- [ ] Every row has company name, domain, industry, and geography populated (100% — non-negotiable minimum fields)
- [ ] Random 50-row sample checked for ICP fit; ≥ 70% match rate achieved
- [ ] Raw de-duplication pass completed (by domain, then by company-name fuzzy match)
- [ ] Source tag applied to every row
- [ ] File/export format matches the schema in `templates.md`
- [ ] No personally-identifying data pulled beyond what's needed at this stage (name/company/role only — no scraping of personal social profiles beyond business-relevant fields)

## Rejection Criteria (send back for re-extraction)

- [ ] ICP-match rate on sample < 50%
- [ ] More than 4 of the 4 minimum fields missing on > 10% of rows
- [ ] Source later found to prohibit the extraction method used (rework via a compliant method)

## Sign-off

- [ ] Reviewed by: __________
- [ ] Date: __________
- [ ] Approved for handoff to Stage 07/08: Y / N
