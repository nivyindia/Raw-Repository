# Stage 06 — Resources / Vendor Library

## B2B Databases
- Apollo.io — apollo.io
- ZoomInfo — zoominfo.com
- Lusha — lusha.com
- Snov.io — snov.io
- Hunter.io — hunter.io

## Professional Network
- LinkedIn Sales Navigator — linkedin.com/sales

## Browser Automation
- Phantombuster — phantombuster.com *(use per the ToS caution in `methods.md`)*

## Directories / Trade Sources (International Focus)
- National chamber-of-commerce member directories (country-specific — verify per target market)
- Trade/export promotion council directories (e.g. national export-promotion-body listings, verify per country)
- Customs/trade-data portals (coverage and access vary significantly by country — verify current availability before relying on any specific one)

## Notes
This list intentionally does not name every country-specific registry, since coverage and terms vary widely and change over time — verify availability for the specific target geography before each campaign rather than assuming a source listed here is still current.
