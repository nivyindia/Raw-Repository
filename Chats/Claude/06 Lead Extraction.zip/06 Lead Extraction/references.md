# Stage 06 — References

## Internal Cross-References
- Stage 02 — ICP Definition (source of the filter/match criteria used in this stage)
- Stage 05 — Lead Source Selection (determines which sources are in scope for extraction)
- Stage 07 — Contact Discovery (primary downstream consumer of this stage's output)
- Stage 08 — Lead Enrichment (secondary downstream consumer)
- Stage 10 — Lead Verification (where accuracy/deliverability checking actually happens, not here)

## External / Vendor Documentation
- Apollo.io API documentation (verify current URL/version before use)
- Hunter.io API documentation (verify current URL/version before use)
- LinkedIn Sales Navigator official help/export documentation (verify current URL/version before use)
- Respective country trade/export-promotion body documentation for registry access (verify per target geography)

## Note on Sourcing
This pilot's content is built from general B2B lead-generation industry practice rather than from a specific proprietary internal document, since no dedicated internal "Lead Extraction" SOP was available as source material at the time of writing. Where a real internal SOP exists, it should supersede the general practice described here.
