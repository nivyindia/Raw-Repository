# Stage 06 — Templates

## 1. Raw Extraction Column Schema (CSV/Sheet)

| Column | Required? | Notes |
|---|---|---|
| company_name | Yes | |
| company_domain | Yes | Used as primary de-dup key |
| industry | Yes | Map to internal ICP industry taxonomy, not the source's own category system |
| geography (country/region) | Yes | |
| company_size (headcount band) | Recommended | |
| contact_name | If available | May be filled at Stage 07 instead |
| contact_title | If available | |
| source | Yes | e.g. "Apollo", "Sales Navigator", "TradeRegistry-UAE" |
| extraction_date | Yes | |
| campaign/batch_id | Yes | Links back to the specific pull for later source-performance analysis |

## 2. Boolean Search-String Template (Database/LinkedIn)

```
Industry: [industry OR industry_synonym]
AND Title: [target title OR target title synonym]
AND Geography: [country/region]
AND Company Size: [headcount range]
NOT [excluded industry / negative-ICP keyword, per Stage 02's negative-ICP list]
```

## 3. Handoff Packaging Template

```
Batch ID: 
Source(s) used: 
Total rows extracted: 
Rows after raw de-dup: 
Sample ICP-match rate: 
Ready for: [ ] Stage 07 Contact Discovery   [ ] Stage 08 Lead Enrichment
Notes/flags for downstream stage: 
```
