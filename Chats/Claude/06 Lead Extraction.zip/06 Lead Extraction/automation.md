# Stage 06 — Automation Progression

For each extraction method, the manual → semi-automated → fully-automated → AI-assisted progression:

## B2B Database Extraction (Apollo / ZoomInfo / Lusha)

- **Manual:** Apply filters in the UI, export CSV by hand each time.
- **Semi-automated:** Save filter presets; scheduled recurring exports where the platform supports it.
- **Fully automated:** API pull triggered on a schedule (e.g. weekly) directly into a staging sheet/database.
- **AI-assisted:** LLM reviews the filter/Boolean logic against the current ICP definition before each run and flags drift (e.g. if too many rows are coming back outside the target industry list).

## LinkedIn / Sales Navigator

- **Manual:** Search + copy-paste contact/company names.
- **Semi-automated:** Sales Navigator's own list-export feature (where available on the plan), reviewed manually before use.
- **Fully automated:** Browser-automation tool (e.g. Phantombuster) running scheduled, throttled scrapes — **only** as a fallback when no official export path exists, given ban risk.
- **AI-assisted:** Not typically applicable at the extraction step itself; AI assistance is more useful downstream at enrichment/personalization.

## Directory / Marketplace Scraping

- **Manual:** Copy listings by hand for small directories.
- **Semi-automated:** Scraper script run manually per batch, output reviewed before use.
- **Fully automated:** Scheduled scraper with change-detection (only re-pulls updated listings).
- **AI-assisted:** LLM-based extraction/parsing of unstructured directory pages into structured fields (name, industry, location) where the site has no clean table structure.

## Government / Trade Registry Data

- **Manual:** Manual bulk download from the portal.
- **Semi-automated:** Scheduled bulk-download job where the portal supports it.
- **Fully automated:** API polling where available.
- **AI-assisted:** LLM-based classification of raw registry entries into the ICP's industry taxonomy, since government registries often use their own industry-code systems (e.g. HS codes, NAICS) that need mapping to the ICP's own categories.

## General Rule

Move one step up the automation ladder only once the step below it has a stable, low-error-rate process — automating a noisy manual process just produces noise faster.
