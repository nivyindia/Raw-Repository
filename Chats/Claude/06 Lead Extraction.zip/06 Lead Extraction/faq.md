# Stage 06 — FAQ

**Q: Is extraction the same as verification?**
No. Extraction only pulls raw records out of a source. Accuracy/deliverability verification happens at Stage 10.

**Q: Why is the ICP-match rate target only 70% and not 100%?**
Because filters at the source level are never perfect proxies for the full ICP definition — some legitimate matches get filtered out and some near-matches get filtered in. 70% is a workable bar; anything much lower usually means the filter logic needs rework before continuing.

**Q: Can we scrape LinkedIn directly?**
Prefer official export paths (Sales Navigator's own export features) first. Unmanaged scraping of the LinkedIn UI risks account bans and is explicitly against LinkedIn's terms — if browser automation is used at all, it should be throttled, low-volume, and treated as a fallback, not the default method.

**Q: What do we do if a source has no clean export and no API?**
Fall back to manual extraction for that source, or reconsider whether it's worth including in Stage 05's source shortlist at all — a source that can't be extracted at reasonable volume/cost may not be worth pursuing.

**Q: How do we handle countries where trade-registry data isn't available?**
Fall back to B2B databases and directories for that geography and note the gap — don't substitute a different country's data or invent coverage that doesn't exist.
