# Nivy Next — Master Company Profile

> **Status:** DRAFT — extracted from existing Notion workspace export ("Nivy Next" 2026-06 snapshot).
> This file is the canonical, human-approved source of truth. Nothing here was invented — every
> fact is either taken verbatim from the source workspace, marked `NEEDS_REVIEW` (present but
> ambiguous/templated), or marked `MISSING` (not found anywhere in the export).
> **A human must review and approve this file before it drives any automation.**

- Version: 0.1.0 (unapproved draft)
- Source: `Nivy Next` Notion export, primarily `🧠 Nivy Next — Master Business Profile System.md`
- Extracted: 2026-08-16
- Approval status: **PENDING**

---

## 1. Identity

| Field | Value | Status |
|---|---|---|
| Company name | Nivy Next | confirmed |
| Legal name | *(not stated — "Nivy Next" appears to be a division/brand, not a registered legal entity name)* | NEEDS_REVIEW |
| Parent company | Nivy Digital (Nivy Next is described as "the digital innovation arm of Nivy Digital") | confirmed |
| Brand name | Nivy Next | confirmed |
| Founded year | 2022 (per "Our Journey" timeline: "2022 — The Beginning") | confirmed |
| Website | https://www.thenivy.com | confirmed |
| Primary email | contact@thenivy.com | confirmed |
| Primary phone | +91 867054360 | NEEDS_REVIEW (only 9 digits after country code shown in source — likely a typo/truncation of an Indian mobile number, should be 10 digits) |
| Founders / Leadership | "Founders with backgrounds in business strategy, technology, and international operations" — no names given | MISSING (names) |
| Tagline | Innovate \| Create \| Evolve | confirmed |

## 2. Regional / Office Addresses

The source lists four "hub" addresses under Part 2 §15. These read as **generic placeholder
addresses** (e.g. the Delaware address is a well-known registered-agent template address, and the
UK address is a well-known virtual-office template address; hub emails use the placeholder domain
`yourcompany.com`, not `thenivy.com`). Do not publish these anywhere until verified.

| Hub | Region | Address (as found) | Phone (as found) | Email (as found) | Status |
|---|---|---|---|---|---|
| AMER | Americas | 1209 North Orange Street, Wilmington, DE 19801, United States | +1 (302) 555-0143 | amer.hq@yourcompany.com | NEEDS_REVIEW — looks templated |
| EMEA | UK & EU | 71-75 Shelton Street, Covent Garden, London, WC2H 9JQ, United Kingdom | +44 20 7946 0192 | emea.hq@yourcompany.com | NEEDS_REVIEW — looks templated |
| MEASA | Middle East, Africa, India | Meydan Grandstand, 6th Floor, Meydan Road, Nad Al Sheba, Dubai, UAE | +971 4 388 0111 | measa.hq@yourcompany.com | NEEDS_REVIEW — looks templated |
| APAC | SE Asia, Australia, East Asia | 10 Anson Road, #10-11 International Plaza, Singapore 079903 | +65 6789 0123 | apac.hq@yourcompany.com | NEEDS_REVIEW — looks templated |

**HQ / operations base:** India (stated under Geographic Reach → Secondary Markets: "India (HQ & Operations Base)"). Exact HQ street address: MISSING.

## 3. Positioning

- **Positioning statement:** Nivy Next is an AI-first digital services company that helps growth-stage businesses in international markets scale faster through intelligent marketing, automation, and full-stack digital execution.
- **Category:** AI-Powered Digital Services Agency
- **Tier:** Premium / High-Performance
- **Personality:** Strategic, sharp, modern, results-obsessed, globally literate

### Vision
To be the most trusted AI-powered growth partner for ambitious businesses scaling internationally.

### Mission
To help growth-stage companies across global markets move faster, operate smarter, and grow more profitably — by delivering AI-native digital services that are strategic, measurable, and built for scale.

### Core Values
1. Outcomes Over Outputs
2. AI-Native by Design
3. Radical Transparency
4. Specialist Depth
5. Global Mindset, Local Execution
6. Partnership, Not Transacting

## 4. Descriptions

**Short (elevator, 1 sentence):**
Nivy Next is an AI-first digital services company that helps ambitious businesses scale internationally — faster and smarter.

**Medium (3 sentences):**
Nivy Next is an AI-powered growth partner for growth-stage businesses expanding internationally. We deliver across digital marketing, AI automation, web and app development, creative production, and virtual assistant services — all under one accountable team. Our clients stop managing vendors and start getting results.

**Long:** see `docs/source-excerpts/about-long.md` (kept out of this file to keep it scannable; content is a verbatim carry-over of the "Long" elevator pitch in the source Master Business Profile System doc, Part 1 §C).

## 5. USP / Why Nivy Next
1. AI-Native, Not AI-Adjacent
2. International-Ready by Default
3. One Team. Full Stack.
4. Outcomes Over Outputs
5. Transparent Operations

## 6. Services
See `services.yaml` for the structured breakdown (7 verticals, 12 sub-services under Digital Marketing).

## 7. Industries Served
See `industries.yaml`.

## 8. Target Markets
Primary: United States, United Kingdom, Canada, Australia, UAE.
Secondary: India (HQ), Singapore, South Africa.
See `locations.yaml`.

## 9. Ideal Client Profile
- Stage: Growth-stage (Seed–Series B) or established SME expanding internationally
- Revenue: $500K–$10M ARR (or equivalent)
- Team size: 5–100 employees
- Decision makers: Founder / CEO / CMO / Head of Growth

## 10. Brand Voice & Tone
- Voice: Confident, strategic, direct, globally minded
- Never: jargon-heavy, vague promises, corporate fluff, overly formal language, passive voice
- Tone shifts by channel (proposals = professional/structured; social = energetic/sharp; outreach = conversational; website = clear/outcome-focused; decks = bold/punchy)

## 11. Brand Visual Identity
- **Logo versions, brand colors, fonts:** MISSING — the corresponding Notion pages ("1.2.1 Logo Versions", "1.2.2 Brand Colors", "1.2.3 Fonts") exist only as empty placeholder stubs ("*(Add content here)*") in the export. Several `.png` assets exist in the export root (e.g. `ChatGPT_Image_Oct_24_2025_06_35_57_PM.png`, `Gemini_Generated_Image_*.png`, `image 1.png`–`image 6.png`) but are unlabeled — cannot be attributed to "logo" vs. other use without human confirmation. Copied as-is into `assets/unlabeled/` pending review.

## 12. Approved Claims / Restricted Claims
- MISSING — no explicit "approved claims" or "restricted claims" list exists in the source. The closest equivalent is the "Never" list under Brand Voice (§10) and the stated proof-status table (below), which implies sample/placeholder proof points must not be published as if real.

## 13. Proof Points — Status (do not publish as verified until reviewed)
| Proof type | Status in source | Notes |
|---|---|---|
| Quantified case studies | "2 (sample)" toward a target of 10 live | Source explicitly labels these as *samples* — NEEDS_REVIEW before external use |
| Client testimonials | "3 (sample)" toward a target of 15 real | Source explicitly says: *"replace placeholders with client name... before use"* — NEEDS_REVIEW |
| Directory reviews (Clutch/GoodFirms) | 0 | MISSING |
| Certifications | "Listed" (Google Ads, Meta Blueprint, HubSpot Partner, Semrush Certified Agency) but not yet "verified + displayed" per source | NEEDS_REVIEW |
| Press mentions | 0 | MISSING |

## 14. Social Profiles
See `social-profiles.yaml`. Handles given in source are proposed/draft (e.g. "@thenivy (or @nivy.next)") — **not confirmed live handles**. Human must verify actual live usernames before this feeds any automation.

## 15. Contact
- Website: https://www.thenivy.com
- Email: contact@thenivy.com
- Phone: +91 867054360 (NEEDS_REVIEW — verify digit count)
- The dedicated "Emails", "Social Media Links", and "Office Address" pages in the export are empty template stubs — MISSING as standalone structured data, reconstructed here only from what's embedded in the Master Business Profile System narrative doc.

---

## Change Log
| Version | Date | Change | Author | Status |
|---|---|---|---|---|
| 0.1.0 | 2026-08-16 | Initial extraction from Notion export into Master Profile structure | Claude (automated extraction) | PENDING human approval |
