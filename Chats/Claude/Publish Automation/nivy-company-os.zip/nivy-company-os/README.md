# nivy-company-os

GitHub-as-source-of-truth company profile + omnichannel publishing automation, for **Nivy
Next**. This repo is the output of **Phase 1 + the start of Phase 2** of the implementation
order in the original master command. Read this file before anything else.

## What's real in this repo right now

| Layer | Status |
|---|---|
| `company-profile/` | **Populated with real extracted data**, honestly flagged `confirmed` / `needs_review` / `missing` per field. This is the actual deliverable of Phase 1. |
| `docs/github-source-of-truth.md`, `docs/platform-matrix.md` | Written, as required by the "First Action" step. |
| `database/schema.sql`, `database/seeds/company_seed.sql` | A complete, runnable Postgres schema matching the spec, plus a seed script generated from the extracted profile. |
| `docker-compose.yml`, `.env.example`, `Makefile` | Scaffolded and consistent with each other — `docker compose up -d` will bring up Postgres/n8n/Ollama/api/worker/web containers, *if* you supply `apps/api`, `apps/worker`, `apps/web` Dockerfiles (not yet written — see below) and real secrets in `.env`. |
| `n8n/workflows/github_profile_webhook.json` | One worked **skeleton** workflow showing the intended shape (webhook → verify signature → filter changed files → hand off to parser/validator). The other ~29 workflows listed in the spec are not yet built. |
| `ai/prompts/profile-adaptation.md` | One worked example prompt template with the required "never invent facts" guardrail and `MISSING_FACT` escape hatch. |
| `apps/`, `browser/`, `integrations/` | Folder structure only — no application code yet. |

## What is *not* built, and why

This system's later phases (official API integrations, the Playwright framework, the
Next.js dashboard, live n8n workflow wiring, GitHub Actions approval pipeline, GEO/SEO
engines) require things that can't be created inside this chat session:

- **A real GitHub repository URL.** Nothing here has been pushed anywhere — you asked for
  a system built *around* a GitHub repo, but no `GITHUB_REPOSITORY` was given. Per the
  master command's own §57 ("ask me for the existing GitHub repository URL ONLY if I have
  not provided one"), that's the one open question before Phase 2 can continue for real:
  **what's the target repo (existing or to-be-created)?**
- **Live infrastructure.** n8n, Postgres, and Ollama need to actually run somewhere (your
  server, a VM, cloud containers) with real credentials — I can build the config and
  workflow definitions, but I can't host them for you from here.
- **Platform credentials.** Every official API (Meta, LinkedIn, Google, X, etc.) requires
  your own developer app registrations and OAuth approval — often with manual review by
  the platform. These can't be fabricated or pre-filled.
- **Human review of `company-profile/`.** See the next section — this is a hard blocker
  per the project's own Rule 7 ("human approval required for important factual changes"),
  and rightly so: several fields below are placeholder-looking data lifted from a strategy
  document, not verified real-world facts.

## Phase 1 findings (as requested in the master command, §57)

**1. Existing repository structure:** none — source was a Notion workspace export (zip),
not a git repo. ~430 Markdown files, mostly SOP/dashboard/template stubs; a handful of
files contain real content.

**2 & 3. Existing profile structure / extracted information:** the real substance lives in
one document, `🧠 Nivy Next — Master Business Profile System.md` (1,376 lines) — company
positioning, vision/mission/values, ICP, services (7 verticals, 12 marketing sub-services),
industries, messaging, pricing tiers, social bio drafts, and directory-listing drafts. This
has been fully extracted into `company-profile/`.

**4. Missing information:** legal entity name, founder names, HQ street address, brand
colors, fonts, logo files, an actual SEO keyword list, approved/restricted claims list. See
`master-profile.md` §11–13 for the full list.

**5. Conflicting/suspect information:** the four "regional hub" addresses (Delaware,
London, Dubai, Singapore) use `@yourcompany.com` placeholder emails and at least one
(Delaware) matches a well-known generic registered-agent template address — these read as
unfilled template content, not real offices. The phone number `+91 867054360` is one digit
short of a standard Indian mobile number. Case studies and testimonials are explicitly
labeled "(sample)" in the source. Flagged throughout as `needs_review`.

**6. Proposed Master Profile structure:** built exactly to the spec's file list —
`master-profile.md` + `company-facts.yaml`, `brands.yaml`, `services.yaml`,
`industries.yaml`, `locations.yaml`, `people.yaml`, `contact.yaml`, `social-profiles.yaml`,
`keywords.yaml`, `competitors.yaml`, `certifications.yaml`, `awards.yaml`,
`brand-guidelines.yaml`, `assets/`.

**7. Platform capability matrix:** `docs/platform-matrix.md`.

**8. Implementation plan:** the 14-phase order from the master command, unchanged. This
delivery covers Phase 1 fully and starts Phase 2 (repo/profile structure) and pieces of
Phase 3 (DB schema). Phases 4–14 need the missing pieces above (repo URL, hosting,
credentials) before they can be real rather than templated.

## Suggested next step
Tell me:
1. The GitHub repo to use (existing URL, or "create a new one called X" — I can scaffold
   the push if you connect a GitHub tool/credential, or you can `git init` this folder and
   push it yourself).
2. Corrections for the `needs_review` / `missing` fields in `company-profile/` — especially
   legal name, real HQ address, phone number, and founder names.

Once those land, Phase 3 onward (real n8n wiring, GitHub Actions, API adapters) is
buildable incrementally on top of this scaffold.
