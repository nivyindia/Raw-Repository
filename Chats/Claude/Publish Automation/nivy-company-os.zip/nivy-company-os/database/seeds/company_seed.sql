-- Seed generated from company-profile/*.yaml (extraction v0.1.0). Run only against a dev DB.
-- All *_review flags are carried into the `status` columns — do not treat this seed as
-- verified/publishable data.

INSERT INTO companies (name, parent_company, website, tagline, founded_year, hq_country, source_file, version)
VALUES ('Nivy Next', 'Nivy Digital', 'https://www.thenivy.com', 'Innovate | Create | Evolve', 2022, 'India',
        'company-profile/master-profile.md', '0.1.0');

-- Services (7 verticals) — company_id resolved via subquery for portability
INSERT INTO services (company_id, slug, name, description)
SELECT id, v.slug, v.name, v.description FROM companies,
  (VALUES
    ('digital-marketing', 'Digital Marketing', 'Data-driven marketing systems across SEO, paid, social, email, content, CRO.'),
    ('ai-solutions-automation', 'AI Solutions & Automation', 'Custom AI workflows, chatbots, CRM automation, lead qualification.'),
    ('website-development', 'Website Development', 'Landing pages to full-scale web platforms.'),
    ('app-development', 'App Development', 'Native and cross-platform mobile apps.'),
    ('graphic-design', 'Graphic Designing', 'Brand identity, collateral, decks, social creatives, UI design.'),
    ('video-editing', 'Video Editing', 'Reels, brand films, podcast editing, motion graphics.'),
    ('virtual-assistant', 'Virtual Assistant Services', 'B2B outreach, CRM management, admin, pipeline assistance.')
  ) AS v(slug, name, description)
WHERE companies.name = 'Nivy Next';

INSERT INTO contacts (company_id, type, value, status)
SELECT id, 'email', 'contact@thenivy.com', 'confirmed' FROM companies WHERE name = 'Nivy Next';
INSERT INTO contacts (company_id, type, value, status)
SELECT id, 'phone', '+91 867054360', 'needs_review' FROM companies WHERE name = 'Nivy Next';
