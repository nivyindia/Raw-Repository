-- Nivy Company OS — PostgreSQL schema
-- PostgreSQL is an OPERATIONAL MIRROR of company-profile/ in GitHub. It must never become
-- an independent source of truth (Rule 2). Every canonical-fact table carries source_file,
-- source_commit, and version so provenance is always traceable back to GitHub.

CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- ============================================================================
-- CORE PROFILE MIRROR
-- ============================================================================

CREATE TABLE companies (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name TEXT NOT NULL,
    legal_name TEXT,
    parent_company TEXT,
    website TEXT,
    tagline TEXT,
    founded_year INT,
    hq_country TEXT,
    hq_address TEXT,
    canonical_value JSONB NOT NULL DEFAULT '{}',
    source TEXT NOT NULL DEFAULT 'github',
    source_commit TEXT,
    source_file TEXT,
    version TEXT NOT NULL DEFAULT '0.0.0',
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    deleted_at TIMESTAMPTZ
);

CREATE TABLE brands (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    company_id UUID NOT NULL REFERENCES companies(id),
    name TEXT NOT NULL,
    role TEXT,
    website TEXT,
    source_commit TEXT, source_file TEXT, version TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    deleted_at TIMESTAMPTZ
);

CREATE TABLE people (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    company_id UUID NOT NULL REFERENCES companies(id),
    full_name TEXT,
    role TEXT,
    bio TEXT,
    is_public_facing BOOLEAN DEFAULT true,
    source_commit TEXT, source_file TEXT, version TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    deleted_at TIMESTAMPTZ
);

CREATE TABLE services (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    company_id UUID NOT NULL REFERENCES companies(id),
    slug TEXT NOT NULL,
    name TEXT NOT NULL,
    description TEXT,
    parent_service_id UUID REFERENCES services(id),
    source_commit TEXT, source_file TEXT, version TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    deleted_at TIMESTAMPTZ,
    UNIQUE(company_id, slug)
);

CREATE TABLE industries (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    company_id UUID NOT NULL REFERENCES companies(id),
    name TEXT NOT NULL,
    note TEXT,
    source_commit TEXT, source_file TEXT, version TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    deleted_at TIMESTAMPTZ
);

CREATE TABLE locations (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    company_id UUID NOT NULL REFERENCES companies(id),
    label TEXT NOT NULL,          -- e.g. 'AMER hub'
    region TEXT,
    address TEXT,
    phone TEXT,
    email TEXT,
    is_hq BOOLEAN DEFAULT false,
    status TEXT DEFAULT 'needs_review', -- confirmed | needs_review | missing
    source_commit TEXT, source_file TEXT, version TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    deleted_at TIMESTAMPTZ
);

CREATE TABLE contacts (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    company_id UUID NOT NULL REFERENCES companies(id),
    type TEXT NOT NULL,   -- email | phone | booking_url
    value TEXT NOT NULL,
    status TEXT DEFAULT 'needs_review',
    source_commit TEXT, source_file TEXT, version TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE social_profiles (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    company_id UUID NOT NULL REFERENCES companies(id),
    platform TEXT NOT NULL,
    handle TEXT,
    url TEXT,
    status TEXT DEFAULT 'needs_review', -- confirmed | needs_review | missing_handle
    source_commit TEXT, source_file TEXT, version TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    deleted_at TIMESTAMPTZ,
    UNIQUE(company_id, platform)
);

CREATE TABLE websites (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    company_id UUID NOT NULL REFERENCES companies(id),
    url TEXT NOT NULL,
    kind TEXT DEFAULT 'primary', -- primary | market-specific | landing
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE keywords (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    company_id UUID NOT NULL REFERENCES companies(id),
    keyword TEXT NOT NULL,
    kind TEXT DEFAULT 'tag', -- tag | seo_keyword
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE competitors (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    company_id UUID NOT NULL REFERENCES companies(id),
    competitor_type TEXT,
    competitor_name TEXT,
    their_gap TEXT,
    our_advantage TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE certifications (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    company_id UUID NOT NULL REFERENCES companies(id),
    name TEXT NOT NULL,
    status TEXT DEFAULT 'needs_review',
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE awards (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    company_id UUID NOT NULL REFERENCES companies(id),
    name TEXT NOT NULL,
    year INT,
    issuer TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE assets (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    company_id UUID NOT NULL REFERENCES companies(id),
    kind TEXT,  -- logo | image | brand_asset | unlabeled
    file_path TEXT NOT NULL,
    label TEXT,
    reviewed BOOLEAN DEFAULT false,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE brand_guidelines (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    company_id UUID NOT NULL REFERENCES companies(id),
    voice TEXT,
    tone_by_channel JSONB,
    never_list JSONB,
    colors JSONB,
    fonts JSONB,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- ============================================================================
-- VERSIONING / CHANGE TRACKING (GitHub commit history mirror)
-- ============================================================================

CREATE TABLE master_profile_versions (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    company_id UUID NOT NULL REFERENCES companies(id),
    version TEXT NOT NULL,
    commit_sha TEXT NOT NULL,
    author TEXT,
    change_summary TEXT,
    approval_status TEXT NOT NULL DEFAULT 'pending', -- pending | approved | rejected
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE master_profile_changes (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    version_id UUID NOT NULL REFERENCES master_profile_versions(id),
    field_path TEXT NOT NULL,   -- e.g. 'company-facts.yaml#primary_phone'
    previous_value TEXT,
    new_value TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- ============================================================================
-- PLATFORM REGISTRY
-- ============================================================================

CREATE TABLE platforms (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name TEXT NOT NULL UNIQUE,
    category TEXT,
    official_url TEXT,
    developer_url TEXT,
    documentation_url TEXT,
    api_available BOOLEAN,
    oauth_available BOOLEAN,
    profile_api BOOLEAN,
    publishing_api BOOLEAN,
    analytics_api BOOLEAN,
    browser_automation_possible BOOLEAN,
    browser_automation_allowed BOOLEAN,
    manual_only BOOLEAN DEFAULT false,
    rate_limit TEXT,
    pricing TEXT,
    access_requirements TEXT,
    last_verified DATE,
    notes TEXT
);

CREATE TABLE platform_capabilities (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    platform_id UUID NOT NULL REFERENCES platforms(id),
    capability TEXT NOT NULL,   -- e.g. 'update_bio', 'publish_post'
    supported BOOLEAN NOT NULL DEFAULT false,
    notes TEXT
);

CREATE TABLE platform_accounts (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    company_id UUID NOT NULL REFERENCES companies(id),
    platform_id UUID NOT NULL REFERENCES platforms(id),
    handle TEXT,
    account_url TEXT,
    credential_ref TEXT, -- pointer into secret storage, never the secret itself
    status TEXT DEFAULT 'unverified',
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE platform_profiles (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    platform_account_id UUID NOT NULL REFERENCES platform_accounts(id),
    generated_from_version_id UUID REFERENCES master_profile_versions(id),
    status TEXT NOT NULL DEFAULT 'draft', -- draft | validated | approval_required | approved | published
    last_published_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE platform_profile_fields (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    platform_profile_id UUID NOT NULL REFERENCES platform_profiles(id),
    field_name TEXT NOT NULL,  -- e.g. 'bio', 'headline'
    value TEXT,
    char_limit INT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- ============================================================================
-- CONTENT ENGINE
-- ============================================================================

CREATE TABLE content (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    company_id UUID NOT NULL REFERENCES companies(id),
    title TEXT,
    body TEXT,
    status TEXT DEFAULT 'draft',
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE content_variants (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    content_id UUID NOT NULL REFERENCES content(id),
    platform_id UUID REFERENCES platforms(id),
    variant_body TEXT,
    status TEXT DEFAULT 'draft',
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE content_publications (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    content_variant_id UUID NOT NULL REFERENCES content_variants(id),
    platform_account_id UUID NOT NULL REFERENCES platform_accounts(id),
    published_at TIMESTAMPTZ,
    external_post_id TEXT,
    status TEXT DEFAULT 'pending'
);

-- ============================================================================
-- SEO / GEO
-- ============================================================================

CREATE TABLE seo_properties (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    company_id UUID NOT NULL REFERENCES companies(id),
    domain TEXT NOT NULL
);

CREATE TABLE keyword_rankings (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    keyword_id UUID NOT NULL REFERENCES keywords(id),
    engine TEXT, position INT, checked_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE serps (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    keyword_id UUID NOT NULL REFERENCES keywords(id),
    raw_result JSONB, checked_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE backlinks (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    seo_property_id UUID NOT NULL REFERENCES seo_properties(id),
    source_url TEXT, target_url TEXT, discovered_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE mentions (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    company_id UUID NOT NULL REFERENCES companies(id),
    source_url TEXT, snippet TEXT, sentiment TEXT, found_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE reviews (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    company_id UUID NOT NULL REFERENCES companies(id),
    platform_id UUID REFERENCES platforms(id),
    rating NUMERIC, review_text TEXT, responded BOOLEAN DEFAULT false,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE nap_records (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    company_id UUID NOT NULL REFERENCES companies(id),
    platform_id UUID REFERENCES platforms(id),
    name TEXT, address TEXT, phone TEXT, consistent BOOLEAN, checked_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE geo_visibility (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    company_id UUID NOT NULL REFERENCES companies(id),
    surface TEXT, -- e.g. 'google_ai_overview', 'perplexity'
    classification TEXT, -- OFFICIAL_API | INDIRECT_MEASUREMENT | MANUAL | UNAVAILABLE
    query TEXT, mentioned BOOLEAN, checked_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- ============================================================================
-- AUTOMATION / APPROVALS / AUDIT
-- ============================================================================

CREATE TABLE automation_jobs (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    job_type TEXT NOT NULL,
    status TEXT DEFAULT 'queued',
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE automation_runs (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    job_id UUID NOT NULL REFERENCES automation_jobs(id),
    started_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    finished_at TIMESTAMPTZ,
    status TEXT DEFAULT 'running',
    dry_run BOOLEAN DEFAULT false
);

CREATE TABLE automation_errors (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    run_id UUID NOT NULL REFERENCES automation_runs(id),
    message TEXT, stack TEXT, created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE manual_actions (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    platform_id UUID REFERENCES platforms(id),
    action TEXT NOT NULL,
    instructions TEXT,
    required_data JSONB,
    status TEXT DEFAULT 'open', -- open | in_progress | done
    assigned_to TEXT,
    evidence TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    completed_at TIMESTAMPTZ
);

CREATE TABLE approval_requests (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    subject_type TEXT NOT NULL, -- 'platform_profile' | 'master_profile_version' | 'content_variant'
    subject_id UUID NOT NULL,
    status TEXT NOT NULL DEFAULT 'pending', -- pending | approved | rejected
    requested_by TEXT,
    decided_by TEXT,
    decided_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE audit_logs (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    ts TIMESTAMPTZ NOT NULL DEFAULT now(),
    source TEXT, commit_sha TEXT, app_user TEXT, platform TEXT,
    field TEXT, old_value TEXT, new_value TEXT,
    method TEXT, approval TEXT, status TEXT, error TEXT
);

-- indexes
CREATE INDEX idx_services_company ON services(company_id);
CREATE INDEX idx_social_profiles_company ON social_profiles(company_id);
CREATE INDEX idx_platform_accounts_company ON platform_accounts(company_id);
CREATE INDEX idx_content_variants_content ON content_variants(content_id);
CREATE INDEX idx_audit_logs_ts ON audit_logs(ts);
CREATE INDEX idx_manual_actions_status ON manual_actions(status);
CREATE INDEX idx_approval_requests_status ON approval_requests(status);
