# GitHub as Source of Truth — How This Repo Works

## The rule
`company-profile/` in **this repository** is the only canonical, human-approved source of
company facts. Every other system (PostgreSQL, generated social bios, website copy,
directory listings) is a **derivative** of these files, regenerated on demand — never
edited directly and pushed back upward.

```
company-profile/*.md, *.yaml   (human edits + reviews + approves)
        │  git commit / PR merge
        ▼
   GitHub webhook  →  n8n  →  validate + parse  →  PostgreSQL (canonical mirror)
                                                  │
                                                  ▼
                                      Ollama (rewrite/adapt, never invent)
                                                  │
                                                  ▼
                              platform-specific drafts → approval queue
                                                  │
                                                  ▼
                        official API (preferred) or permitted Playwright fallback
                                                  │
                                                  ▼
                                verification + audit log + report
```

## Why the extraction so far is full of `NEEDS_REVIEW` / `MISSING`
This repo was seeded from an existing Notion export ("Nivy Next"), not written fresh. Per
the system's core rule (**never invent company facts**), every field in
`company-profile/` was extracted verbatim or explicitly flagged:

- **`confirmed`** — stated plainly and unambiguously in the source.
- **`needs_review`** — present, but looks templated/placeholder (e.g. the four "regional
  hub" addresses use a well-known Delaware registered-agent address and `@yourcompany.com`
  emails — classic boilerplate, not confirmed real offices), or is internally inconsistent
  (e.g. the phone number is one digit short of a standard Indian mobile number).
- **`missing`** — no value exists anywhere in the export (e.g. legal entity name, founder
  names, brand colors, fonts, logo files, HQ street address, an actual SEO keyword list).

**Nothing in `company-profile/` should be pushed to any live platform until a human has
gone through the `NEEDS_REVIEW` and `MISSING` items and either supplied the correct value
or explicitly accepted the current draft.**

## Configuration
```
GITHUB_REPOSITORY=owner/nivy-company-os
GITHUB_BRANCH=main
GITHUB_MASTER_PROFILE_PATH=company-profile/master-profile.md
GITHUB_WEBHOOK_SECRET=<set in .env, never commit>
```
The repository URL is not hardcoded anywhere in `apps/` or `integrations/` — it is read
from these environment variables at runtime (see `apps/api` config loader once implemented).

## Approval workflow (GitHub Actions, to be added in `.github/workflows/`)
1. PR opened against `company-profile/**`
2. Schema validation (YAML syntax + required-field checks)
3. Fact validation (URL reachability, email format, phone format, char-limit checks per
   platform in `docs/platform-matrix.md`)
4. Broken-link check
5. Human review + approval (CODEOWNERS on `company-profile/`)
6. Merge → webhook fires → n8n picks it up

This repo does not yet contain the GitHub Actions workflow files or the n8n workflow
JSON bodies with real node wiring — see `docs/setup.md` (to be written) for the
implementation order. What exists today is the **data layer** (this profile) and the
**scaffold** (folder structure, schema, docker-compose, prompt templates) described in
the top-level README.
