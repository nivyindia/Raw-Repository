# Platform Capability Matrix

Status legend: `OFFICIAL_API` (documented public API exists) · `INDIRECT_MEASUREMENT`
(no publishing/read API, but visibility can be measured indirectly) · `MANUAL_ONLY` (no
API — Playwright only if ToS-permitted, otherwise pure manual task) · `UNKNOWN` (needs
research before this system touches it).

**No endpoint, scope, rate limit, or price below is fabricated. Where the current
Anthropic knowledge cutoff (Jan 2026) can't guarantee the details are still accurate,
that is flagged — re-verify against the platform's own developer docs before building
any integration.**

## Social Platforms

| Platform | Official API | OAuth | Profile update via API | Publish via API | Browser automation allowed | Notes |
|---|---|---|---|---|---|---|
| LinkedIn (Company Page) | Yes (Marketing/Community Mgmt API) — restricted access, requires app review | Yes | Partial | Yes (with approved app) | No — LinkedIn ToS prohibits automation | Access typically requires partnership approval; re-verify current tier requirements |
| Instagram (Business) | Yes (Instagram Graph API, via Meta) | Yes | Partial | Yes (Business accounts only) | No | Requires Facebook Page linkage |
| Facebook Pages | Yes (Graph API) | Yes | Yes | Yes | No | |
| X / Twitter | Yes (X API v2) | Yes | Partial | Yes | No | Free tier is heavily rate-limited; paid tiers exist — verify current pricing before relying on it |
| YouTube | Yes (YouTube Data API v3) | Yes | Yes (channel metadata) | Yes (video upload) | No | Quota-based rate limiting |
| TikTok | Yes (TikTok for Developers / Content Posting API) | Yes | Limited | Limited (approval-gated) | No | Access is application/approval-gated |
| Pinterest | Yes (Pinterest API) | Yes | Yes | Yes | No | |
| Reddit | Yes (Reddit API) | Yes | Limited | Yes (posts/comments) | No — automation of posting must respect subreddit rules and Reddit API terms | Commercial API pricing changed in 2023; re-verify current terms |
| Threads | Yes (Threads API, via Meta) | Yes | Limited | Yes | No | Newer API — re-verify current scope coverage |
| Snapchat | Limited (Snap Kit / Marketing API for ads) | Yes (ads only) | No general profile API | No | No | Primarily an ads API, not organic-profile |
| Telegram | Yes (Bot API) | N/A (bot tokens) | N/A (bots, not personal/brand profiles) | Yes (channel/bot posting) | N/A | Different paradigm — channels/bots, not "profiles" |
| Discord | Yes (Discord API) | Yes (bots) | N/A | Yes (via bot) | N/A | Server/community tool, not a brand "profile" |
| Quora | UNKNOWN | UNKNOWN | UNKNOWN | UNKNOWN | UNKNOWN | No confirmed public API for business profile management — verify before building |
| Medium | Deprecated public API (integration token flow discontinued for new apps in past) | UNKNOWN | UNKNOWN | UNKNOWN | UNKNOWN | Re-verify current state before use |
| Tumblr | Yes (Tumblr API) | Yes | Yes | Yes | No | |
| Mastodon | Yes (per-instance REST API) | Yes | Yes | Yes | No | API surface depends on the specific instance |
| Bluesky | Yes (AT Protocol / Bluesky API) | Yes (app passwords / OAuth) | Yes | Yes | No | |

## Search / Webmaster

| Platform | Official API | Notes |
|---|---|---|
| Google Search Console | Yes (Search Console API) | |
| Google Business Profile | Yes (Business Profile API) — access is approval-gated | |
| Google Analytics (GA4) | Yes (Data API) | |
| Google Trends | No official public API | Third-party wrappers exist but are unofficial/unsupported |
| Google Ads Keyword Planner | Yes, via Google Ads API (requires developer token approval) | |
| PageSpeed Insights / Lighthouse | Yes (PageSpeed Insights API); Lighthouse is a local/CLI tool, not a hosted API | |
| Bing Webmaster Tools | Yes (Bing Webmaster API) | |
| Bing Places | UNKNOWN — verify current API availability | |
| Yandex Webmaster | Yes (Yandex Webmaster API) | |
| Naver Search Advisor | UNKNOWN | Korea-specific; verify |
| Baidu Webmaster Tools | UNKNOWN | China-specific; verify |

## Local / Business SEO Directories

| Platform | Official API | Notes |
|---|---|---|
| Google Business Profile | Yes | see above |
| Apple Business Connect | Yes (Apple Business Connect has a management portal / limited API access) | Verify current access model |
| Yelp | Yes (Fusion API — read-heavy; business owner profile editing is largely portal-based, not full write API) | |
| Foursquare | Yes (Places API, read-focused) | |
| Tripadvisor | Limited (Content API, primarily for read/display, not profile publishing) | |
| MapQuest / HERE / Waze | HERE has a developer API; Waze Business listings are managed via a portal, not a public write API | Verify |
| Yellow Pages, MapQuest, BBB, Hotfrog, Manta, Chamber of Commerce, Crunchbase, Clutch, GoodFirms, DesignRush, Sortlist, UpCity, G2, Capterra, Trustpilot | Mostly **no public write API** for profile management — portal/manual claim-and-edit flows | Treat as `MANUAL_ONLY` until individually verified; do not attempt unauthorized scraping/automation against ToS |

## Content Platforms

| Platform | Official API | Notes |
|---|---|---|
| WordPress (self-hosted) | Yes (REST API, or XML-RPC on older installs) | |
| Ghost | Yes (Admin API) | |
| Substack | No public publishing API | `MANUAL_ONLY` |
| Blogger | Yes (Blogger API) | |
| Hashnode | Yes (GraphQL API) | |
| DEV Community | Yes (Forem API) | |
| Medium, LinkedIn Articles, Reddit, Quora | see Social Platforms table above | |

## Video Platforms

| Platform | Official API | Notes |
|---|---|---|
| YouTube | Yes | see above |
| Vimeo | Yes (Vimeo API) | |
| TikTok | see above | |
| Instagram Reels / Facebook Video | via Meta Graph API | |
| Dailymotion | Yes (Dailymotion API) | |
| Twitch | Yes (Twitch API) — primarily livestream/VOD | |
| Rumble | UNKNOWN | Verify |

## Developer / Tech, Design, and Startup Databases

Standard developer-facing platforms (GitHub, GitLab, Bitbucket, Stack Overflow/Stack
Exchange, DEV, Hashnode, CodePen, Product Hunt, Hacker News, Kaggle) and design platforms
(Behance, Dribbble, ArtStation, DeviantArt, Adobe Portfolio) generally **do** have public
APIs for content/profile management, with varying scope. Startup databases (Crunchbase,
Wellfound, F6S, Gust, StartupBlink, Tracxn, Dealroom) are **largely read-only or
claim-and-edit-via-portal** — treat as `MANUAL_ONLY` / `INDIRECT_MEASUREMENT` until
verified per-platform.

## SEO Data Providers (optional paid adapters)
Semrush, Ahrefs, Moz, DataForSEO, SerpApi, Similarweb, Majestic all have official paid
APIs. The core system must not require any of these — they are optional `integrations/seo/`
adapters, gated behind the corresponding `*_API_KEY` env var being present.

## AI / GEO Visibility Surfaces

| Surface | Classification | Notes |
|---|---|---|
| Google AI Overviews / AI search | `INDIRECT_MEASUREMENT` | No official "AI ranking" API; must be inferred from SERP monitoring tools that detect AI Overview presence |
| Bing / Copilot | `INDIRECT_MEASUREMENT` | No official ranking API for AI answers |
| Perplexity | `MANUAL` / `INDIRECT_MEASUREMENT` | No public citation-tracking API |
| ChatGPT discoverability | `UNAVAILABLE` | No official API for "does ChatGPT mention us" |
| Gemini | `UNAVAILABLE` | Same as above |
| Claude | `UNAVAILABLE` | Same as above |
| You.com, Brave Search | `INDIRECT_MEASUREMENT` / `UNAVAILABLE` | Verify current state |

**No AI-ranking API is claimed to exist anywhere in this system.** GEO monitoring must be
built as periodic sampled queries + manual/automated screenshot review, not a live ranking
feed.

---
*Last verified: not yet independently re-verified against live docs as of this repo's
creation — this table reflects general platform knowledge as of the assistant's training
data and should be re-confirmed against each platform's current developer documentation
before any integration is built, per the project's "never fabricate API details" rule.*
