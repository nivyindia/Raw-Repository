# Prompt Library

Each prompt file in this folder is a template for one Ollama transformation task listed in
the master command (profile adaptation, bio generation, headline generation, service
descriptions, SEO titles/meta descriptions, content repurposing, keyword clustering,
search intent, competitor analysis, content gap, review sentiment, review response
drafting, NAP consistency, entity consistency, GEO analysis).

Only `profile-adaptation.md` is filled in as a worked example so far — it demonstrates the
required pattern every other prompt file must follow:

1. The literal instruction **"Use only facts supplied by the approved Master Profile. Never
   invent company facts."** must appear in every prompt.
2. The prompt must accept the approved facts as structured input (JSON/YAML), never rely on
   the model's own memory of the company.
3. The prompt must define an explicit `MISSING_FACT: <field>` escape hatch instead of letting
   the model fill gaps with plausible-sounding text.

Add the remaining prompt files following this same pattern before wiring `ai/ollama/` calls
into any n8n workflow.
