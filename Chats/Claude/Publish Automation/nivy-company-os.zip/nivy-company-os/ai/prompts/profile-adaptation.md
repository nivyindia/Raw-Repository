# Prompt: Platform Profile Adaptation

## System rule (prepend to every call)
"Use only facts supplied by the approved Master Profile. Never invent company facts.
If a required fact is missing from the supplied context, output MISSING_FACT: <field>
instead of guessing."

## Template
```
You are adapting Nivy Next's approved company profile for {{platform_name}}.

Constraints for this platform:
- Character limit: {{char_limit}}
- Format: {{format_notes}}
- Fields required: {{required_fields}}

Approved source facts (JSON, from company-profile/*.yaml — do not add anything not present here):
{{master_profile_json}}

Task: produce a {{field_name}} for {{platform_name}} that:
1. Uses only the facts above.
2. Fits within {{char_limit}} characters.
3. Matches the brand voice: confident, strategic, direct, globally minded.
4. Avoids: jargon-heavy language, vague promises, corporate fluff, overly formal language, passive voice.

If any required fact is not present in the source facts, respond with:
MISSING_FACT: <name of missing field>
and do not fabricate a placeholder value.

Output only the final text, nothing else.
```
