# Tools — 34 Pricing and Packaging

[⬅ Back to README](README.md)

_Pricing figures are approximate — verify current pricing before purchase._

| Tool | Purpose | Pricing (approx., verify) | OSS/Free Alt | API/Automation |
|---|---|---|---|---|
| HubSpot Quotes / Product Library | Central pricing catalog synced into every proposal | Free with HubSpot | Free tier | Native |
| PandaDoc / Proposify | Pricing table rendering inside proposal documents | Paid, verify current tier pricing | No direct match in the declared OSS stack (Odoo/Mautic/Documenso/NocoDB-Baserow/Ollama) — evaluate case-by-case rather than force-fit | API |
| Google Sheets / Notion database | Internal master pricing table (tiers × market × add-ons) | Free | Free | API (Notion API) |
| Stripe / PayPal / Wise | Payment collection once a tier is agreed (feeds Stage 36/39) | Usage-based | No direct match in the declared OSS stack (Odoo/Mautic/Documenso/NocoDB-Baserow/Ollama) — evaluate case-by-case rather than force-fit | API |

## Selection Notes
- The pricing catalog should live in exactly one place (Notion or CRM product library) and be referenced by proposal tools, not re-typed per deal — prevents stale figures reaching a prospect.
