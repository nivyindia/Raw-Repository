# Tools — 36 Contract and Legal

[⬅ Back to README](README.md)

_Pricing figures are approximate — verify current pricing before purchase._

| Tool | Purpose | Pricing (approx., verify) | OSS/Free Alt | API/Automation |
|---|---|---|---|---|
| DocuSign | Contract e-signature | Subscription, verify current tier pricing | Documenso (OSS e-signature) | API |
| Dropbox Sign | Contract e-signature (lighter-weight alternative) | Subscription, verify current tier pricing | Free tier (limited) | API |
| PandaDoc / Signable | Combined proposal-to-contract e-signature | Paid, verify current tier pricing | Documenso (OSS e-signature) | API |
| Google Drive / Notion | Signed-document filing and company records | Free–low cost | Free tier | API |
| Stripe / PayPal / Wise | Payment collection tied to the signed contract (feeds Stage 39) | Usage-based | No direct match in the declared OSS stack (Odoo/Mautic/Documenso/NocoDB-Baserow/Ollama) — evaluate case-by-case rather than force-fit | API |

## Selection Notes
- Whichever e-signature tool is used for the proposal (Stage 33) should generally carry through to the contract, to avoid a second unfamiliar tool in the client's signing experience.
