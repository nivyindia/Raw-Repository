# Tools — 45 Product and Service Adoption

[⬅ Back to README](README.md)

_Pricing figures are approximate — verify current pricing before purchase._

| Tool | Purpose | Pricing (approx., verify) | OSS/Free Alt | API/Automation |
|---|---|---|---|---|
| Notion (client portal) | Live project dashboard — tasks, status, KPIs | Free–paid, verify current tier pricing | Free tier | API |
| Google Analytics / GA4 | Web performance data for adoption/results reporting | Free | Free | API |
| Meta Ads Manager | Ad performance data for adoption/results reporting | Free (platform), spend separate | — | API |
| Google Data Studio / Looker Studio | Live client-facing dashboards | Free | Free | API |
| WhatsApp Business | Weekly relationship-maintenance touchpoint | Free–low cost | Free tier | API |
| Zoom / Google Meet | Monthly strategy/results review calls | Free–low cost | Free tier | — |

## Selection Notes
- The client-facing dashboard and the internal delivery-tracking system should draw from the same underlying data — two systems showing different numbers undermines the trust this stage is meant to build.
