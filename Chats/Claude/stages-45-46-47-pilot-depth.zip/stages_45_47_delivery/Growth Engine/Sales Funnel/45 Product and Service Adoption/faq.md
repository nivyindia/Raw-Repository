# FAQ — 45 Product and Service Adoption

[⬅ Back to README](README.md)

**Q: Is there a dedicated internal "adoption" SOP this stage was built from?**
No — no internal doc treats adoption as a standalone step. This stage is synthesized from the "Service Delivery & Scope Management Policy" (SOW, revisions, change requests) and the internal delivery-stage communication rhythm (weekly/bi-weekly/monthly touchpoints), formalized here as its own stage since the funnel's 54-stage structure calls for it explicitly.

**Q: How many revision rounds are included per deliverable?**
Per the source policy: 2 rounds for standard deliverables, 3 for major deliverables (e.g., website wireframes, brand style guides, video scripts) — verify current policy, and confirm the specific count for each deliverable is stated in that engagement's SOW.

**Q: What happens if a client asks for something outside the signed SOW?**
It becomes a formal Change Request — assessed, quoted in writing, and requires client approval before work begins. Unapproved out-of-scope work is explicitly non-billable per policy.

**Q: What signals indicate a client isn't adopting the service well, even if deliverables are being sent on time?**
Going quiet on touchpoints, not engaging with reports/dashboard, or KPIs trending flat/down for two consecutive cycles — these should trigger a remediation review rather than waiting for the client to complain.

**Q: What happens if adoption-health signals stay negative after a remediation review?**
The account routes to Stage 46 (Support and Issue Resolution) for structured issue handling rather than continuing the standard cadence unchanged.
