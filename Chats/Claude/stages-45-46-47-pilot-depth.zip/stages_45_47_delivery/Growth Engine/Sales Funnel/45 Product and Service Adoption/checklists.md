# Checklists — 45 Product and Service Adoption

[⬅ Back to README](README.md)

## Cadence QC
- [ ] Weekly relationship touchpoint sent on schedule
- [ ] Bi-weekly/monthly report delivered by the agreed date
- [ ] Monthly strategy/review call held and not silently skipped

## Adoption-Health Signal QC
- [ ] Client is actively engaging with deliverables (opening reports, responding to updates), not going silent
- [ ] Agreed KPIs are being met or trending toward being met
- [ ] No unresolved Change Request (Stage 42/45) sitting unactioned for more than the SOW's stated turnaround window

## Scope & SOW QC
- [ ] Delivered work matches the signed SOW's Included Services — no unbilled scope creep
- [ ] Any request outside the SOW routed through the formal Change Request process, not absorbed silently

## Escalation QC
- [ ] Two consecutive cycles of declining/underperforming KPIs trigger a remediation review, not just another report
- [ ] Remediation review outcome logged and, if unresolved, routed to Stage 46 (Support and Issue Resolution)

## Duplicate / Accuracy / Completeness Checks
- [ ] Client-facing dashboard and internal delivery tracker show the same numbers
