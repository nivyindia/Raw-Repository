# Methods — 45 Product and Service Adoption

[⬅ Back to README](README.md)

## Traditional
Delivery happens and the client is simply expected to notice value — no structured adoption tracking. Replaced here by a defined communication rhythm and adoption-health signal set.

## Modern / Tool-Assisted
A live client portal/dashboard (Notion or equivalent) showing task status and KPIs in real time, so adoption is visible rather than only reported after the fact.

## AI-Assisted
AI-generated bi-weekly/monthly performance reports that make delivered value legible to the client without manual report-building each cycle.

## Manual
Weekly relationship-maintenance touchpoint (WhatsApp or equivalent) — a human check-in, not a templated automated message, to surface early concerns before they become churn risk.

## Automated
Automated report generation and dashboard refresh from source data (GA4, ad platforms, CRM) on a fixed cadence.

## API / Integration
Analytics/ad-platform APIs (GA4, Meta Ads Manager) feeding the client dashboard and reports directly, avoiding manual data pulls.

## Browser Automation
Not applicable to this stage.

## Scraping
Not applicable to this stage.

## Public Database / Government
Not applicable to this stage.

## Community / Referral
Strong adoption and visible results are the direct precondition for referral requests (Stage 53) and case studies (Stage 52) — this stage is the upstream input to both.

## Method Selection Guidance
Default to the standard weekly/bi-weekly/monthly communication rhythm; escalate to a dedicated remediation review the moment adoption-health signals (see [checklists.md](checklists.md)) trend negative for two consecutive cycles.
