# Automation — 45 Product and Service Adoption

[⬅ Back to README](README.md)

## Manual
Weekly personal relationship-maintenance touchpoint — always a human message, not an automated template, since its purpose is surfacing concerns a dashboard won't show.

## Semi-Automated
AI drafts the bi-weekly/monthly performance report narrative from pulled data; a human reviews framing and tone before it's sent, particularly for underperforming metrics.

## Full-Automated
Dashboard and data-pull refresh (GA4, ad platforms) on a fixed schedule so report data is always current without manual export/import.

## AI-Assisted Workflow
1. Onboarding (Stage 40) and kickoff (Stage 41) complete, delivery underway (Stage 42).
2. Source data (analytics, ad platforms, CRM) feeds the live dashboard automatically.
3. AI drafts the bi-weekly/monthly report from current data; account manager reviews before send.
4. Weekly WhatsApp (or equivalent) touchpoint sent personally, referencing current dashboard state.
5. Adoption-health signals (see [checklists.md](checklists.md)) reviewed each cycle; two consecutive negative cycles trigger remediation review and feed Stage 46.

## Suggested n8n / integration flow
`GA4/Ads API (data pull) → Dashboard refresh → AI report draft → Account manager review → Send → Adoption-health signal check → If declining 2x: remediation review (Stage 46)`
