# Templates — 45 Product and Service Adoption

[⬅ Back to README](README.md)

## Communication Rhythm

| Channel | Purpose | Cadence |
|---|---|---|
| Notion/client portal | Live project dashboard — tasks, status, KPIs | Continuous |
| WhatsApp (or equivalent) | Personal relationship maintenance, early concern surfacing | Weekly |
| Email | Formal performance report | Bi-weekly or monthly (per SOW) |
| Zoom / Google Meet | Strategy/results review call | Monthly |

## Weekly Touchpoint Message Template
```
Hi [Name],

Quick update — [1-2 line summary of what happened this week]. Everything
on track for [upcoming milestone/report].

Let me know if anything's come up on your side.
```

## Adoption Health Signal Checklist
- Client opens/engages with reports and dashboard updates
- KPIs trending toward or meeting SOW targets
- Client proactively asking questions or requesting more (a positive engagement signal, distinct from a complaint)
- No unresolved Change Requests aging past the SOW's stated turnaround window

## SOW-Governed Delivery Reference (from Service Delivery & Scope Policy)
- Every engagement runs against a signed SOW: objectives, deliverables, included services, explicit exclusions
- Standard deliverables include 2 revision rounds; major deliverables include 3 — additional revisions become a Change Request
- Client feedback on a delivered draft is expected within 5 business days to keep the revision cycle moving
- Anything outside the signed SOW performed without an approved Change Order is explicitly non-billable — protects both sides from scope-creep disputes

## Change Request Process (from Service Delivery & Scope Policy)
1. Client submits request via email to Account Manager
2. Impact assessed against timeline/resources/budget
3. Written Change Order with cost/timeline provided
4. Client written approval required before work begins
5. Change Order integrated into the project plan
