# Checklists — 46 Support and Issue Resolution

[⬅ Back to README](README.md)

## Response-Time QC
- [ ] Emails acknowledged within the committed window (verify current SLA — carried over figure: 4 business hours)
- [ ] WhatsApp/portal messages acknowledged within the committed window (verify current SLA — carried over figure: 2 business hours)
- [ ] Missed calls receive a callback within the committed window (verify current SLA — carried over figure: 1 hour)

## Escalation QC
- [ ] Issue starts at Level 1 (Account Manager) unless genuinely critical
- [ ] Unresolved after 24 hours escalates to Level 2 (Department Head) per policy
- [ ] Persistent or senior-intervention issues escalate to Level 3 (Operations Director)
- [ ] Business-continuity/contractual issues escalate to Level 4 (Managing Director)
- [ ] No level is skipped except for genuinely critical issues that warrant direct Level 4 routing

## Coverage QC
- [ ] Out-of-office auto-notification active during any planned absence, with alternative contact provided
- [ ] Weekend/after-hours coverage matches the client's support tier (if tiered support exists)

## Post-Project Support QC
- [ ] Standard post-project support window honored (verify current policy — carried over figure: 30 days)
- [ ] Extended maintenance package terms match what the client actually purchased, not a default assumption

## Duplicate / Accuracy / Completeness Checks
- [ ] Every support interaction logged against the client record — no channel operates as an untracked silo
