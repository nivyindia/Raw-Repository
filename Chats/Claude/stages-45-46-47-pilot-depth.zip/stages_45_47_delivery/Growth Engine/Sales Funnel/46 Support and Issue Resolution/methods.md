# Methods — 46 Support and Issue Resolution

[⬅ Back to README](README.md)

## Traditional
Ad hoc "email whoever you can reach" support — replaced by named channels, published response-time commitments, and a defined 4-level escalation path.

## Modern / Tool-Assisted
A dedicated client portal messaging system for project-specific support, alongside email (formal) and WhatsApp (time-sensitive) channels.

## AI-Assisted
AI-assisted triage of incoming support messages to route to the correct escalation level/department head based on issue type, before a human responds.

## Manual
Escalation decisions beyond Level 1 (Account Manager) — a human judgment call about whether an issue needs Department Head, Operations Director, or Managing Director involvement.

## Automated
Automatic out-of-office notifications during holidays/planned absences, and automatic response-time SLA tracking so breaches are visible rather than only noticed when a client complains.

## API / Integration
Client portal ⇄ CRM integration so support interactions are logged against the client record, visible alongside delivery/adoption data (Stage 45).

## Browser Automation
Not applicable to this stage.

## Scraping
Not applicable to this stage.

## Public Database / Government
Not applicable to this stage.

## Community / Referral
Not applicable to this stage — support quality is, however, a direct input to whether a client later becomes a referral source (Stage 53) or advocate (Stage 54).

## Method Selection Guidance
Default to Level 1 (Account Manager) for all incoming issues; escalate strictly by the defined time thresholds (24hrs unresolved → Level 2, etc.), never skip levels except for genuinely critical business-continuity issues that go straight to Level 4.
