# Tools — 46 Support and Issue Resolution

[⬅ Back to README](README.md)

_Pricing figures are approximate — verify current pricing before purchase._

| Tool | Purpose | Pricing (approx., verify) | OSS/Free Alt | API/Automation |
|---|---|---|---|---|
| Email (support inbox) | Primary channel for formal requests, approvals, documentation | Low cost (hosting) | Free tier (limited) | API |
| WhatsApp Business | Quick, time-sensitive clarifications | Free–low cost | Free tier | API |
| Client portal (Notion or equivalent) | Project-specific messaging and file sharing | Free–paid, verify current tier pricing | Free tier | API |
| Zoom / Google Meet | Monthly performance review calls | Free–low cost | Free tier | — |
| Phone line | Emergency/urgent contact | Carrier cost | — | — |

## Selection Notes
- Every support channel should log into the same client record (CRM/portal) so escalation history is visible to whoever picks up the issue next — no channel should be a dead-end silo.
