# Templates — 46 Support and Issue Resolution

[⬅ Back to README](README.md)

## Channels of Communication

| Channel | Purpose |
|---|---|
| Email | Formal requests, approvals, documentation |
| WhatsApp Business | Time-sensitive matters, quick clarifications |
| Client portal | Project-specific communication, file sharing |
| Video call (Zoom/Meet) | Monthly performance review |
| Phone line | Emergency/urgent contact |

## Response Time Commitments
_Figures below are carried over from internal reference material — verify current policy before publishing to clients._

| Channel | Target Response Time |
|---|---|
| Email | Within 4 business hours (during working hours) |
| WhatsApp | Within 2 business hours (during working hours) |
| Client portal | Within 4 business hours (during working hours) |
| Phone | Immediate if available; callback within 1 hour if missed |
| After-hours emergency | Response within 2 hours for critical issues |

## Escalation Path

| Level | Contact | Trigger | Target Response |
|---|---|---|---|
| 1 | Account Manager | First point of contact for all service matters | Standard response times above |
| 2 | Department Head | Issue unresolved after 24 hours | Within 8 business hours |
| 3 | Operations Director | Persistent issue or senior intervention needed | Within 24 business hours |
| 4 | Managing Director | Critical business-continuity or contractual concern | Within 48 business hours |

## Post-Project Support Tiers
_Figures below are carried over from internal reference material — verify current pricing/terms before quoting._

| Tier | Coverage | Duration |
|---|---|---|
| Standard (included) | Email support and minor updates | 30 days post-project |
| Basic Maintenance | Email support + minor updates | 3 months (quarterly fee) |
| Standard Maintenance | Priority support, monthly reports, quarterly strategy reviews | 6 months (quarterly fee) |
| Premium Maintenance | Dedicated support, bi-weekly check-ins, ongoing optimization | 12 months (quarterly fee) |

## Out-of-Office Message Template
```
Thanks for your message. I'm currently out of office until [date].

For urgent matters, please contact [alternative contact/channel].
Otherwise, I'll respond as soon as I'm back.
```

## Escalation Request Template (internal)
```
Client: [Name/Company]
Issue: [Short description]
Level 1 response given: [Yes/No + date]
Time unresolved: [X hours/days]
Escalating to: [Level 2/3/4 contact]
Reason for escalation: [persistent / senior judgment needed / business-continuity]
```
