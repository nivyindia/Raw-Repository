# Automation — 46 Support and Issue Resolution

[⬅ Back to README](README.md)

## Manual
Escalation beyond Level 1 and any judgment call about issue severity — never auto-escalated without human confirmation, to avoid over-alarming senior staff on routine matters.

## Semi-Automated
Response-time SLA tracked automatically (time since client message received); the reply itself is human-authored.

## Full-Automated
Out-of-office auto-notifications during planned absences; automatic SLA-breach flagging when a response-time commitment is about to be missed.

## AI-Assisted Workflow
1. Client message arrives via any channel (email/WhatsApp/portal/phone).
2. AI-assisted triage classifies issue type and suggests the correct department/escalation level.
3. Account Manager (Level 1) responds within the committed window, or escalates per the defined thresholds if unresolved.
4. Resolution logged against the client record, feeding back into Stage 45's adoption-health signals.

## Suggested n8n / integration flow
`Incoming message (any channel) → AI triage/classification → Route to Level 1 (Account Manager) → SLA timer starts → If unresolved past threshold: auto-escalate to next level → Resolution logged → Stage 45 adoption record updated`
