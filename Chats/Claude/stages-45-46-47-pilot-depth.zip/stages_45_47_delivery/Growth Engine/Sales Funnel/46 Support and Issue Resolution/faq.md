# FAQ — 46 Support and Issue Resolution

[⬅ Back to README](README.md)

**Q: What's the first point of contact for any client issue?**
The client's dedicated Account Manager (Level 1) — all service-related matters route there first, per the source guide.

**Q: When does an issue escalate beyond the Account Manager?**
If it remains unresolved after 24 hours, it escalates to the relevant Department Head (Level 2). Persistent issues go further to Operations Director (Level 3), and critical business-continuity or contractual matters go to Managing Director (Level 4).

**Q: Are the specific response-time figures (4 hours for email, etc.) fixed policy?**
They're carried over from internal reference material as a starting point — verify they're still current company policy before publishing them as a client-facing commitment.

**Q: What support is included after a project ends, and what costs extra?**
30 days of complimentary support is standard; anything beyond that (Basic/Standard/Premium Maintenance packages) is a paid add-on with different coverage levels — verify current pricing before quoting.

**Q: How does this stage relate to Stage 45 Product and Service Adoption?**
Stage 45's adoption-health signals can flag a remediation review that routes here; conversely, how well an issue is resolved here feeds back into the client's adoption-health record.
