# Tools — 47 Upsell Identification

[⬅ Back to README](README.md)

_Pricing figures are approximate — verify current pricing before purchase._

| Tool | Purpose | Pricing (approx., verify) | OSS/Free Alt | API/Automation |
|---|---|---|---|---|
| Client delivery tracker (Notion/CRM) | Log every upsell trigger check and attempt | Free–paid, verify current tier pricing | Free tier | API |
| Google Analytics / GA4 | Monitor traffic-growth triggers (SEO, content) | Free | Free | API |
| Meta Ads Manager | Monitor ROAS/CPL triggers (performance marketing) | Free (platform), spend separate | — | API |
| CRM (HubSpot or equivalent) | Track booking-rate and revenue triggers (lead gen, CPA) | Free–paid tier | Free tier | Native |

## Selection Notes
- Trigger monitoring should pull from the same dashboards used for Stage 45 adoption reporting — a strong adoption signal and an upsell trigger are often the same underlying data viewed from a different angle.
