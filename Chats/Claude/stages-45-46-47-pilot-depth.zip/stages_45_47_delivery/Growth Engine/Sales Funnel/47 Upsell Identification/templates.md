# Templates — 47 Upsell Identification

[⬅ Back to README](README.md)

## Core Rule
**Never pitch an upsell before the trigger moment.** A client who hasn't seen results yet will reject any upsell. A client who has seen results will often say yes without much prompting.

## How to Use the Trigger System
1. Find the client's current package in the master trigger table
2. Check trigger conditions — are any true?
3. If yes, use the matching script cue
4. Log the upsell attempt in the client delivery tracker
5. If client says yes → hand off to Closer immediately

## Master Upsell Trigger Table (by Service Line)

### Social Media Management (SMM)
| Trigger | Timing | Upsell To |
|---|---|---|
| Follower growth > 20% in 60 days | Month 2 report | SMM L2 |
| Client asks "can we do more posts?" | Any time | SMM L2 or L3 |
| Client mentions running ads | Any time | Performance Marketing |
| 3 months consistent delivery, satisfied | Month 3 review | SMM L2 |

### Content Creation
| Trigger | Timing | Upsell To |
|---|---|---|
| Client says "we need more reels" | Any time | Content L2 |
| Reels consistently 5K+ views | Month 2 | Content L2 + SMM |
| Client wants to post daily | Any time | Content L2 |

### Performance Marketing (Ads)
| Trigger | Timing | Upsell To |
|---|---|---|
| ROAS > 3x for 4 straight weeks | Month 2 report | Perf Mktg L2/L3 |
| Client asks about Google Ads | Any time | Perf Mktg L2/L3 |
| CPL improving month-on-month | Month 3 | L3 System |
| Client expanding to new city/product | Any time | L3 System |

### SEO
| Trigger | Timing | Upsell To |
|---|---|---|
| First keywords entering top 50 | Month 3 report | SEO L2 |
| Client asks about blog posts | Any time | SEO L2 |
| Organic traffic growing > 30% | Month 3 | SEO L2 |

### Lead Generation (Outreach)
| Trigger | Timing | Upsell To |
|---|---|---|
| Booking rate > 5% consistently | Month 2 | Lead Gen L2 |
| Client asks about international outreach | Any time | Lead Gen L2/Custom |
| Client wants a CRM | Any time | Lead Gen L2 + CRM |

### CPA (Financial Management)
| Trigger | Timing | Upsell To |
|---|---|---|
| Monthly revenue exceeds a defined threshold (verify current figure) | Month 3 MIS | CPA Growth |
| Client hiring employees | Any time | CPA Scale |
| Client asks about tax savings | Any time | CPA CFO |
| 2+ compliance notices | After 2nd notice | CPA Scale/CFO |
| Client profitable and growing fast | Quarter review | CPA CFO |

## Cross-Sell Trigger Combinations
| Client Has | Add | Why |
|---|---|---|
| SMM only | Content Creation | Content fuels social; they compound |
| Ads only | Lead Gen | Paid + organic outreach = full pipeline |
| Ads + SMM | SEO | Captures long-term search intent alongside paid |
| Lead Gen | CPA | Clients closing deals need clean books |
| Any marketing package | CPA Starter | Every growing business needs compliance |

## Upsell Attempt Log Fields
`Date` · `Client Name` · `Current Package` · `Upsell Pitched` · `Trigger Used` · `Response` (Interested/Not Now/No/Closed) · `Next Step`

## Handoff Rule
> If a client expresses interest in an upsell, do not try to close it yourself. Hand off to the Closer immediately. Your job is to identify the trigger and open the conversation — not close it.
