# Automation — 47 Upsell Identification

[⬅ Back to README](README.md)

## Manual
The upsell conversation itself, and the decision to hand off an interested client to the Closer — never auto-closed by the person who identified the trigger.

## Semi-Automated
Trigger-condition monitoring is automated (dashboard/API-fed); the rep manually confirms the trigger is genuine before using the script cue.

## Full-Automated
Standing monitoring of delivery metrics against each service line's trigger table, flagging a candidate the moment a threshold (e.g., ROAS > 3x for 4 weeks, follower growth > 20% in 60 days) is crossed.

## AI-Assisted Workflow
1. Delivery metrics (Stage 42/45) feed the trigger-monitoring system continuously.
2. When a threshold is met, the system flags the client and surfaces the matching script cue from the master trigger table.
3. Account Manager/VA confirms the trigger is genuine and opens the conversation using the script cue.
4. If the client expresses interest, immediate handoff to the Closer — the person who identified the trigger does not close it themselves.
5. Attempt logged in the client delivery tracker regardless of outcome.

## Suggested n8n / integration flow
`Delivery metrics (GA4/Ads/CRM) → Trigger-condition check against master table → Flag + script cue surfaced → Rep opens conversation → Interested? → Handoff to Closer → Log attempt`
