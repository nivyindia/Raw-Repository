# 47 Upsell Identification

> **Stage 47 of 54** in the International B2B Sales Funnel Knowledge Base.
> Status: ✅ **Populated to pilot depth** (Batch 7, Session 10).

---

## Navigation

- ⬅ Previous stage: [46 Support and Issue Resolution](../46 Support and Issue Resolution/README.md)
- ➡ Next stage: [48 Cross Sell Strategy](../48 Cross Sell Strategy/README.md)
- 🏠 [Funnel home](../README.md)
- Files in this folder: [methods.md](methods.md) · [tools.md](tools.md) · [automation.md](automation.md) · [checklists.md](checklists.md) · [templates.md](templates.md) · [resources.md](resources.md) · [faq.md](faq.md) · [references.md](references.md)

---

## 1. Stage Overview

**Objective:** Identify the precise, results-backed moment a client is ready for an expanded package — using a per-service-line master trigger table — and open the conversation with the matching script cue, handing off any interested client to the Closer immediately.

**Purpose:** Upselling on a fixed calendar schedule regardless of results gets rejected; upselling the moment a client has genuinely seen results converts easily. This stage exists to replace guesswork with an observable, per-service trigger table, so upsell timing is evidence-based rather than a rep's gut feel or a rigid month-count.

**Inputs:**
- Delivery metrics per service line (follower growth, ROAS, keyword rankings, booking rate, revenue) from Stage 42/45
- The client's current package

**Outputs:**
- A flagged, trigger-validated upsell opportunity with the matching script cue
- A logged attempt in the client delivery tracker
- Interested clients handed off to the Closer for Stage 33-37's proposal/negotiation/close process on the expanded scope

**Expected Result:** Upsell conversations only happen when a genuine trigger condition is met, conversion is high because the client has already seen results, and every attempt (successful or not) is logged for tracking and follow-up.

---

## 2. Complete Sub-Stages

| Sub-Stage | Description |
|---|---|
| **47A** Trigger Monitoring | Continuous check of delivery metrics against the per-service-line trigger table |
| **47B** Trigger Validation | Confirming a flagged condition is genuine before opening the conversation |
| **47C** Script-Cue Conversation | Opening with the trigger-matched script, not a generic upsell pitch |
| **47D** Cross-Sell Trigger Check | Package-combination opportunities (e.g., SMM-only → add Content Creation) |
| **47E** Handoff & Logging | Immediate handoff to Closer on interest; attempt logged regardless of outcome |

---

## 3. Complete Methods

See [methods.md](methods.md).

---

## 4. Complete Website Library

No external website library — see [resources.md](resources.md) and [tools.md](tools.md).

---

## 5. Complete Tool Library

See [tools.md](tools.md).

---

## 6. Automation

See [automation.md](automation.md).

---

## 7. AI Section

**How AI can help:**
- Continuous automated monitoring of delivery metrics against each service line's trigger thresholds, flagging candidates the moment a condition is met
- Surfacing the correct script cue automatically alongside a flagged trigger, so the rep doesn't have to look it up manually

**Prompt examples:**
```
"Here is this client's Month 2 performance data: [paste]. Check it
against the SMM and Performance Marketing trigger tables and flag any
condition that's been met, along with the matching script cue."
```

**Agent workflows:** An agent can monitor metrics and flag triggers automatically, but the actual conversation and any closing activity remain human — per the source system's explicit rule that the trigger-identifier hands off to a Closer rather than closing it themselves.

**RAG / vector database considerations:** Not required — the trigger table is small and structured enough for direct rule-based matching.

**LLM recommendations:** Standard current-generation models are sufficient for trigger-matching and script-cue retrieval.

**Automation opportunities:** See [automation.md](automation.md).

---

## 8. Data Structure

### Upsell attempt fields (mandatory)
`Client ID` · `Date` · `Current Package` · `Service Line` · `Trigger Used` · `Upsell Pitched` · `Response` (Interested/Not Now/No/Closed) · `Next Step`

### JSON schema
```json
{
  "client_id": "string",
  "date": "ISO 8601 date",
  "current_package": "string",
  "service_line": "smm|content|performance_marketing|seo|lead_gen|cpa",
  "trigger_used": "string",
  "upsell_pitched": "string",
  "response": "interested|not_now|no|closed",
  "next_step": "string"
}
```

### Validation rules
- `upsell_pitched` must map to an actual row in the master trigger table for the given `service_line` — no ad hoc pitches logged as trigger-based
- `response: interested` requires an immediate handoff to the Closer logged as the `next_step`, not a self-close attempt
- `response: not_now` requires a follow-up date in `next_step`

### Naming conventions
- `service_line` is a fixed enum matching the six trigger-table categories in [templates.md](templates.md)

---

## 9. Quality Control

See [checklists.md](checklists.md). Summary gates:
- [ ] Trigger genuinely met before any pitch — never pre-results
- [ ] Correct script cue used for the matched trigger
- [ ] Interested clients handed off to Closer immediately, not self-closed
- [ ] Every attempt logged regardless of outcome

---

## 10. KPIs

| Metric | Benchmark | Notes |
|---|---|---|
| Trigger-to-pitch accuracy | 100% — no pre-trigger pitches | Core rule violation risk if not enforced |
| Trigger-to-interested conversion rate | Track and trend | Should be materially higher than untimed/calendar-based upsell attempts |
| Attempt logging completeness | 100% | Required for trigger-effectiveness reporting over time |

---

## 11. Templates

See [templates.md](templates.md).

## 12. Resources

See [resources.md](resources.md).

## 13. References

See [references.md](references.md).

---

## Cross-References

- **Previous stage:** [46 Support and Issue Resolution](../46 Support and Issue Resolution/README.md)
- **Next stage:** [48 Cross Sell Strategy](../48 Cross Sell Strategy/README.md)
- **Depends on:** [45 Product and Service Adoption](../45 Product and Service Adoption/README.md) (delivery/results data)
- **Feeds:** [48 Cross Sell Strategy](../48 Cross Sell Strategy/README.md), [33 Proposal Creation](../33 Proposal Creation/README.md) through [37 Closing Techniques](../37 Closing Techniques/README.md) (for the expanded-scope deal)

> **Source note:** Built directly from the internal "Upsell Trigger System" doc, which is already a complete, comprehensive playbook covering per-service-line trigger tables, cross-sell trigger combinations, logging format, and the explicit handoff-to-Closer rule.

[⬅ Back to README](README.md)
