# Checklists — 47 Upsell Identification

[⬅ Back to README](README.md)

## Trigger-Validity QC
- [ ] Client has demonstrably seen results before any upsell is pitched — never pitch pre-results, per the system's core rule
- [ ] Trigger condition matches an actual entry in the master trigger table for that service line, not an ad hoc judgment call
- [ ] Correct script cue used for the matched trigger

## Conversation QC
- [ ] Upsell opened, not force-closed, by the person who identified the trigger
- [ ] Interested client handed off to the Closer immediately — the identifier does not attempt to close it themselves

## Cross-Sell QC
- [ ] Package-combination cross-sell triggers (e.g., SMM-only client → Content Creation) checked in addition to same-line upsell triggers
- [ ] Cross-sell rationale communicated (why the two services compound), not just offered as an add-on

## Logging QC
- [ ] Every upsell attempt logged in the client delivery tracker: date, client, current package, upsell pitched, trigger used, response, next step
- [ ] "Interested" responses have a clear next step (handoff to Closer) or follow-up date logged

## Duplicate / Accuracy / Completeness Checks
- [ ] No client has two conflicting open upsell attempts logged simultaneously without a clear owner
