# References — 47 Upsell Identification

[⬅ Back to README](README.md)

## Internal Sources
- Upsell Trigger System (Growth Engine) — primary and comprehensive source: master trigger table by service line, cross-sell trigger combinations, logging format, and the handoff-to-Closer rule
- Sell → Upsell → Cross-Sell Playbook (Growth Engine) — supplementary strategic framing, referenced for Stage 48

## Official / Vendor Docs
- None specific to this stage

> Trigger thresholds (follower growth %, ROAS multiples, revenue figures) are carried over directly from internal reference material dated April 2026 — verify current thresholds with leadership before relying on the specific numbers.
