# Methods — 47 Upsell Identification

[⬅ Back to README](README.md)

## Traditional
Upselling attempted on a fixed calendar schedule (e.g., "always pitch at month 3") regardless of whether the client has actually seen results — explicitly rejected by the source system's core rule.

## Modern / Tool-Assisted
A master trigger table per service line (SMM, Content, Performance Marketing, SEO, Lead Gen, CPA) mapping specific, observable conditions to a specific upsell offer and script cue.

## AI-Assisted
AI-assisted monitoring of client delivery metrics (follower growth, ROAS, keyword rankings, booking rate, revenue) to flag when a trigger condition has been met, rather than relying on a rep remembering to check.

## Manual
The actual upsell conversation and handoff decision — the trigger identifies the moment, but delivering the script cue and reading the client's response is a human skill.

## Automated
Automatic trigger-condition monitoring against delivery dashboards (Stage 42/45), surfacing a flagged upsell opportunity the moment a threshold is crossed.

## API / Integration
Analytics/ad-platform APIs (GA4, Meta Ads Manager) and CRM data feeding the trigger-monitoring system so conditions like "ROAS > 3x for 4 straight weeks" are checked against real data, not estimated.

## Browser Automation
Not applicable to this stage.

## Scraping
Not applicable to this stage.

## Public Database / Government
Not applicable to this stage.

## Community / Referral
Not applicable directly to upsell identification, though a client who accepts an upsell is a stronger candidate for later referral (Stage 53) and advocacy (Stage 54).

## Method Selection Guidance
Never pitch before a trigger condition is genuinely met — the source system's core rule is explicit that premature upselling to a client who hasn't seen results gets rejected, while a results-backed trigger converts with little resistance.
