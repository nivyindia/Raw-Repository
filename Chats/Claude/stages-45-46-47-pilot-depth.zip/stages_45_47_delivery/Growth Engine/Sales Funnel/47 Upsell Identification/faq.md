# FAQ — 47 Upsell Identification

[⬅ Back to README](README.md)

**Q: What's the single most important rule in this stage?**
Never pitch an upsell before the trigger moment. Per the source system, a client who hasn't seen results yet will reject the upsell; a client who has will often say yes without much prompting.

**Q: Who closes an upsell once a client expresses interest?**
Not the person who identified the trigger — they hand off to the Closer immediately. The identifier's job is spotting the trigger and opening the conversation, not closing.

**Q: How is this different from Stage 48 Cross Sell Strategy?**
Stage 47 covers identifying and acting on same-service-line expansion triggers (e.g., SMM client hitting a follower-growth threshold → SMM L2) plus the package-combination cross-sell triggers. Stage 48 covers the broader strategic approach to cross-selling across the client base, not just individual trigger-spotting.

**Q: What happens if a rep spots a trigger but the client says "not now"?**
Log it as "Not Now" with a follow-up date — the trigger table doesn't force a close, and a declined upsell isn't a dead end, just a timing mismatch.

**Q: Are the specific thresholds (20% follower growth, ROAS > 3x, etc.) fixed?**
They're carried over from internal reference material — verify they're still current before using them as the literal trigger criteria, particularly the CPA revenue threshold which wasn't fully specified in the source.
