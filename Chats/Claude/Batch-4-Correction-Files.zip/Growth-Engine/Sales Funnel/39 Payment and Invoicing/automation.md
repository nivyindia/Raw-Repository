# Automation — 39 Payment and Invoicing

> Part of Stage 39 (Payment and Invoicing). See [README.md](README.md) for the stage overview.

For each sub-stage below: manual → semi-automated → fully automated → AI-assisted workflow, required tools/APIs, expected output, common errors, recovery.

---

## 1. Payment Structure Selection & Invoice Generation (39A–39B)

| Level | Workflow |
|---|---|
| **Manual** | Whoever handles billing looks at the signed contract, works out the correct structure (project/retainer/quarterly/annual/media-buying) by hand, and builds the invoice from a blank template. |
| **Semi-automated** | Contract type (Stage 36) selects a matching invoice template in the invoicing tool; billing period, line items, and tax treatment are still entered by hand each time. |
| **Fully automated** | Contract signature webhook (Stage 36) → n8n reads the deal's payment structure and pricing straight from the CRM/contract record → invoice is generated automatically in the invoicing tool (Zoho Invoice/QuickBooks/Wave) via API with sequential numbering, correct billing period, and tax treatment applied per the client's billing country. |
| **AI-assisted** | An LLM step cross-checks the generated invoice's line items and total against the signed contract/proposal (and any approved Deal Desk deviation from Stage 38) before it's released, flagging any mismatch instead of assuming the template populated correctly. |

**Required:** Invoicing tool with API access (Zoho Invoice, QuickBooks, Wave, or Odoo Invoicing) · n8n/Zapier/Make for the contract-signed trigger · CRM API access to pull contract terms.
**Expected output:** a sequentially-numbered, correctly-taxed invoice matching the exact contract/approved terms, generated with no manual re-entry of pricing.
**Common errors:** invoice generated from the *standard* pricing template when a Deal Desk deviation (Stage 38) was actually approved, silently overcharging or undercharging the client (recovery: the generation step must read the approved-terms field, not just the contract's original line, per the Stage 38 cross-stage note); GST/tax-ID missing for a client whose invoice requires it (recovery: block invoice generation until the client billing-details record has a populated tax field for jurisdictions that require one).

**n8n template reference:** "Airtable to Google Sheets Auto-Sync" (adapted for the Airtable-based billing tracker → Sheets reconciliation pattern) plus a Stripe/Odoo webhook pattern for payment-confirmation triggers — see [N8N-AUTOMATION-INDEX.md § Reference collection](../N8N-AUTOMATION-INDEX.md) for the source collection. *(Verify link resolves before relying on it — template names on n8n.io/community collections change.)*

---

## 2. Invoice Delivery & Payment Collection (39C–39D)

| Level | Workflow |
|---|---|
| **Manual** | Billing person emails the invoice PDF as an attachment, manually checks the bank account or payment gateway daily to see if it landed. |
| **Semi-automated** | Invoicing tool sends the invoice automatically on generation, but payment status is still checked manually against the bank/gateway. |
| **Fully automated** | Invoice delivery triggers automatically on generation via the invoicing tool's native send function; a payment gateway webhook (Stripe/Razorpay/PayPal) or bank-feed integration pushes a payment-received event straight into the CRM/invoicing tool, updating invoice status without anyone checking a statement. |
| **AI-assisted** | Not typically needed at this step — delivery and payment-confirmation are structured, event-driven tasks; an LLM adds little value beyond what a webhook already does deterministically. |

**Required:** Payment gateway with webhook support (Stripe, Razorpay, PayPal, Wise) · invoicing tool's native send/delivery function · webhook receiver (n8n) to update CRM/invoice status.
**Expected output:** invoice delivered to the correct billing contact within minutes of generation; payment status auto-updated the moment funds clear, not on the next manual check.
**Common errors:** invoice sent to a generic company inbox instead of the actual billing contact captured in Stage 40 onboarding data (recovery: pull the send-to address from the client's verified billing-contact field, not the primary CRM contact by default); webhook silently fails and payment sits unreconciled for days (recovery: alert on any invoice still "Sent" past its due date rather than assuming the webhook worked).

---

## 3. Reconciliation (39E)

| Level | Workflow |
|---|---|
| **Manual** | Someone manually matches a bank statement line to an outstanding invoice and marks it paid in a spreadsheet. |
| **Semi-automated** | Payment gateway shows the transaction; a person still manually finds the matching invoice and updates its status. |
| **Fully automated** | Gateway/bank-feed webhook includes enough metadata (invoice number in the payment reference, or gateway-side invoice linkage) to auto-match and mark the correct invoice "Paid" with no manual lookup. |
| **AI-assisted** | For payments that arrive with mismatched or missing references (a common real-world problem with wire transfers), an LLM step compares the paid amount and payer name against outstanding invoices to suggest the most likely match for a human to confirm, rather than leaving it in an unmatched queue indefinitely. |

**Required:** Gateway/bank feed with reference-metadata support · n8n matching logic · optional LLM fallback-matching step for ambiguous wires.
**Expected output:** every incoming payment matched to exactly one invoice with no manual spreadsheet reconciliation for the majority case.
**Common errors:** partial payments (client pays 90% of an invoice) auto-marked "Paid" instead of "Partially Paid," hiding a real shortfall (recovery: matching logic must compare amount paid to amount due exactly, not just "a payment arrived"); duplicate matching when a client accidentally pays twice (recovery: flag, don't auto-close, any payment that would fully match an invoice already marked Paid).

---

## 4. Overdue Management & Recurring Billing (39F–39G)

| Level | Workflow |
|---|---|
| **Manual** | Someone checks which invoices are overdue and writes a one-off follow-up message each time. |
| **Semi-automated** | A scheduled report lists overdue invoices; reminder messages are AI-drafted per the escalating cadence but a human sends each one. |
| **Fully automated** | A scheduled n8n workflow checks invoice due dates daily, and at each cadence milestone (e.g., day 3, day 7, day 14 overdue) automatically sends the corresponding reminder template and applies any policy-defined late fee — no manual tracking of who's overdue and by how much. |
| **AI-assisted** | An LLM drafts each reminder's tone calibrated to lateness (polite nudge at day 3, firmer at day 14, referencing the applicable late fee) using the client's name/invoice details, and flags any account crossing the "service suspension" threshold for a human decision rather than auto-suspending. |

**Required:** n8n scheduled trigger · invoicing tool API for due-date/status checks · LLM step for reminder drafting · CRM flag for the human-reviewed suspension decision.
**Expected output:** a consistent, non-awkward reminder cadence running with no manual daily tracking, and every recurring-billing client re-invoiced automatically at each cycle without anyone remembering to do it by hand.
**Common errors:** recurring billing re-invoicing at the wrong cadence after a mid-contract term change (recovery: recurring-billing schedule must read from the current contract record, not a one-time-set-and-forget schedule); reminder cadence firing after a client has *already* paid because reconciliation (39E) lagged the reminder check (recovery: the overdue-check step must re-verify current status immediately before sending, not rely on a stale nightly snapshot).

---

## Cross-Stage Automation Note

Invoice generation (39B) depends on Stage 38's approved-terms field for any deal with a logged deviation, and reconciliation (39E) feeds directly into Stage 40's onboarding trigger ("contract signed + payment confirmed") — so the payment-confirmed event from this stage should be a single, reusable webhook that both closes the invoice loop here and fires Stage 40, not two separately-maintained triggers.

## Recovery Principles (General)

- **Never let a document silently revert to standard terms** — invoice generation must always check for an approved deviation (Stage 38) before defaulting to the standard template.
- **Distinguish "a payment arrived" from "the correct payment arrived"** — auto-matching without an amount check turns partial payments and duplicate payments into silent data-integrity problems.
- **Alert on stalled automation, don't assume success** — an invoice stuck in "Sent" past due date is a signal the webhook chain broke, not evidence the client is simply slow.

---

## Cross-References

- Stage README: [README.md](README.md)
- Sub-stages referenced above: [README.md § 2](README.md#2-complete-sub-stages)
- Tools referenced above: [tools.md](tools.md)
- Deal Desk approved-terms dependency: [38 Deal Desk and Approval Workflows](../38 Deal Desk and Approval Workflows/automation.md)
- Feeds into: [40 Client Onboarding](../40 Client Onboarding/automation.md)
- Previous stage: [38 Deal Desk and Approval Workflows](../38 Deal Desk and Approval Workflows/README.md)
- Next stage: [40 Client Onboarding](../40 Client Onboarding/README.md)
