# Automation — 40 Client Onboarding

> Part of Stage 40 (Client Onboarding). See [README.md](README.md) for the stage overview.
> Flagged in [N8N-AUTOMATION-INDEX.md](../N8N-AUTOMATION-INDEX.md) as the highest-ROI n8n build in the 54-stage funnel — this is the stage with the most fan-out (portal, Drive, notifications, questionnaire, CSAT) from a single trigger.

For each sub-stage below: manual → semi-automated → fully automated → AI-assisted workflow, required tools/APIs, expected output, common errors, recovery.

---

## 1. Onboarding Trigger & Welcome Sequence (40A–40B)

| Level | Workflow |
|---|---|
| **Manual** | Someone notices a contract was signed and payment landed, then manually sends a welcome email and pings the account manager to reach out. |
| **Semi-automated** | CRM lifecycle-stage change to "Customer" is manual (someone flips it), but once flipped, a templated welcome email sends automatically. |
| **Fully automated** | Stage 39's payment-confirmed webhook fires the onboarding trigger directly — CRM lifecycle stage updates automatically, welcome email sends, and a WhatsApp message queues for the assigned account manager, all from the same event with no manual flag-flipping. |
| **AI-assisted** | An LLM drafts the account manager's WhatsApp message using the client's name and package details so it reads as a genuinely personal note rather than an obvious template — the AM reviews/sends it, since a message that's *supposed* to feel personal shouldn't be fully auto-sent. |

**Required:** CRM with lifecycle-stage automation (HubSpot workflow or n8n) · webhook from Stage 39's payment-confirmed event · WhatsApp Business API or manual-send queue for the AM's message.
**Expected output:** onboarding fires within minutes of payment confirmation, with zero manual triggering and the client hearing from a human-feeling channel (not just an automated email) within the same day.
**Common errors:** onboarding trigger fires on contract signature alone, before payment actually clears, starting delivery work for an unpaid deal (recovery: gate the trigger on the payment-confirmed event specifically, not the earlier contract-signed event); AI-drafted WhatsApp message sent without AM review and reading as obviously generated (recovery: keep this one send point human-reviewed even though everything around it is automated).

---

## 2. Questionnaire, Business Info & Access Collection (40C–40E)

| Level | Workflow |
|---|---|
| **Manual** | AM emails a Google Doc questionnaire and chases the client by memory until it's returned. |
| **Semi-automated** | A structured form (Typeform/Google Forms) auto-sends on trigger, but reminders for incomplete submissions are sent manually. |
| **Fully automated** | Questionnaire sends automatically on trigger; if not completed within 48 hours, an n8n scheduled check fires an automatic reminder — no one has to track completion status by hand. Access-collection requests (analytics, ad accounts, CMS, social) are itemized per the specific service purchased, pulled from a service-type-to-access-checklist mapping rather than a single generic list. |
| **AI-assisted** | An LLM parses free-text questionnaire answers (business description, competitors, current marketing) into the structured fields the internal team brief needs, catching information even when the client didn't format their answer the way the form expected. |

**Required:** Typeform/Google Forms/Tally with webhook support · n8n for the 48-hour reminder check · a service-type → required-access checklist mapping (maintained per package) · LLM step for free-text parsing.
**Expected output:** a complete questionnaire response plus the *correct* set of access requests for the specific service purchased — not a generic access list that asks for things the engagement doesn't need.
**Common errors:** access-collection request sent as one generic list regardless of service purchased, confusing clients and slowing delivery (recovery: itemize the request against the service-type mapping, not a single static template); reminder logic re-sends the full form link even after partial completion, frustrating the client (recovery: reminder should link back to the client's in-progress response, not restart it).

---

## 3. Asset Collection & Portal/Workspace Setup (40F–40G)

| Level | Workflow |
|---|---|
| **Manual** | AM manually creates a new Notion page and Google Drive folder from scratch for each client, copying structure from a previous one by hand. |
| **Semi-automated** | A Notion/Drive template exists and is manually duplicated per client, then manually renamed and shared. |
| **Fully automated** | On trigger, n8n calls the Notion API to duplicate the client-portal template and the Google Drive API to create the folder structure from a template, renames both to the client name automatically, and shares access with the client's billing-contact email — with no manual duplication step. |
| **AI-assisted** | Not typically needed — portal/folder creation is a deterministic templating task; an LLM adds no meaningful value over direct API templating here. |

**Required:** Notion API (or equivalent client-portal tool) · Google Drive API · n8n for the duplicate-and-rename-and-share sequence.
**Expected output:** a fully structured, correctly-named, correctly-shared client portal and asset folder existing before the client's first question arrives — with zero manual folder-building.
**Common errors:** portal shared with the wrong contact email (internal AM email instead of the client's) because the sharing step used a hardcoded field instead of the verified billing-contact field (recovery: pull the share-to address from the same verified contact record Stage 39 uses for invoicing); template drift where someone edits the "live" template folder instead of a locked master, breaking future duplications (recovery: lock the master template and version it explicitly).

---

## 4. Internal Team Briefing & Day 7 Satisfaction Check (40H–40I)

| Level | Workflow |
|---|---|
| **Manual** | AM manually writes up a brief for the delivery team after reading through the questionnaire themselves. |
| **Semi-automated** | Questionnaire answers are manually copied into a Slack message to the delivery team. |
| **Fully automated** | Internal ops channel notification (with a standard onboarding checklist) fires automatically the moment the trigger event happens — before the questionnaire is even back — so the team is briefed on *that a new client exists* immediately, independent of the brief content. Day 7 CSAT survey dispatch and low-score alerting run entirely on a scheduled trigger with no manual tracking of which client is on day 7. |
| **AI-assisted** | Once the questionnaire is submitted, an LLM drafts a 1-page internal team brief (business context, service specifics, key contacts, anything unusual flagged) for the AM to review and forward — turning raw questionnaire data into something the delivery team can act on in under a minute of reading. |

**Required:** Slack/Telegram API for ops notifications · n8n scheduled trigger for Day 7 CSAT · CSAT survey tool (Typeform/native CRM survey) · LLM step for the team-brief draft.
**Expected output:** the delivery team knows a new client exists before the client's first message arrives, has a usable brief once the questionnaire is in, and every client gets a Day 7 pulse-check with no manual date-tracking.
**Common errors:** Day 7 CSAT survey scheduled from contract-signed date instead of onboarding-trigger date, landing before the client has actually experienced anything yet (recovery: anchor the Day 7 timer to the onboarding-trigger event specifically); low CSAT score logged but no actual alert fires because the threshold check was never wired up (recovery: treat "alert AM on low score" as its own tested automation step, not an assumed side-effect of collecting the score).

**n8n template reference:** "Streamline Client Onboarding with PDF, Trello, Slack, Gmail and Airtable" — adapt the multi-tool fan-out pattern (notify + create + collect) to this stage's Notion/Drive/Slack stack. See [N8N-AUTOMATION-INDEX.md § Reference collection](../N8N-AUTOMATION-INDEX.md). *(Verify link resolves before relying on it.)*

---

## Cross-Stage Automation Note

The single trigger event that opens this stage (Stage 39's payment-confirmed webhook) should fan out to every sub-stage above from one workflow run, not five separately-triggered automations — that's what makes this the highest-ROI n8n build in the funnel: one reliable trigger, many parallel automated branches, versus the previous state of five to seven manual steps each waiting on someone to remember them.

## Recovery Principles (General)

- **Gate the trigger on payment, not just signature** — starting onboarding (and delivery-team time) on an unpaid contract is the single costliest failure mode in this stage.
- **Personal-feeling touchpoints (the AM's WhatsApp message) stay human-reviewed** even when everything structural around them is automated — automation should remove busywork, not the relationship signal that this stage exists to create.
- **Anchor all downstream timers (Day 7 CSAT, reminder cadences) to the actual trigger event**, not to an earlier or assumed date, or the whole cadence silently drifts.

---

## Cross-References

- Stage README: [README.md](README.md)
- Sub-stages referenced above: [README.md § 2](README.md#2-complete-sub-stages)
- Tools referenced above: [tools.md](tools.md)
- Trigger source: [39 Payment and Invoicing](../39 Payment and Invoicing/automation.md)
- Feeds into: [41 Kickoff and Expectation Setting](../41 Kickoff and Expectation Setting/automation.md)
- Previous stage: [39 Payment and Invoicing](../39 Payment and Invoicing/README.md)
- Next stage: [41 Kickoff and Expectation Setting](../41 Kickoff and Expectation Setting/README.md)
