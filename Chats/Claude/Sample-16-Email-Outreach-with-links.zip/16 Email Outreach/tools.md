# Tools — 16 Email Outreach

[⬅ Back to README](README.md)

_Pricing figures are approximate — verify current pricing before purchase._

| Tool | Purpose | Pricing (approx., verify) | OSS/Free Alt | API/Automation |
|---|---|---|---|---|
| [Instantly.ai](https://instantly.ai) | Cold email sequencing, mailbox rotation, deliverability warm-up | ~$37-97/mo | No direct match in the declared OSS stack (Odoo/Mautic/Documenso/NocoDB-Baserow/Ollama) — evaluate case-by-case rather than force-fit | API + native integrations |
| [Apollo.io](https://www.apollo.io) | Sequencing + contact database in one tool | ~$49-99/user/mo | No OSS equivalent for paid contact/lead databases — stack free tiers (e.g. [Hunter.io](https://hunter.io) 25/mo, [Snov.io](https://snov.io) free tier) instead of one paid tool | API |
| [Lemlist](https://www.lemlist.com) | Sequencing with personalized images/video | ~$39-99/mo | No direct match in the declared OSS stack (Odoo/Mautic/Documenso/NocoDB-Baserow/Ollama) — evaluate case-by-case rather than force-fit | API |
| [Google Workspace](https://workspace.google.com) / [Microsoft 365](https://www.microsoft.com/microsoft-365) | Sending mailbox infrastructure | ~$6-12/user/mo | No direct match in the declared OSS stack (Odoo/Mautic/Documenso/NocoDB-Baserow/Ollama) — evaluate case-by-case rather than force-fit | Gmail/Graph API |
| [Mailwarm](https://www.mailwarm.com) / [Warmup Inbox](https://www.warmupinbox.com) | Automated inbox warm-up | ~$15-30/mo | No direct match in the declared OSS stack (Odoo/Mautic/Documenso/NocoDB-Baserow/Ollama) — evaluate case-by-case rather than force-fit | Limited |
| [Hunter.io](https://hunter.io) Email Verifier | Bounce-risk verification before send | Free tier + paid | [check-if-email-exists](https://github.com/reacherhq/check-if-email-exists) (OSS CLI/API, self-hosted SMTP verification) | API |
| [NeverBounce](https://www.neverbounce.com) | Bulk email verification | Pay-per-verify | [check-if-email-exists](https://github.com/reacherhq/check-if-email-exists) (OSS CLI/API, self-hosted SMTP verification) | API |
| [Google Postmaster Tools](https://postmaster.google.com) | Domain reputation/spam-rate monitoring (Gmail) | Free | No direct match in the declared OSS stack (Odoo/Mautic/Documenso/NocoDB-Baserow/Ollama) — evaluate case-by-case rather than force-fit | Limited API |
| [MXToolbox](https://mxtoolbox.com) | SPF/DKIM/DMARC and blacklist checking | Free tier | No direct match in the declared OSS stack (Odoo/Mautic/Documenso/NocoDB-Baserow/Ollama) — evaluate case-by-case rather than force-fit | Limited |

## Selection Notes
- Use a dedicated sending domain (not the primary company domain) so any deliverability damage doesn't affect core business email.
- Confirm SPF, DKIM, and DMARC are correctly configured before any volume sending — this is a one-time technical setup, not optional.
