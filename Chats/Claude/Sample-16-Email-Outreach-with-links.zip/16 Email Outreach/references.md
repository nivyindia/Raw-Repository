# References — 16 Email Outreach

[⬅ Back to README](README.md)

## Internal Sources
- Cold Email Outreach SOP (Growth Engine)
- Cold Email System — Apollo + Instantly Method (Growth Engine)
- Cold Email System (Apollo Method) (Growth Engine)
- Email Sequences Library — 21-Day Nurture + Trigger (Growth Engine)
- Stage 10 Lead Verification (this KB)
- Stage 15 Outreach Channel Strategy (this KB)

## Official / Vendor Docs
- [Instantly.ai documentation](https://help.instantly.ai)
- [Apollo.io documentation](https://knowledge.apollo.io)
- [Google Postmaster Tools documentation](https://support.google.com/mail/answer/9981691)
- [MXToolbox SPF/DKIM/DMARC checkers](https://mxtoolbox.com/SuperTool.aspx)

> Pricing and tool-feature details in this stage's files are marked "verify current" — SaaS pricing and deliverability-provider policy both change frequently.
