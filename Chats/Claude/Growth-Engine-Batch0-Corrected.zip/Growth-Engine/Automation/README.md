# Automation/ — Exported n8n Workflow Files

**Status as of Batch 0 correction:** this folder was empty dead weight (no files, unclear purpose). Per the Correction Implementation Plan (Batch 0), it has been repurposed rather than deleted.

## Purpose

This is the landing spot for **exported `.json` n8n workflow files** — the actual importable workflow exports (not just links to templates) — once Batch 1 (n8n Template Linking Pass) and later depth-building batches start producing them.

## Convention

- One `.json` file per built/customized workflow.
- Name files to match the stage they belong to, e.g. `sales-16-email-outreach.json`, `marketing-m18-experiment-tracker.json`.
- If a workflow is a lightly-modified copy of a public template (from `nivyindia/all_n8n_templates_collection` or n8n.io), note the source template in a one-line comment at the top of this README or in a companion `.md` file with the same base name.
- This folder holds **working exports**, not documentation — the "why/when to use it" narrative stays in each stage's own `automation.md`, which should link back here once a matching export exists.

## Log

| Date | Change |
|---|---|
| 2026-07-23 | Folder repurposed (was empty/unused). No workflow exports yet — awaiting Batch 1. |
