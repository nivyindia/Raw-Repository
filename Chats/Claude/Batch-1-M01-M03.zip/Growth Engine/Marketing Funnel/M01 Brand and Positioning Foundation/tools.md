# M01 — Tools

Pulls from the shared free/OSS stack in `IMPLEMENTATION-PLAN.md` §2, plus stage-specific additions below.

## Stage-specific tools

| Function | Free / OSS tool | Notes | Paid upgrade path |
|---|---|---|---|
| Positioning workshop capture | **Notion free tier** or a plain shared doc | No dedicated tool needed — this stage is people-and-words, not software | — |
| Competitive scan | Manual browser review of competitor sites, **Wayback Machine** (free) for historical positioning changes | No paid competitive-intel tool needed at this stage's scale | SimilarWeb / SEMrush competitive modules, once deeper traffic/keyword-overlap data is needed |
| AI-assisted drafting | **Claude.ai / ChatGPT free tier** | Draft-only per Track M's standing QC rule — human sign-off required before a positioning statement is final | Paid API tier only if this is automated at multi-brand scale via n8n |
| Brief storage | **Notion** or the existing Master Company Database (already built for Nivy Empires) | Store the final brief where M02/M03 can link to it directly | — |

## Shared stack references used by this stage

- Workflow automation: n8n (self-hosted) — relevant if the AI-drafting step is templated across multiple brands (see `automation.md`)
- Experiment/record tracking: Notion or Airtable free tier — for tracking which brands have a completed brief vs. not

## Verify-current flags

- Notion and Airtable free-tier record/block caps change without notice — verify current limits before assuming this stage's brief storage fits inside a free plan across 10+ brands.
- No paid tool is required to complete this stage at any brand count.
