# M01 — Automation

M01 is the least automatable stage in Track M by design — positioning is a judgment call, not a data-processing task. Automation here is limited to **removing busywork around** the human decision, not replacing the decision.

## Manual (default for this stage)

- Workshop, competitive scan, and final sign-off are manual. This is correct, not a gap to close later.

## Semi-automated

- n8n workflow: when a new brand is added to the Master Company Database (Notion), trigger a checklist item / task assignment to run the M01 positioning workshop for that brand, so no new brand silently skips this stage.
- n8n workflow: on brief completion (a Notion property flips to "Done"), auto-notify the M02 and M03 owners that the brief is ready to consume, so those stages don't start on stale or missing positioning.

## AI-assisted (draft-only, human gate required)

- AI-drafting step (method 3 in `methods.md`) can be templated as a single n8n HTTP node that takes a brand's existing website copy as input and returns a first-draft positioning statement + value prop.
- **Standing QC rule applies**: this output is never published or handed to M02/M03 without the human-review checklist gate in `checklists.md` being completed first.

## What does not get automated

- The workshop itself (method 1) — this requires a human conversation, not a form.
- Final sign-off — always a named human decision-maker per brand, never an AI or an automated approval.
