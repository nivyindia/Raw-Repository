# M01 — Methods

Four ways to run the Brand & Positioning Foundation exercise, in increasing order of speed (and decreasing order of depth). Pick the depth that matches how much is genuinely unsettled about the brand — an established brand with 3+ years of market presence needs a lighter pass than a brand-new launch.

## 1. Manual / workshop method

- Run a structured 90-minute positioning workshop with the brand's decision-maker(s).
- Use the "positioning statement" fill-in-the-blank format: *"For [target buyer] who [need/problem], [brand] is the [category] that [key differentiator], unlike [primary alternative]."*
- Capture verbatim language the decision-maker uses to describe the brand — this raw language is often better source material for messaging than a polished summary, because it's how the person who understands the buyer instinctively frames the value.
- Output goes straight into the `templates.md` brief template.

## 2. Competitive-scan method

- Before writing positioning, pull the public-facing positioning of 3–5 direct competitors (their homepage hero copy, About page, and any published positioning statement).
- Map each on two axes relevant to the brand's category (e.g., price vs. service depth, DIY vs. done-for-you, generalist vs. specialist).
- Identify the open space — the combination no competitor currently owns — and check whether the brand's actual strengths can credibly claim it.
- This method is strongest paired with method 1, not as a replacement for it.

## 3. AI-assisted drafting method

- Feed the brand's existing collateral (website copy, sales deck, any prior Brand Bible) into an AI drafting tool with a prompt asking it to reverse-engineer a positioning statement and value proposition from the existing material.
- Treat the output as a **first draft only** — it reflects what's already been said publicly, not necessarily what's true or differentiated. A human must validate every claim against reality before it goes in the brief.
- This is the fastest method for brands that already have a lot of existing copy to draw from, and the weakest for brand-new brands with no existing material.

## 4. Hybrid (recommended default)

- Run the AI-assisted draft first (method 3) to get a starting point.
- Run the workshop (method 1) to correct, sharpen, and add verbatim language the AI couldn't have known.
- Run the competitive scan (method 2) to pressure-test the differentiation claim against what's actually true in-market.
- This is the default recommended approach because it's faster than pure-manual and more accurate than pure-AI.

## QC note

Every method above ends the same way: a human decision-maker for the brand signs off on the final positioning statement before it's marked done. AI-assisted drafting is a starting point, never a final answer — see `checklists.md`.
