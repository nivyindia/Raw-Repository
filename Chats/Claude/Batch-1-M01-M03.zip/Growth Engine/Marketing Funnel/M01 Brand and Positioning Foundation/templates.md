# M01 — Templates

## Template: Brand & Positioning Brief

```
BRAND: [brand name]
PARENT ENTITY: [if applicable]
DATE COMPLETED: [date]
OWNER / SIGN-OFF: [name]

1. TARGET BUYER (cross-ref Sales Funnel Stage 02 ICP — don't duplicate, link)
   - ICP summary: [1-2 lines]
   - Link to full ICP doc: [link]

2. POSITIONING STATEMENT
   For [target buyer]
   who [need / problem],
   [brand] is the [category]
   that [key differentiator],
   unlike [primary alternative].

3. VALUE PROPOSITION
   - Core value prop (1 sentence): [ ]
   - Proof point 1: [real, specific — no invented metrics]
   - Proof point 2: [ ]
   - Proof point 3: [ ]

4. COMPETITIVE LANDSCAPE
   | Competitor | Their positioning | Where we differ |
   |---|---|---|
   | [ ] | [ ] | [ ] |
   | [ ] | [ ] | [ ] |
   | [ ] | [ ] | [ ] |

5. VOICE & TONE
   - 3 adjectives that describe the brand's voice: [ ]
   - Example on-brand sentence: [ ]
   - Example off-brand sentence (what to avoid): [ ]

6. VISUAL IDENTITY
   - Existing Brand Bible link (if any): [ ]
   - If none exists, flag for separate visual-identity work: [Y/N]
```

## Template: Competitive Positioning Map (2-axis)

```
Axis 1 (e.g. Price): Low -------------------- High
Axis 2 (e.g. Service depth): DIY -------------------- Full-service

Plot each competitor + your brand as a point. Identify the open quadrant.
```

## Template: Workshop discussion prompts (for method 1 in methods.md)

- "If a client had to describe us to a colleague in one sentence, what would they say?"
- "What do we do that competitors genuinely can't or won't do?"
- "What's a piece of feedback a client has given us more than once?"
- "What would we lose if we tried to be 'everything to everyone'?"
