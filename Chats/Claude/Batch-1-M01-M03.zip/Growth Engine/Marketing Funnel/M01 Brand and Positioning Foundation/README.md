# M01 — Brand & Positioning Foundation

**Phase:** A — Foundation
**Feeds into:** M02 (Channel & Platform Selection), M03 (Content Pillars & Messaging Framework), and indirectly every downstream stage — brand and positioning are the reference point every later stage's tone, targeting, and messaging gets checked against.
**Depends on:** Sales Funnel Stages 02–03 (ICP / Persona definition) as cross-reference inputs — see note in §Raw Material below.

## What this stage does

M01 is where the business's market position gets defined in writing, once, so every later marketing decision (which channels, which content pillars, which words) has a fixed reference instead of being re-litigated per stage or per brand. Output is a single Brand & Positioning Brief per brand/entity that M02 and M03 both consume directly.

For a multi-brand operation, M01 is run **once per brand**, not once for the whole group — each brand under the parent entity gets its own positioning brief, because a B2B accounting/tax brand and a digital-marketing education brand do not share a target buyer, tone, or proof points even if they share an owner and back-office.

## Raw material note

The build checklist for this stage calls for mining existing ICP/Persona docs from Sales Funnel Stages 02–03. Those documents were not available in this session, so this stage's files are written as a **generic, brand-agnostic framework** rather than pre-filled with brand-specific positioning claims. Populating the actual positioning statements, ICP details, and proof points for each brand is the first task when this stage moves from skeleton to execution — see `checklists.md` for the gate that enforces this.

## Sub-stages

| # | Sub-stage | Output |
|---|---|---|
| M01.1 | ICP & buyer definition (cross-reference, don't duplicate, Sales Funnel Stage 02) | Confirmed ICP per brand |
| M01.2 | Competitive landscape scan | Competitor positioning map |
| M01.3 | Positioning statement | One-sentence positioning per brand |
| M01.4 | Value proposition & proof points | Value prop + evidence list |
| M01.5 | Voice & tone definition | Voice/tone guide |
| M01.6 | Visual identity cross-reference (if a Brand Bible already exists for the brand, link — don't rebuild) | Link to existing Brand Bible or flag as missing |

## How to use this stage

1. Start with `methods.md` for how to run the positioning exercise (manual, structured, or AI-assisted).
2. Use `templates.md` for the actual brief template — this is the artifact every other stage links back to.
3. Run the QC gate in `checklists.md` before treating a brief as final.
4. Once complete, M02 (Channel Selection) and M03 (Messaging Framework) both read directly from this brief.

## Cross-references

- Feeds: [M02 Channel & Platform Selection](../M02%20Channel%20and%20Platform%20Selection/README.md), [M03 Content Pillars & Messaging Framework](../M03%20Content%20Pillars%20and%20Messaging%20Framework/README.md)
- Depends on: Sales Funnel Stage 02 (ICP), Sales Funnel Stage 03 (Persona) — cross-reference, do not duplicate
- Parent index: [Marketing Funnel home](../README.md)
