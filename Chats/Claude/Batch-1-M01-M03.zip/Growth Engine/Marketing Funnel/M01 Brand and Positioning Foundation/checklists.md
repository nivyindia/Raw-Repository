# M01 — Checklists

## QC Gate: Positioning Brief Sign-Off (required before a brief is marked "Done")

- [ ] Positioning statement follows the fill-in-the-blank format and names a real, specific target buyer (not "everyone")
- [ ] Value proposition is backed by at least one real proof point (case result, credential, track record) — no invented metrics or claims
- [ ] Competitive differentiation claim has been checked against actual competitor positioning, not assumed
- [ ] Voice & tone guide includes at least 3 concrete examples of on-brand language, not just adjectives
- [ ] If an existing Brand Bible already exists for this brand, this brief cross-references it rather than contradicting or duplicating it
- [ ] A named human decision-maker for the brand has signed off on the final brief
- [ ] If any section used AI-assisted drafting (method 3), that section has been human-reviewed and edited, not published as-is

## Per-brand rollout checklist (multi-brand groups)

- [ ] Confirmed this brand does not already have a positioning brief elsewhere in the workspace before starting fresh
- [ ] ICP cross-referenced from Sales Funnel Stage 02, not re-invented
- [ ] Brief stored in the location M02/M03 will actually look for it (Notion path confirmed)
- [ ] Progress tracker in `IMPLEMENTATION-PLAN.md` updated

## Red flags that should stop this stage from being marked done

- Positioning statement could apply to any competitor with the brand name swapped in
- Proof points are aspirational ("will be") rather than real ("has been")
- No human sign-off recorded, only an AI-drafted output
