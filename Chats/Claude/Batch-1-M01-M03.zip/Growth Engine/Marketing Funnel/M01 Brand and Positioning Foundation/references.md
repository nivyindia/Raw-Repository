# M01 — References

## Internal sources cited

- `README.md` (Marketing Funnel home) — stage index and folder standard
- `IMPLEMENTATION-PLAN.md` §2 — shared free/OSS tool stack referenced in `tools.md`
- `IMPLEMENTATION-PLAN.md` §5 — per-stage build checklist this file follows
- Sales Funnel Stage 02 / Stage 03 (ICP & Persona) — named as cross-reference source, not duplicated here; not available in this build session (see README.md "Raw material note")

## Framework references (general marketing methodology, not brand-specific)

- Positioning statement fill-in-the-blank format — standard "for/who/is/that/unlike" structure widely used in B2B positioning work (e.g., Geoffrey Moore's *Crossing the Chasm* positioning template)
- Two-axis competitive mapping — standard strategy-consulting technique for visualizing category white space

## Note

This stage's files were built without access to the Growth Engine raw-material docs referenced in `IMPLEMENTATION-PLAN.md` §5 (ICP/Persona docs). No brand-specific claims, metrics, or positioning statements have been fabricated to fill that gap — see README.md "Raw material note" for what remains to be populated per brand.
