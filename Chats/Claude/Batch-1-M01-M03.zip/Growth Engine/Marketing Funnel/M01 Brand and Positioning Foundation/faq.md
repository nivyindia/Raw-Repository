# M01 — FAQ

**Q: Do we need a separate positioning brief for every brand, or can Nivy Empires / Billion Dreams United have one shared brief?**
A: Separate, per brand. A parent-entity-level brief can exist as a short "house of brands" summary, but it doesn't substitute for each operating brand's own positioning — different brands have different buyers and can't share a single positioning statement without it becoming generic.

**Q: What if a brand already has informal positioning that's never been written down?**
A: That's the most common starting point, not a problem. Run the workshop method (methods.md §1) to get it into writing — the goal is capturing what already works, not inventing something new from scratch.

**Q: Can this stage be skipped for brands that already seem to have clear positioning?**
A: The brief still needs to exist in writing and in the standard template, even if the workshop is short, because M02 and M03 both link to this file directly — if it doesn't exist in the expected format/location, downstream stages break.

**Q: What happens if the competitive scan finds we're not actually differentiated from a competitor?**
A: That's a real finding, not a stage failure. Flag it honestly in the brief rather than forcing a differentiation claim that isn't true — a weak-but-honest positioning statement is more useful downstream than a strong-but-false one.

**Q: Who signs off on the brief?**
A: A named human decision-maker for that specific brand — not a general approval, and never an AI-only sign-off (see `checklists.md`).
