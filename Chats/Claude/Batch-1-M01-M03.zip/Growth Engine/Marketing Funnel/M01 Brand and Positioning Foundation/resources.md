# M01 — Resources

## Internal

- Sales Funnel Stage 02 (ICP definition) — cross-reference input
- Sales Funnel Stage 03 (Persona definition) — cross-reference input
- Master Company Database (Notion) — where completed briefs should be stored/linked
- Existing per-brand Brand Bibles (e.g., Nivy Next Brand Bible) — link, don't duplicate, if one already exists for the brand in question

## External / official docs

- Google Search Console Help — for later validating positioning against actual search demand once M04 (Keyword Research) runs: https://support.google.com/webmasters
- Notion Help Center (for brief storage/templates): https://www.notion.so/help
- Wayback Machine (for historical competitor positioning review): https://web.archive.org

## Note on external links

External links above point to official documentation home pages rather than deep-linked articles, since deep-link paths on vendor help sites change without notice — verify current before relying on a specific sub-page.
