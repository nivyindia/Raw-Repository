# M03 — Content Pillars & Messaging Framework

**Phase:** A — Foundation
**Depends on:** M01 (Brand & Positioning Foundation), M02 (Channel & Platform Selection)
**Feeds into:** M04 (Keyword Research), M08 (Editorial Calendar), M09 (Long-Form Content Production), and every social channel stage (M11–M16) — this is the last Foundation stage before the SEO Engine (Phase B) and Content Engine (Phase C) begin.

## What this stage does

M03 translates positioning (M01) and channel choice (M02) into a small, fixed set of **content pillars** — the 3-5 recurring topic buckets a brand will actually publish content within — plus a **messaging framework** that defines the key phrases, proof points, and claims that should show up consistently across every piece of content, on every channel.

Without M03, content production (M09) and editorial planning (M08) have no consistent topical spine, and every writer, VA, or AI-drafting pass reinvents "what do we even talk about" from scratch each time — which is how brand messaging drifts inconsistent across a large content volume.

## Sub-stages

| # | Sub-stage | Output |
|---|---|---|
| M03.1 | Content pillar definition (3-5 pillars, tied to ICP pain points from M01) | Pillar list with rationale |
| M03.2 | Messaging framework (core claims, proof points, phrases to reuse and phrases to avoid) | Messaging doc |
| M03.3 | Pillar-to-channel mapping (which pillars lead on which Primary channel from M02) | Pillar/channel matrix |
| M03.4 | Content pillar validation against real buyer questions (not just internal assumptions) | Validated pillar list |

## Why 3-5 pillars, not more

A larger pillar count feels more comprehensive but in practice dilutes editorial focus and makes it harder for a content calendar (M08) or an AI-drafting prompt (M09) to stay on-brand — 3-5 pillars is a deliberate constraint, not an oversight, and matches standard content-marketing practice for this reason.

## Cross-references

- Depends on: [M01 Brand & Positioning Foundation](../M01%20Brand%20and%20Positioning%20Foundation/README.md), [M02 Channel & Platform Selection](../M02%20Channel%20and%20Platform%20Selection/README.md)
- Feeds: M04 Keyword Research, M08 Editorial Calendar, M09 Long-Form Content Production (not yet built — see Batches 2-3)
- Parent index: [Marketing Funnel home](../README.md)
