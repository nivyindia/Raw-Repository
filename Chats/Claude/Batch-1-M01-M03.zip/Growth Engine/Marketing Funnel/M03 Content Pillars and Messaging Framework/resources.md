# M03 — Resources

## Internal

- M01 Brand & Positioning Brief (per brand) — required input
- M02 Channel Priority Matrix (per brand) — required input
- Sales call notes / support ticket logs — buyer-question validation source

## External / official docs

- AnswerThePublic: https://answerthepublic.com
- Google Search (for manual "People Also Ask" review): https://www.google.com

## Note on external links

AnswerThePublic's free-tier terms and query caps change without notice — verify current before relying on it for a full multi-brand validation pass.
