# M03 — Methods

## 1. Pain-point-to-pillar method (primary method)

- Pull the ICP pain points already surfaced in M01's positioning brief.
- Group related pain points into 3-5 clusters — each cluster becomes a content pillar.
- Example shape (illustrative structure only, not a filled-in claim): a B2B professional-services brand might cluster around pillars like "process/how-it-works education," "compliance/regulatory changes," "cost/ROI comparison," and "case-outcome proof" — the actual pillar names must come from that brand's real ICP pain points, not be copied from this example.
- Each pillar should be specific enough that a writer knows what NOT to write, not just what to write.

## 2. Buyer-question validation method

- Cross-check draft pillars against real questions the ICP actually asks — sales call notes, support tickets, FAQ pages, or (once M04 runs) actual search query data.
- Drop or merge any pillar that doesn't map to a real, recurring buyer question — a pillar that only reflects what the business wants to say, not what the buyer wants to know, underperforms.

## 3. Messaging framework method

- For each pillar, write: the core claim, 1-2 proof points, and 2-3 reusable phrases.
- Separately maintain a short "phrases to avoid" list — jargon, overused industry phrases, or claims that overlap too closely with a specific competitor's stated positioning.
- This becomes the reference doc every AI-assisted drafting pass in M09/M10 is prompted against, so AI-drafted content stays on-message without a human re-explaining brand voice every time.

## 4. Pillar-to-channel mapping method

- For each Primary channel from M02, assign which pillar(s) lead there and which are secondary — not every pillar needs equal weight on every channel (e.g., a "process education" pillar may lead on long-form/SEO content, while a "proof/case outcome" pillar may lead on LinkedIn).
