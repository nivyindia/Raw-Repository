# M03 — Tools

## Stage-specific tools

| Function | Free / OSS tool | Notes | Paid upgrade path |
|---|---|---|---|
| Pillar/messaging doc storage | **Notion free tier** | Single source of truth every AI-drafting prompt in M09/M10 references | — |
| Buyer-question validation | **AnswerThePublic** (free tier, verify current daily-query cap), **Google "People Also Ask"** (free, manual review), actual sales-call/support-ticket notes | Combine 2-3 sources since none alone is comprehensive | Ahrefs "Questions" report once keyword tooling budget exists (also feeds M04) |
| AI-assisted messaging drafting | **Claude.ai / ChatGPT free tier** | Draft-only, per Track M's standing QC rule | Paid API tier for scaled multi-brand automation |

## Shared stack references used by this stage

- Once complete, this stage's messaging framework becomes a reusable input the shared AI-drafting step (referenced in `IMPLEMENTATION-PLAN.md` §2, Content repurposing row) is prompted against for every future stage that drafts content.

## Verify-current flags

- AnswerThePublic's free-tier query cap changes without notice — verify current before relying on it for a full validation pass across many brands.
