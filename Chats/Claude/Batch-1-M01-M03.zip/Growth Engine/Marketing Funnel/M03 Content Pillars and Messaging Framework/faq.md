# M03 — FAQ

**Q: Can pillars change over time?**
A: Yes — pillars should be revisited if the buyer-question validation starts turning up new recurring questions the current pillars don't cover, or if M02's channel mix changes materially. This isn't a one-time-forever artifact, but changes should be deliberate, not ad hoc per content piece.

**Q: What if internal stakeholders want to add a 6th or 7th pillar?**
A: Push back per the QC gate — more than 5 pillars is a signal to re-cluster overlapping topics rather than treat every internal idea as its own pillar. If a genuinely distinct new pillar is needed, an existing one should usually be retired or merged to keep the total at 3-5.

**Q: Does every piece of content need to map cleanly to exactly one pillar?**
A: Most should map primarily to one pillar, though a given piece can touch a secondary pillar. If a large share of published content doesn't map to any pillar, that's a signal the pillars were defined too narrowly or content production has drifted from the framework — worth a checklist review.

**Q: How does this framework get used day-to-day?**
A: It's the reference doc for M08 (Editorial Calendar) when scheduling topics, and the reference doc every AI-drafting prompt in M09/M10 should be built against, so AI-assisted content drafts stay on-pillar and on-voice without needing the brand context re-explained each time.
