# M03 — Checklists

## QC Gate: Content Pillar & Messaging Framework Sign-Off

- [ ] Pillar count is between 3 and 5 — more than 5 gets flagged for re-clustering before approval
- [ ] Every pillar traces back to a real ICP pain point in the M01 brief, not an internally-assumed topic
- [ ] Every pillar validated against at least one real buyer-question source (sales notes, support tickets, or search data)
- [ ] Messaging framework includes both reusable phrases AND a "phrases to avoid" list
- [ ] Pillar-to-channel mapping completed against M02's Primary channel list
- [ ] No proof point in the messaging framework is an invented or unverified metric/case claim
- [ ] Framework stored where M04, M08, and M09 owners can reference it directly

## Red flags

- Pillars read like internal department names (e.g., "Company News," "Product Updates") rather than buyer-relevant topics
- No pillar was ever cross-checked against a real buyer question
- Messaging framework only lists what to say, with no "avoid" list — this usually means competitor-overlap risk wasn't checked
