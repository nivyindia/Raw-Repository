# M03 — Automation

## Manual (default)

- Pillar definition and messaging framework writing are manual/judgment-based — done once per brand (with periodic revisits), not per content piece.

## Semi-automated

- n8n workflow: once M02's Channel Priority Matrix is marked "Done" for a brand, auto-create the M03 pillar/messaging template and assign it, so this stage doesn't get skipped.
- n8n workflow: on M03 completion, auto-notify M04 (Keyword Research), M08 (Editorial Calendar), and M09 (Content Production) owners that the messaging framework is ready to reference.

## AI-assisted (draft-only, human gate required)

- AI drafting can generate a first-pass pillar list and candidate proof-point phrasing from the M01 brief as input, but per the standing QC rule, a human must validate every pillar against real buyer questions (method 2) before it's finalized — AI-suggested pillars reflect pattern-matching on the input brief, not verified buyer demand.

## What does not get automated

- Buyer-question validation against real sales/support data — this requires a human (or at minimum a human-reviewed data pull) to be credible, since it's the check against the business fabricating pillars nobody actually asks about.
