# M03 — Templates

## Template: Content Pillar & Messaging Framework

```
BRAND: [brand name]
DATE: [date]
LINKED POSITIONING BRIEF: [link to M01 output]
LINKED CHANNEL MATRIX: [link to M02 output]

PILLAR 1: [name]
- ICP pain point it addresses: [ ]
- Validated by (real buyer question source): [ ]
- Core claim: [ ]
- Proof point(s): [ ]
- Reusable phrases: [ ]
- Leads on channel(s): [ ]

PILLAR 2: [name]
[repeat structure]

PILLAR 3: [name]
[repeat structure]

[Pillar 4-5 optional, same structure — do not exceed 5]

PHRASES TO AVOID (across all pillars)
- [ ]
- [ ]

PILLAR-TO-CHANNEL MATRIX
| Pillar | Primary channel(s) | Secondary channel(s) |
|---|---|---|
| [ ] | [ ] | [ ] |
```

## Template: Buyer-Question Validation Log

```
| Candidate pillar | Real question found | Source (sales call / support ticket / search) | Keep / merge / drop |
|---|---|---|---|
| [ ] | [ ] | [ ] | [ ] |
```
