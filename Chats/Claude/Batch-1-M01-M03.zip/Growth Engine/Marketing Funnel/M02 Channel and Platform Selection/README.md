# M02 — Channel & Platform Selection

**Phase:** A — Foundation
**Depends on:** M01 (Brand & Positioning Foundation) — reads the ICP and positioning brief directly
**Feeds into:** M03 (Content Pillars & Messaging Framework), and directly determines which of Phase D's social stages (M11–M16) actually get built to full depth vs. left as low-priority skeletons

## What this stage does

M02 decides **where** a brand shows up — which channels get real investment (content, time, budget) and which get deliberately skipped. This matters more for a multi-brand group than a single-brand business: without an explicit per-brand channel decision, the default failure mode is spreading every brand across every platform (LinkedIn, Instagram, YouTube, X, Facebook, Pinterest, Threads, WhatsApp) at shallow depth, which produces worse results than fewer channels done well.

Output is a **Channel Priority Matrix per brand**: a ranked list of primary, secondary, and not-now channels, with the reasoning for each, so M11–M16 know which stages to build first.

## Sub-stages

| # | Sub-stage | Output |
|---|---|---|
| M02.1 | ICP-to-channel mapping (where does this brand's buyer actually spend attention?) | Channel shortlist |
| M02.2 | Competitive channel scan (where are competitors winning attention, where is it uncontested?) | Channel opportunity notes |
| M02.3 | Capacity reality check (how many channels can actually be run to a quality bar with current resourcing?) | Resourcing-adjusted shortlist |
| M02.4 | Final Channel Priority Matrix | Primary / Secondary / Not-now list per brand |

## Why this stage exists as its own stage

Channel selection is a distinct decision from content strategy (M03) and from execution (M11–M16). Folding it into either would either make M03 a channel-planning doc instead of a messaging doc, or let M11–M16 each independently decide "should we even be here," which risks 6 different answers to the same question across 6 stages.

## Cross-references

- Depends on: [M01 Brand & Positioning Foundation](../M01%20Brand%20and%20Positioning%20Foundation/README.md)
- Feeds: [M03 Content Pillars & Messaging Framework](../M03%20Content%20Pillars%20and%20Messaging%20Framework/README.md), M11 LinkedIn through M16 Secondary Platforms (not yet built — see Batch 4)
- Parent index: [Marketing Funnel home](../README.md)
