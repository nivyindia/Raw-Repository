# M02 — Tools

## Stage-specific tools

| Function | Free / OSS tool | Notes | Paid upgrade path |
|---|---|---|---|
| Platform demographic/usage data | Each platform's own official ad-planning tool (e.g., LinkedIn Campaign Manager audience estimates, Meta Ads Manager audience insights) — free to view even without running ads | Most current and accurate source; always check live rather than relying on remembered figures, which go stale | — |
| Competitive channel scan | Manual review of competitor profiles across platforms | No paid tool required at this stage | Social listening tools (Brandwatch, Sprout Social) once monitoring needs to be continuous rather than a one-time scan |
| Channel Priority Matrix storage | **Notion free tier** (or existing Master Company Database) | One matrix per brand, linked from M01's brief | — |
| Capacity planning | Simple spreadsheet or Notion table | Time-cost-per-channel math doesn't need dedicated software | — |

## Shared stack references used by this stage

- Experiment/record tracking: Notion or Airtable free tier, per `IMPLEMENTATION-PLAN.md` §2

## Verify-current flags

- Platform-reported audience/demographic figures change frequently and are platform-self-reported — treat as directional, not precise, and re-check before major channel decisions rather than reusing a stale figure.
