# M02 — Automation

## Manual (default)

- ICP-to-channel mapping and the capacity reality check are manual judgment calls — this is a strategic decision made a handful of times per brand (not per post), so full automation isn't the goal here.

## Semi-automated

- n8n workflow: once M01's brief is marked "Done" for a brand (Notion property change), auto-create the M02 Channel Priority Matrix template for that brand and assign it to an owner, so channel selection doesn't get skipped or forgotten between stages.
- n8n workflow: on Channel Priority Matrix completion, auto-notify M03 and the relevant M11–M16 stage owners of which channels are Primary vs. Secondary vs. Not-now for that brand.

## AI-assisted (supporting research only)

- AI drafting tools can help summarize publicly available platform usage patterns to speed up research, but per `methods.md` §4, this must be checked against live platform data before being used in a final decision — AI-summarized platform demographics are a starting point, not a source of truth.

## What does not get automated

- The final Primary/Secondary/Not-now call per brand — always a human decision informed by the matrix, not an automated score.
