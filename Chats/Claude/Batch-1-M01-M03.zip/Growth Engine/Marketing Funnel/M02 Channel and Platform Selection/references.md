# M02 — References

## Internal sources cited

- `README.md` (Marketing Funnel home)
- `IMPLEMENTATION-PLAN.md` §2, §5
- M01 Brand & Positioning Foundation (`README.md`, `templates.md`) — direct input dependency

## Framework references (general methodology)

- ICP-to-channel attention mapping — standard B2B demand-gen planning practice (buyer research behavior differs materially by role/seniority, which drives channel choice)
- Capacity-based channel prioritization — common growth-marketing practice of matching channel count to sustainable production capacity rather than platform count alone

## Note

No brand-specific channel decisions have been pre-filled in this stage's files — the matrix template in `templates.md` is blank by design and gets populated per brand once M01's brief exists for that brand.
