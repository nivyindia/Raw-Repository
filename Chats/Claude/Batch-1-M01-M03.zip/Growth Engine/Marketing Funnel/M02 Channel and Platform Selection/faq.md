# M02 — FAQ

**Q: Should every brand be on every channel "just in case"?**
A: No — this is the exact failure mode M02 exists to prevent. Thin presence across every channel typically underperforms strong presence on 2-3 channels. A channel with no realistic weekly capacity behind it should be Not-now, not a token Secondary presence.

**Q: What if a brand's ICP is genuinely active on a channel that's hard to produce content for (e.g., YouTube, which is production-heavy)?**
A: That's a legitimate Primary-tier channel if the capacity exists — high production cost isn't disqualifying on its own. It becomes Not-now only if the capacity reality check (methods.md §3) shows it can't be sustained.

**Q: Can channel priority differ across brands in the same group?**
A: Yes, and it usually should — each brand has its own M01 brief and its own ICP, so a shared parent entity does not imply a shared channel matrix. Nivy Advisory's B2B buyer and Nivy Academy's learner audience are a clear example of two different ICPs likely needing two different channel mixes.

**Q: How often should the matrix be revisited?**
A: At minimum annually, or sooner if a platform materially changes (algorithm shift, new feature, competitor moving in force) — see the red flags in `checklists.md`.
