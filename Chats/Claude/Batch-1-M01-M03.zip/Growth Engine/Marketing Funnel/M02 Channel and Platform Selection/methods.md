# M02 — Methods

## 1. ICP-to-channel mapping method (primary method)

- Start from the ICP in M01's Brand & Positioning Brief, not from "which platforms are trending."
- For B2B buyers (e.g., a Nivy Advisory-type accounting/tax buyer), the honest default is: LinkedIn first, search/SEO-fed content second, email third — because B2B buyers research on search and LinkedIn, not Instagram or Pinterest.
- For consumer-education or personal-brand-driven offers (e.g., a Nivy Academy-type audience), Instagram, YouTube, and community channels typically outperform LinkedIn for top-of-funnel reach, even though LinkedIn may still matter for B2B partnership angles.
- Write out, per brand: "our buyer spends attention on [X, Y, Z] because [reason tied to their role/behavior]" — not "everyone uses Instagram."

## 2. Competitive channel scan method

- Check where direct competitors are actually active (not just have a profile on, but post consistently and get engagement on).
- Flag channels where competitors are weak or absent — this is often a better opportunity than fighting for attention where every competitor is already investing heavily.

## 3. Capacity reality check method

- List actual available hands: how many people (including VAs) can realistically produce channel-native content weekly, per brand.
- Multiply channel count by a conservative per-channel weekly time cost (content creation + posting + engagement/community response) and compare to actual capacity.
- Where the math doesn't work, cut channels rather than running all of them shallowly — this directly determines the Primary/Secondary/Not-now tiers in the output matrix.

## 4. AI-assisted channel research (supporting, not primary)

- AI tools can summarize general platform demographic/usage data, but this data goes stale and is often generic — always verify current platform-reported demographics rather than relying on model training data, which may be outdated (see `checklists.md`).
