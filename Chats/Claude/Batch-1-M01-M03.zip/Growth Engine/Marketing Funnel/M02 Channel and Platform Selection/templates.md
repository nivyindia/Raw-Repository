# M02 — Templates

## Template: Channel Priority Matrix

```
BRAND: [brand name]
DATE: [date]
LINKED POSITIONING BRIEF: [link to M01 output]

PRIMARY CHANNELS (full weekly investment)
| Channel | Why (ICP-attention reasoning) | Weekly time cost (est.) | Owner |
|---|---|---|---|
| [ ] | [ ] | [ ] | [ ] |

SECONDARY CHANNELS (light/repurposed presence only)
| Channel | Why secondary, not primary | Minimum viable cadence |
|---|---|---|
| [ ] | [ ] | [ ] |

NOT-NOW CHANNELS (deliberately skipped)
| Channel | Reason for skipping | Revisit trigger (what would change this) |
|---|---|---|
| [ ] | [ ] | [ ] |

CAPACITY CHECK
- Total weekly content-production hours available: [ ]
- Total weekly hours required by Primary + Secondary above: [ ]
- Fits? [Y/N] — if N, cut a channel before finalizing
```

## Template: Competitive Channel Scan Notes

```
| Competitor | Channels active on | Where they're strong | Where they're weak/absent (opportunity) |
|---|---|---|---|
| [ ] | [ ] | [ ] | [ ] |
```
