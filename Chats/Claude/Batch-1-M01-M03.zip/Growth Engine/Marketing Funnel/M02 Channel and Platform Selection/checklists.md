# M02 — Checklists

## QC Gate: Channel Priority Matrix Sign-Off

- [ ] Every channel decision is tied back to the ICP from M01's brief — no channel included just because it's popular in general
- [ ] Competitive scan completed for at least 3 direct competitors before finalizing tiers
- [ ] Capacity reality check completed — Primary tier channel count matches actual available production capacity, not aspirational capacity
- [ ] Platform usage/demographic data used in the decision was checked live, not pulled from memory or a stale prior report
- [ ] Not-now channels have a documented reason (capacity, ICP mismatch, saturated competition) — not left blank
- [ ] Matrix stored where M03 and M11–M16 owners can find it

## Red flags

- Every channel is marked "Primary" — this usually means the capacity reality check wasn't actually run
- Channel choice is justified by "competitors are there" alone, with no ICP-attention reasoning
- Matrix hasn't been revisited in 12+ months for a fast-moving brand (platforms and buyer attention shift; treat this as a living document, not a one-time artifact)
