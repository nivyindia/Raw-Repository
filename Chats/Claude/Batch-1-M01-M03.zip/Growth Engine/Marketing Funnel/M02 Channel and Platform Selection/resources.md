# M02 — Resources

## Internal

- M01 Brand & Positioning Brief (per brand) — required input
- Master Company Database (Notion) — matrix storage location

## External / official docs

- LinkedIn Campaign Manager (audience estimate tool, free to view): https://www.linkedin.com/campaignmanager
- Meta Ads Manager (Audience Insights, free to view): https://www.facebook.com/business/tools/ads-manager
- YouTube Analytics / Creator help (for channel-fit research): https://support.google.com/youtube

## Note on external links

Platform tools and audience-estimate features are frequently renamed or moved by the platforms themselves — verify current tool names/locations before relying on a specific link path.
