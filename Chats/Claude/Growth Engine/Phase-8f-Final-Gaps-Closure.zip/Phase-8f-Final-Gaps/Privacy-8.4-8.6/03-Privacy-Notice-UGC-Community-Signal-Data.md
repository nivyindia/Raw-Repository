# Privacy Notice — UGC Content, Community Membership & Signal-Based Outreach Data
**[TEMPLATE — applies across 8.4 UGC/Share, 8.5 Community, and 8.6 Signal-Based Outreach engines. Link this from the Showcase page, the Founders Circle invite page, and every 8.6 outbound email/opt-out page footer.]**

*Last updated: {{last_updated_date}} · Version 1.0*

This notice sits alongside `03-Privacy-Notice-Contest-Data.md` (which covers 8.1–8.3 only). It does not replace it — a visitor who both enters the contest **and** joins the community should be pointed at both notices, since the data categories and legal bases differ. **{{legal_entity_name}}** (Nivy Next / Billion Dreams United) is the data controller for all three engines below.

---

## Part A — 8.4 UGC / Share Engine

### A1. What we collect
- Identity/contact data (name, business name, email) submitted with a Showcase entry
- The Submission itself: post/reel URLs, screenshots, testimonial text, video links
- Verification metadata: `verification_status`, points awarded, reviewer notes
- Public engagement data visible on the platform where the content was posted (likes/comments count, if used for verification only — not stored beyond a verification snapshot)

### A2. Why (legal basis)
| Purpose | Legal basis |
|---|---|
| Reviewing and scoring your Submission, awarding points | Contract (performance of the Submission Terms) |
| Displaying your Submission + name/business name on our site, socials, or marketing (per the Content License) | Consent (given at submission; withdrawable for future use) |
| Fraud/duplicate-submission checks | Legitimate interest |

### A3. Retention
Verified Submission metadata and points ledger: kept for the life of the campaign + 24 months (leaderboard history). Rejected submissions: purged after 90 days. Underlying published content (e.g., a shared social post) is controlled by you on that platform, not by us.

---

## Part B — 8.5 Community Engine (Founders Circle)

### B1. What we collect
- Identity/contact data (name, business/agency name, email, WhatsApp/Telegram handle)
- `community_members` record: role (`member`/`moderator`/`partner`), join date, status
- Moderation-relevant records only (e.g., a documented Code of Conduct violation and the action taken) — **we do not separately archive general group chat content**; that lives on WhatsApp/Telegram under that platform's own terms

### B2. Why (legal basis)
| Purpose | Legal basis |
|---|---|
| Managing membership, adding/removing you from the group | Contract (performance of the Community Guidelines) |
| Moderation and enforcement of the Code of Conduct | Legitimate interest |
| Partner-tier cross-referral visibility (Part B of the Community Guidelines) | Contract / consent (partner opt-in) |

### B3. Retention
Membership records: kept for the duration of membership + 12 months after leaving (for re-invite/history purposes), unless you request earlier deletion.

---

## Part C — 8.6 Signal-Based Outreach Engine

**This is the one engine in Phase 8 where we process data about you *before* you have ever interacted with us** — sourced from public signals (e.g., a hiring post, funding announcement, or press mention) or from your prior status as a lapsed client (`winback.escalated`). Read this part carefully; it carries different obligations than Parts A and B.

### C1. What we collect
- Publicly available business/professional data relevant to the triggering signal (company name, role, public contact channel, the public post/announcement itself)
- `signal_leads` record: `signal_type`, `raw_signal` (the source data), `ai_score`, `outreach_status`
- If you were previously a client: prior engagement history used solely to determine reactivation eligibility

### C2. Why (legal basis)
| Purpose | Legal basis |
|---|---|
| Identifying and scoring a relevant outreach opportunity from public signals | Legitimate interest — balanced against your rights; see `01-Outbound-Compliance-Notes.md` for the region-by-region limits we apply |
| Sending the outreach email itself | Legitimate interest (US/most regions) or **consent/existing-business-relationship** where required (Canada/UK/EU — see compliance notes) |
| Honoring an opt-out/unsubscribe | Legal obligation |

### C3. Where the data comes from
Publicly available sources only (company websites, public job postings, public press/funding announcements, public professional profiles) or our own prior client records for reactivation. We do not purchase or scrape private/restricted data, and we do not use data obtained in violation of a platform's own terms of service.

### C4. Retention
`signal_leads` rows for non-responders are purged or anonymized after **12 months** of inactivity (data-minimization, consistent with GDPR/UK GDPR). Opted-out contacts are retained **indefinitely on the suppression list only** (the minimum needed to guarantee we never contact you again), not for any other purpose.

### C5. Your right to object
You may object to this processing and request erasure at any time — this is not conditional on you having previously interacted with us. Use the opt-out link in any 8.6 email, the standalone opt-out page (`02-opt-out-confirmation-page.html`), or email {{privacy_contact_email}} directly.

---

## Part D — Shared provisions (all three engines)

### D1. Who we share it with
- Internal CRM (`clients_master`) and the relevant campaign table (`ugc_submissions`, `community_members`, `signal_leads`)
- Messaging infrastructure providers (WhatsApp Business API/Waha, Telegram, email/SMTP) strictly to deliver communications tied to your Submission/membership/outreach
- We do **not** sell personal data to third parties, and we do not share 8.6 signal data with any party outside {{legal_entity_name}}.

### D2. International transfers
Data is stored and processed on servers accessible to our team in India. UK/EU-linked data transferred out of the UK/EEA relies on Standard Contractual Clauses or an equivalent safeguard where required.

### D3. Your rights
Depending on your country, you may have the right to access, correct, delete, or port your data, and to object to or restrict processing. **UK/EU:** rights under UK/EU GDPR. **California:** rights under CCPA/CPRA (no sale of personal information occurs). **Australia:** rights under the Privacy Act 1988 (Cth). **Canada:** rights under PIPEDA (and CASL-specific consent withdrawal for 8.6 email). To exercise any right, contact **{{privacy_contact_email}}**; we respond within the timeframe required by applicable law (typically 30 days).

### D4. Automated decision-making
UGC verification and signal scoring flag/rank items for **human review** — no fully-automated decision (rejection, community removal, or outreach exclusion) is made without a human able to intervene. You may request human review of any automated flag concerning you.

### D5. Children
None of these three engines are directed at, or knowingly collect data from, individuals under 18.

### D6. Contact
{{legal_entity_name}} · Lucknow, Uttar Pradesh, India · {{privacy_contact_email}}

---
> ⚠️ Template only. Two items specifically need counsel's eyes before go-live: (1) Part C's legitimate-interest balancing test for 8.6 outreach in the UK/EU (GDPR Recital 47 documentation) and (2) whether any signal source used for 8.6 requires its own data-source-specific compliance check (e.g., a job-board's API terms on redistribution of listings data).
