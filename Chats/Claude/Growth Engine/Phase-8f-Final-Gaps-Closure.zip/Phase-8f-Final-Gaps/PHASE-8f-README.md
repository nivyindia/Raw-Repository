# Phase 8f — Supporting-Files Gap Closure & Final Implementation Plan
*(Sabhi non-`workflow.json` supporting files — T&C, rules, privacy, cookie notice, landing pages, SQL — ka final audit + jo bacha tha wo yahan complete kiya gaya)*

---

## 0. Is package ka scope

Aapne 8a → 8e tak jo bhi bheja, us poore set (engines 8.1–8.7 ke workflow.json chhod ke, sirf non-JSON supporting files — T&C/rules/privacy/landing-pages/SQL) ko cross-check kiya. **3 genuine gaps mile, teeno ab close ho chuke hain:**

| # | Gap | Type | Status |
|---|---|---|---|
| 1 | 8.1 aur 8.2 landing pages ka payload actual `workflow.json` ke expected fields se mismatch tha (Phase 8e QA Findings 1 & 2) — real traffic pe entries silently fail hoti | Bug-fix (HTML/JS, no workflow edit) | ✅ Patched |
| 2 | 8.4 (UGC), 8.5 (Community), 8.6 (Signal-Outreach) ke paas apna koi Privacy Notice nahi tha — jo Privacy Notice ban chuka tha wo explicitly sirf 8.1–8.3 ke liye scoped tha | Missing legal doc | ✅ Created |
| 3 | Poore Phase 8 me (8.1–8.6 sabhi landing pages) kahin bhi cookie/tracking consent disclosure nahi tha — EU/UK (PECR) audience target karne pe ye real gap hai | Missing legal doc + reusable web component | ✅ Created |

Contest rules, prize structure, eligibility, currency — sab **already international-level pe ban chuke the** (`02-Official-Contest-Rules-nivy-top-100-2026.md`: 6 countries eligible, USD-denominated ARV, no-purchase-necessary clause, region exclusions like Quebec) — koi naya prize-structure banane ki zaroorat nahi thi, sirf legal/privacy/tracking coverage ke gaps the jo upar list hain.

---

## 1. Kya naya bana / patch hua (is package me)

```
Phase-8f-Final-Gaps/
├── PHASE-8f-README.md                                    ← ye file
│
├── 8b_supporting_files_patched/
│   └── 04-landing-page-contest-entry.html                ← PATCHED: sends contest_id now, not just campaign_slug
│   └── 02-landing-page-referral.html                     ← PATCHED: self-serve "generate link" replaced with
│                                                             "request link" (manual issuance) + a working
│                                                             "confirm existing code" box wired to the real webhook
│   └── (baaki sab files unchanged, yahan sirf reference ke liye copy hain)
│
├── Privacy-8.4-8.6/
│   └── 03-Privacy-Notice-UGC-Community-Signal-Data.md     ← NEW: 8.4/8.5/8.6 ka apna privacy notice (Parts A/B/C/D)
│
└── Cookie-Consent/
    ├── 00-Cookie-and-Tracking-Notice.md                   ← NEW: site-wide cookie/tracking policy doc
    └── 01-cookie-consent-banner-snippet.html              ← NEW: drop-in banner (EU/UK opt-in default), paste
                                                               before </body> on all 6 landing pages
```

### 1.1 Fix details (already applied, code diff summary)
- **8.1 contest entry page:** ab ek `CONTEST_ID` constant add hai jo payload me `contest_id` bhejta hai (jo `workflow.json` actually padhta hai), `campaign_slug` bhi saath rehta hai (harmless, sirf logging ke liye). Real `CONTEST_ID` `01-ACTIVATE-LAUNCH-CAMPAIGNS.sql` chalane ke baad milega — file ke top comment me exact query di hai.
- **8.2 referral page:** "Generate My Link" button ab ek lead-capture request bhejta hai (koi bhi generic intake webhook — CRM ya 1.3 Website-Lead-Capture spoke), fake-code preview hata diya gaya. Ek naya "Already have a code?" box add kiya jo **actual** 8.2 webhook (`referral-submit`, jo existing code lookup karta hai) ko sahi se call karta hai. Jab tak 8.2 me `/referral-generate-code` naya webhook branch nahi banta (QA doc ka Option B — n8n workflow edit, is package ke scope se bahar), yahi safe launch path hai.

### 1.2 New legal/privacy docs
- **`03-Privacy-Notice-UGC-Community-Signal-Data.md`** — existing `03-Privacy-Notice-Contest-Data.md` ke saath side-by-side rakhna hai, replace nahi karna. Content License (8.4), Community moderation data (8.5), aur **8.6 ka sabse zyada legally-sensitive hissa — public-signal se collect ki gayi data pe processing ka legal basis** (GDPR legitimate-interest balancing) — teeno cover hote hain.
- **`00-Cookie-and-Tracking-Notice.md` + banner snippet** — EU/UK ke liye default **opt-in** (PECR requirement), baaki regions ke liye bhi same strictest-baseline use kiya gaya taaki region-detection logic na chahiye ho. Koi bhi form submission consent ke peeche gated nahi hai.

---

## 2. Har engine ka final supporting-file status (poora Phase 8 audit)

| Engine | T&C / Rules | Privacy | Landing page(s) | SQL | Cookie notice |
|---|---|---|---|---|---|
| 8.1 Contest | ✅ T&C + Official Rules | ✅ (shared 8.1-8.3 notice) | ✅ entry + winner pages (entry page **patched**) | ✅ migrations + seed data | ✅ (new, this package) |
| 8.2 Referral | ✅ Program Terms | ✅ (shared 8.1-8.3 notice) | ✅ referral page (**patched**) | ✅ seed data | ✅ (new) |
| 8.3 Free-Audit | ✅ Audit Terms | ✅ (shared 8.1-8.3 notice) | ✅ audit request page | ✅ seed data | ✅ (new) |
| 8.4 UGC | ✅ Submission Terms + Content License | ✅ **(new, this package)** | ✅ showcase page | ✅ seed data | ✅ (new) |
| 8.5 Community | ✅ Guidelines + Partner Terms | ✅ **(new, this package)** | ✅ founders-circle page | ✅ seed data | ✅ (new) |
| 8.6 Signal-Outreach | ✅ Compliance Notes (acts as its rules doc — no entry form, so no separate T&C needed) | ✅ **(new, this package)** | ✅ opt-out page | ⚠️ no dedicated `campaigns` row (correct — it's not campaign-scoped) | ✅ (new) |
| 8.7 Dashboard | N/A (internal-only, no public-facing surface) | N/A | N/A | ✅ `02-PHASE-8c-DASHBOARD-VIEWS.sql` | N/A |
| Cross-cutting | ✅ Country-Specific Legal Notes | — | — | ✅ activation + weekly-review SQL | — |

Har cell jo pehle se ✅ tha, unme koi change nahi kiya — sirf jo genuinely khaali tha (Privacy for 8.4-8.6, Cookie notice everywhere, 2 landing-page wiring bugs) wahi close kiya hai.

---

## 3. Build order (isko run karne ka sahi sequence)

1. Agar 8a-8e abhi tak activate nahi kiye, pehle unka existing order follow karo (8a → 8b → 8c → 8d → 8e, jaisa main plan me hai).
2. **`8b_supporting_files_patched/`** ki 2 patched HTML files apne live 8b folder me overwrite karo (same filenames, seedha replace).
3. **`Privacy-8.4-8.6/03-Privacy-Notice-UGC-Community-Signal-Data.md`** ko apne 8.4/8.5/8.6 landing pages (showcase, founders-circle, opt-out) ke footer me link karo — jaise 8.1-8.3 ki pages already `03-Privacy-Notice-Contest-Data.md` link karti hain.
4. **`Cookie-Consent/01-cookie-consent-banner-snippet.html`** ko sabhi 6 live landing pages me `</body>` se pehle paste karo, aur footer me ek `id="cookieSettingsLink"` wala "Cookie settings" link add kar do (banner reopen karne ke liye).
5. Har `{{...}}` placeholder (`{{legal_entity_name}}`, `{{privacy_contact_email}}`, `{{last_updated_date}}`, `{{support_email}}`) ek hi baar sabhi files me find-replace kar do — abhi tak alag-alag files me alag inconsistent ho sakta hai.

---

## 4. Ab bhi jo aapko karna hai (business/legal decision — main nahi bana sakta)

| Kaam | Kyun aapka hai |
|---|---|
| `CONTEST_ID` real number daalna (8.1 page) | `01-ACTIVATE-LAUNCH-CAMPAIGNS.sql` chalane ke baad hi pata chalega |
| `LEAD_WEBHOOK_URL` (8.2 page) kisi real intake endpoint se point karna | Aapka CRM/lead-capture setup |
| Option B: 8.2 me naya `/referral-generate-code` webhook — n8n workflow edit | JSON-level change hai, is (non-JSON supporting files) package ke scope se bahar — agla batch me bologe to ban jaayega |
| Sab `{{...}}` placeholders (entity name, emails, dates) final values se replace karna | Business info |
| Legal review: (a) 8.6 ka GDPR legitimate-interest balancing, (b) cookie banner ka fraud-signal "necessary" classification, (c) contest/lottery-law sign-off jo pehle se `03-Country-Specific-Legal-Notes.md` me flag hai | Lawyer, na ki main |

---

## 5. Progress tracker addition (append to main Phase 8 tracker, Section 9)

| # | Task | Status |
|---|---|---|
| 24 | 8.1/8.2 landing-page wiring bugs (QA Findings 1 & 2) fix | ✅ Done (this package) |
| 25 | Privacy Notice for 8.4/8.5/8.6 | ✅ Done (this package) |
| 26 | Site-wide Cookie/Tracking Consent notice + banner | ✅ Done (this package) |
| 27 | All `{{...}}` placeholders replaced with real values | ⬜ Aapka kaam |
| 28 | 8.2 Option B (`/referral-generate-code` webhook) — n8n build | ⬜ Agla batch, bologe to bana dunga |
| 29 | Legal review (GDPR legitimate-interest + cookie/fraud-signal + contest law sign-off) | ⬜ Aapka kaam |
