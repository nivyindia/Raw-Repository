# Cookie & Tracking Notice
**[TEMPLATE — site-wide, applies to every landing page across 8.1–8.6. Nothing in the current 8a/8b/8c/8d supporting-file set covered this; every landing page currently sets `campaign_slug`/fraud/UTM tracking without a cookie disclosure, which is a real gap for EU/UK (PECR) and similar jurisdictions.]**

*Last updated: {{last_updated_date}} · Version 1.0*

## 1. What this covers
Every Growth Engine landing page (8.1 contest entry, 8.2 referral, 8.3 free audit, 8.4 showcase, 8.5 Founders Circle invite, 8.6 opt-out page) uses a small amount of browser storage and request-level tracking to make campaigns work. This notice explains what, and gives you control over the non-essential part.

## 2. What we use

| Type | Examples on our pages | Essential? | Can you opt out? |
|---|---|---|---|
| **Strictly necessary** | Session token for a multi-step form (e.g. contest entry in progress); CSRF protection | Yes | No — required for the page to function |
| **Campaign attribution** | `campaign_slug` / `?c=` query param read into the form payload; `utm_source`/`utm_medium` capture | No | Yes |
| **Fraud/dedupe signal** | IP address + submission timestamp, used server-side by the fraud-score check (Section 2 of the Implementation Plan) | Partially — needed to keep contests/referrals fair | Limited — declining may increase manual review time for your entry, but never blocks entry |
| **Analytics** | Aggregate page-view/conversion tracking (if/when a analytics tag is added) | No | Yes |

We do **not** use third-party advertising cookies or cross-site ad-retargeting pixels on any Phase 8 landing page as currently built.

## 3. Consent banner behavior
- On first visit, a banner offers **Accept all**, **Necessary only**, and a link to this notice.
- Choice is remembered locally so the banner doesn't reappear every visit.
- Declining non-essential tracking still lets you complete any form (enter a contest, request an audit, request a referral link) — no functionality is gated behind analytics/attribution consent.
- The fraud/dedupe signal (IP + timestamp) is treated as necessary-for-fairness in a contest/referral context and isn't part of the accept/decline toggle, consistent with how sweepstakes fraud prevention is normally justified under legitimate interest — flag this specific point to counsel if a strict PECR reading is required for your target markets.

## 4. Regional notes
- **EU/UK (PECR + GDPR):** non-essential cookies/tracking require **prior opt-in** consent, not opt-out. The banner must default to nothing-but-necessary until the visitor actively accepts.
- **California (CCPA/CPRA):** no sale/sharing of personal information occurs via these pages; a "Do Not Sell/Share" mechanism is not required but the notice link is still shown for transparency.
- **Other regions:** default to the EU/UK opt-in behavior everywhere, since it's the strictest baseline and avoids region-detection complexity on static pages.

## 5. Your choices
Change your preference any time via the "Cookie settings" link in the page footer (added by the snippet below), or by clearing your browser's local storage for this site.

## 6. Contact
{{legal_entity_name}} · {{privacy_contact_email}}

---
> ⚠️ Template only. Have counsel confirm whether the fraud/dedupe signal's "necessary" classification (Section 3) holds up if you actively target EU/UK entrants at volume — some regulators expect even fraud-prevention identifiers to be disclosed with more granularity than shown here.
