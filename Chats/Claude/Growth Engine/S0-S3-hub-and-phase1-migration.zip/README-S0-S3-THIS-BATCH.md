# S0–S3 — Hub Build + Phase 1 Migration (this batch)

## Gap found before starting (disk-checked, not chat-log-checked)

1. **S0–S2 (Hub-Intake, Hub-Dispatcher, `funnel_events` table) did not exist
   anywhere in any uploaded zip.** Grepped every extracted zip for
   `funnel_events`, `Hub-Intake`, `Hub-Dispatcher`, `Report to Hub` — zero
   hits. Only the plan doc existed, not the files. Built for real in this
   batch (see below).
2. **Two of your top-level uploads — `growth-engine-automation-FIXED.zip` and
   `growth-engine-automation-FIXED__1_.zip` — are stale.** Both still have
   the pre-F3.1 12-node version of `1.5-central-crm-sync` (missing the
   `Detect Unmatched Stage` / `Log Unmatched Stage Event` nodes). The correct
   14-node patched version was only inside `files__4_.zip`'s embedded
   `growth-engine-automation-FIXED.zip`. **Used that one as the base for
   everything in this batch.** Worth deleting the two stale standalone copies
   so a future session doesn't grab them by mistake.

## What's actually in this zip

- `growth-engine-automation/phase-0-hub/hub-intake/workflow.json` — S1
- `growth-engine-automation/phase-0-hub/hub-dispatcher/workflow.json` — S2
  (Phase 1 branches only: `lead.qualified`, `lead.booked`, `proposal.ready`,
  `client.won` — the other event types in the taxonomy doc are S4/S5/S6 scope,
  not built yet, and correctly fall through to `flagged_events` until they are)
- `growth-engine-automation/phase-1/1.3-website-lead-capture/workflow.json` — S3.1
- `growth-engine-automation/phase-1/1.4-inbound-form-qualification/workflow.json` — S3.2
- `growth-engine-automation/phase-1/1.5-central-crm-sync/workflow.json` — S3.3
  (14 nodes → 5 nodes: kept trigger/detect/upsert, replaced 4 IF + 4 Execute
  Workflow + unmatched-stage-logging + Odoo-notify with `Map Stage to Event
  Type` → `Report to Hub`)
- `growth-engine-automation/phase-1/1.1-*`, `1.2-*` — copied unchanged (S3.4,
  confirmed no cross-module hand-off exists for these, nothing to do)
- `master-migrations/00-MASTER-MIGRATIONS.sql` — adds `funnel_events` +
  `flagged_events` (S0.1), everything else carried over unchanged from the F6.1
  batch
- `docs/S0-EVENT-TYPE-TAXONOMY.md` — S0.2/S0.3

## What's NOT done yet (by design — this batch is S0–S3 only)

- S4 (Phase 2, 9 modules), S5 (Phase 4–5, 8 modules), S6 (Phase 6–7, 13
  modules), S7 (decommission old mesh + Metabase dashboard + docs) — all still
  open per the plan. Say the word for the next batch.
- `1.5`'s old 4 direct `Execute Workflow` nodes to 2.1/2.4/2.5/2.7 are now
  fully removed from 1.5 — **but those 4 spokes (2.1, 2.4, 2.5, 2.7) haven't
  been given an `Execute Workflow Trigger` input yet** (that's S4 work on the
  *receiving* end). Until S4 runs, Hub-Dispatcher's `Execute Workflow` calls to
  them will work exactly as well as 1.5's old direct calls did before — no
  regression, since none of that changed on the 2.x side.
- Real workflow IDs (`REPLACE_WITH_...`) still need filling in for Hub-Intake
  and the 4 spoke targets in Hub-Dispatcher — same placeholder convention as
  every other module in the audit, one place now instead of four.
- Per plan §2 risk notes: **S3.3 (1.5 rewiring) is the highest-risk single
  step.** Recommend testing in a maintenance window and keeping this batch's
  pre-patch 14-node `1.5` (from `files__4_.zip`) available to roll back to for
  one business cycle before deleting it.

## Suggested test order (S1.4, S2.8, S3.5)

1. Import Hub-Intake, call it manually with a dummy `lead.qualified` event —
   confirm a row lands in `funnel_events`.
2. Import Hub-Dispatcher, confirm it picks up that dummy row and dispatches to
   2.1 Outreach (once its workflow ID is filled in), flips to `done`.
3. Submit one test lead through Typebot end-to-end: 1.3 → Hub → (nothing
   consumes `lead.captured` yet, expected) ... 1.4 fires independently on its
   own webhook → Hub → 1.5 (on its next 5-min poll) → Hub → 2.1. Confirm a
   `funnel_events` row at every hop.
