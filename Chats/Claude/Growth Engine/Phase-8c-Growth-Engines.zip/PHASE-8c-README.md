# Phase 8c — Baaki 4 Engines (Done)

Implementation Plan ke Section 6, **Phase 8c** ke tasks #11–14 complete ho
gaye — 8.4, 8.5, 8.6 (workflows) aur 8.7 (dashboard views). Built strictly
off the actual 8.1/8.2/8.3 files (8a.zip) ke conventions — same node-ID
style (`n1`, `n2`, `hn1`...), same `campaigns` table lookup pattern, same
Report-to-Hub node shape (`__rl` workflowId format), same NoOp placeholders
for channel-sends jinhe aap apne credentials se wire karoge.

---

## 1. Module 8.4 — UGC / Share Engine

**File:** `8.4-UGC-Share-Engine.json` (16 nodes)

**Flow:** Webhook (`/ugc-submit`) → campaign lookup (required, UGC campaigns
are always tied to a specific push, unlike 8.3's optional lookup) →
normalize → upsert `clients_master` → **verification heuristic** (proof-URL
format + allowed-platform check + caption presence, `campaigns.config`-driven
threshold) → insert `ugc_submissions` → auto-verified path reports to Hub
immediately, low-trust path flags for manual review (Odoo Discuss
placeholder).

**Manual-review branch:** same async shape as 8.1's "Manual Trigger - Run
Winner Selection" — a `Manual Trigger` + `Set - Which Submission (EDIT
BEFORE RUN)` node pair for approving a flagged submission by hand, which
then reports the same `ugc.submission_verified` event so downstream
consumers don't need to know which path a submission took.

**Tables used:** `campaigns`, `clients_master`, `ugc_submissions` — all
already in `01-PHASE-8-MIGRATIONS.sql` (v2), no new migration needed.

**⚠️ Flagged gap, not fixed in this batch:** per the Implementation Plan's
own event table, `ugc.submission_verified` should fan out to **8.2** (to
auto-generate a referral link for verified UGC submitters). 8.2 as it
exists today has no trigger entry-point for this event — adding one means
patching 8.2 itself, which is out of this batch's scope (8c = build 8.4/
8.5/8.6/8.7, not modify 8.1–8.3 again). Flagging clearly so it's not
silently missed — say the word if you want that patch done.

---

## 2. Module 8.5 — Community Engine

**File:** `8.5-Community-Engine.json` (16 nodes)

**Flow:** Webhook (`/community-join`) → campaign lookup (required) →
normalize → upsert `clients_master` → duplicate-membership check → insert
`community_members` → welcome-message placeholder → Report to Hub
(`community.member_joined`).

**Bonus (optional, included since the Plan's generic pattern mentions
"event/content drip"):** a `Daily 10AM - Drip Check` scheduled branch that
reads `campaigns.config.drip_sequence` (array of `{day_offset, message}`)
and fires a send-placeholder. **Known limitation, flagged in-file:** this
does NOT track per-member drip progress (which message each member is on)
— it's a simple existence-check, not a full state machine. If real drip
sequencing is needed, this node needs a `community_members` column like
`last_drip_sent_at` and a re-query — didn't build that speculatively since
the Plan didn't specify drip depth.

**Advocacy trigger:** the Plan mentions "advocacy trigger" as part of this
engine's generic shape — didn't build a new one here since v6 already has
`advocate.flagged` (from 6.9) covering this exact concept. No duplicate
built; if 8.5 members should also be able to trigger advocacy status,
that's a cross-link to design later, not a new event type.

---

## 3. Module 8.6 — Signal-Based Outreach Engine

**File:** `8.6-Signal-Based-Outreach-Engine.json` (16 nodes)

**Two entry points, one shared downstream chain:**

1. **`Webhook - External Signal Ingest`** (`/signal-ingest`) — for any
   external signal source (future job-portal scraper, funding-news watcher,
   manual hook). Normalizes → feeds the shared chain.
2. **`From Hub-Dispatcher (winback.escalated)`** — 6.5 Churn Win-back
   already produces this event, but per `docs/S0-EVENT-TYPE-TAXONOMY.md`
   it had **no consumer wired**. 8.6 becomes that consumer now — a
   churn-risk escalation is treated as a `reactivation`-type signal,
   reshaped into the same shape the external branch uses, then joins the
   same downstream chain.

**Shared chain:** insert `signal_leads` → Ollama AI-relevance scoring
(same `httpRequest` pattern as 8.3's analysis node) → threshold gate
(hardcoded 60 — not campaign-scoped since this table intentionally isn't
tied to one campaign window) → if contact info exists, upsert
`clients_master` + queue outreach → Report to Hub (`signal.lead_flagged`).

**Known limitation, flagged in-file:** many raw hiring/news signals won't
come with a direct email/phone yet (needs manual research first) — the
upsert node handles a blank email gracefully but won't produce a useful
`clients_master` row in that case. Low-priority fix if it matters:
route contact-less high-score signals to a manual-research queue instead
of silently attempting an empty-email upsert.

**⚠️ Flagged gap, not fixed in this batch:** same shape as 8.4's gap —
`signal.lead_flagged` should fan into **2.1 Outreach** per the Plan's event
table, but 2.1 doesn't have a trigger entry-point for it yet. Flagging,
not silently building it into 2.1.

---

## 4. Module 8.7 — Dashboard (no n8n workflow, as planned)

**File:** `02-PHASE-8c-DASHBOARD-VIEWS.sql`

8 `CREATE OR REPLACE VIEW` statements, all safe to re-run:

| View | Covers |
|---|---|
| `growth_campaign_performance` | Every campaign, engine-agnostic, driven off `funnel_events` |
| `contest_performance` | 8.1 — entries, fraud rate, winners, per contest |
| `referral_performance` | 8.2 — funnel (submitted→booked→converted→paid), reward liability |
| `audit_engine_performance` | 8.3 — volume, avg score, later-qualified conversion |
| `ugc_engine_performance` | 8.4 — submissions, verification rate, points |
| `community_engine_performance` | 8.5 — membership growth, roles |
| `signal_outreach_performance` | 8.6 — by signal_type (not campaign-scoped, matches the table's own design), reply rate |
| `growth_engine_summary` | One-row-per-engine top-level glance |

Point Metabase directly at these views — no raw table access needed for
the dashboard build. Works with zero rows too (just returns empty), so
it's safe to run before any campaign goes live.

---

## 5. Validation

All 3 workflow files: JSON parses clean, no duplicate node IDs, no
dangling connections (checked programmatically, same bar as v6/8a). One
correctness fix made during build: 8.6's `Code - Parse AI Score` node
originally referenced only one of its two possible upstream `Set` nodes by
name — since only one of the two entry-point branches actually executes
per run, the other reference would throw ("referenced node is
unexecuted"). Fixed with a try/catch fallback, same defensive pattern
already used in 8.1's `Code - Fraud Score` node for optional upstream
config lookups.

---

## 6. What's NOT done (matches the Plan's own phasing — this is 8d/8e work)

- Import into n8n, Hub-Intake ID fill-in (3 places in 8.4, 1 in 8.5, 1 in
  8.6 — the two Report-to-Hub nodes in 8.4 both need it, same in 8.6).
- Hub-Dispatcher: no new branches added yet. Per the Plan's own Section 6,
  this is **Phase 8d** work (step 18: "Dispatcher — baaki sab naye event
  IDs bharo"), done once all engines are imported, not per-engine — same
  order 8a/8b already established (8a/8b's own Dispatcher wiring, task #10
  in the tracker, is also still `⬜` as of this session).
- WhatsApp/Telegram/Email NoOp nodes → real credentials (5 placeholders
  across 8.4/8.5/8.6: UGC welcome-flag alert, community welcome message,
  community drip content, signal outreach queue message).
- The two flagged spoke→spoke Hub gaps (`ugc.submission_verified` → 8.2,
  `signal.lead_flagged` → 2.1) — need small patches to 8.2 and 2.1
  respectively to add trigger entry-points. Not done here since it's
  scope creep on "build 8.4/8.5/8.6/8.7" — say the word if you want these
  next.

---

## 7. Progress Tracker update

Implementation Plan's tracker, **8c section**, all 4 rows can move to ✅:

| # | Task | Status |
|---|---|---|
| 11 | 8.4 UGC/Share Engine — build | ✅ |
| 12 | 8.5 Community Engine — build | ✅ |
| 13 | 8.6 Signal-Based Outreach Engine — build | ✅ |
| 14 | 8.7 Dashboard views (Metabase/SQL) — build | ✅ |

**Agla step:** Phase 8d — import all 6 engines (8.1–8.6), fill Hub-Intake
IDs everywhere, then Hub-Dispatcher branches for all the new event types at
once (Section 2 of the Implementation Plan has the full list).
