-- ============================================================
-- Module 8.7 — Growth Dashboard / Analytics
-- No n8n workflow (per the Implementation Plan, Section 1 —
-- 8.7 is a reporting rollup, not an automation spoke). Run this
-- AFTER 01-PHASE-8-MIGRATIONS.sql, and after 8.4/8.5/8.6 have
-- been imported and have at least some live data (views work
-- fine with zero rows too, just return empty).
-- Safe to re-run: every statement is CREATE OR REPLACE VIEW.
-- ============================================================

-- ------------------------------------------------------------
-- 1. Overall campaign performance — one row per campaign,
--    engine-agnostic, driven off funnel_events (every engine's
--    Report to Hub node writes here regardless of which table
--    it's backed by).
-- ------------------------------------------------------------
CREATE OR REPLACE VIEW growth_campaign_performance AS
SELECT
  c.id AS campaign_id,
  c.campaign_slug,
  c.engine,
  c.campaign_type,
  c.status,
  c.starts_at,
  c.ends_at,
  COUNT(fe.id) AS total_events,
  COUNT(DISTINCT fe.client_id) AS unique_participants
FROM campaigns c
LEFT JOIN funnel_events fe ON (fe.payload->>'campaign_id')::int = c.id
GROUP BY c.id, c.campaign_slug, c.engine, c.campaign_type, c.status, c.starts_at, c.ends_at
ORDER BY c.starts_at DESC NULLS LAST;

-- ------------------------------------------------------------
-- 2. 8.1 Contest performance — entries, fraud-rate, verified vs
--    pending, per contest (not per campaign, since one campaign
--    can technically back multiple contests).
-- ------------------------------------------------------------
CREATE OR REPLACE VIEW contest_performance AS
SELECT
  ct.id AS contest_id,
  ct.name,
  ct.status,
  cm.campaign_slug,
  COUNT(ce.id) AS total_entries,
  COUNT(*) FILTER (WHERE ce.verified) AS verified_entries,
  COUNT(*) FILTER (WHERE ce.fraud_score >= COALESCE((ct.config->>'fraud_threshold')::int, 50)) AS flagged_entries,
  ROUND(100.0 * COUNT(*) FILTER (WHERE ce.fraud_score >= COALESCE((ct.config->>'fraud_threshold')::int, 50)) / NULLIF(COUNT(ce.id), 0), 1) AS fraud_rate_pct,
  COUNT(*) FILTER (WHERE ce.is_winner) AS winners_selected
FROM contests ct
LEFT JOIN campaigns cm ON cm.id = ct.campaign_id
LEFT JOIN contest_entries ce ON ce.contest_id = ct.id
GROUP BY ct.id, ct.name, ct.status, cm.campaign_slug
ORDER BY total_entries DESC;

-- ------------------------------------------------------------
-- 3. 8.2 Referral performance — per campaign, funnel from
--    submitted -> meeting_booked -> converted -> paid, plus
--    total reward liability (approved + pending, not yet paid).
-- ------------------------------------------------------------
CREATE OR REPLACE VIEW referral_performance AS
SELECT
  cm.id AS campaign_id,
  cm.campaign_slug,
  COUNT(rl.id) AS total_referrals,
  COUNT(*) FILTER (WHERE rl.stage = 'meeting_booked') AS meetings_booked,
  COUNT(*) FILTER (WHERE rl.stage = 'converted') AS converted,
  COUNT(*) FILTER (WHERE rl.stage = 'paid') AS paid,
  ROUND(100.0 * COUNT(*) FILTER (WHERE rl.stage IN ('converted','paid')) / NULLIF(COUNT(rl.id), 0), 1) AS conversion_rate_pct,
  SUM(rl.reward_amount) FILTER (WHERE rl.reward_status IN ('pending','approved')) AS reward_liability_outstanding,
  SUM(rl.reward_amount) FILTER (WHERE rl.reward_status = 'paid') AS reward_paid_total
FROM campaigns cm
JOIN referral_codes rc ON rc.campaign_id = cm.id
LEFT JOIN referral_ledger rl ON rl.referral_code_id = rc.id
WHERE cm.engine = '8.2'
GROUP BY cm.id, cm.campaign_slug
ORDER BY total_referrals DESC;

-- ------------------------------------------------------------
-- 4. 8.3 Free-Value / Audit performance — volume + average
--    score + how many audit-requesters later entered the main
--    funnel (joined via clients_master.id showing up in
--    funnel_events with a later lead.qualified event).
-- ------------------------------------------------------------
CREATE OR REPLACE VIEW audit_engine_performance AS
SELECT
  ar.audit_type,
  cm.campaign_slug,
  COUNT(ar.id) AS total_requests,
  ROUND(AVG(ar.score), 1) AS avg_score,
  COUNT(DISTINCT fe.client_id) FILTER (WHERE fe.event_type = 'lead.qualified') AS later_qualified_count
FROM audit_requests ar
LEFT JOIN campaigns cm ON cm.id = ar.campaign_id
LEFT JOIN funnel_events fe ON fe.client_id = ar.client_id AND fe.event_type = 'lead.qualified' AND fe.created_at > ar.completed_at
GROUP BY ar.audit_type, cm.campaign_slug
ORDER BY total_requests DESC;

-- ------------------------------------------------------------
-- 5. 8.4 UGC performance — submissions, verification rate,
--    points awarded, per campaign and platform.
-- ------------------------------------------------------------
CREATE OR REPLACE VIEW ugc_engine_performance AS
SELECT
  cm.campaign_slug,
  COUNT(us.id) AS total_submissions,
  COUNT(*) FILTER (WHERE us.verification_status = 'verified') AS verified_submissions,
  COUNT(*) FILTER (WHERE us.verification_status = 'pending') AS pending_review,
  COUNT(*) FILTER (WHERE us.verification_status = 'rejected') AS rejected,
  SUM(us.points_awarded) AS total_points_awarded
FROM campaigns cm
LEFT JOIN ugc_submissions us ON us.campaign_id = cm.id
WHERE cm.engine = '8.4'
GROUP BY cm.campaign_slug
ORDER BY total_submissions DESC;

-- ------------------------------------------------------------
-- 6. 8.5 Community growth — membership over time, per campaign.
-- ------------------------------------------------------------
CREATE OR REPLACE VIEW community_engine_performance AS
SELECT
  cm.campaign_slug,
  COUNT(cmem.id) AS total_members,
  COUNT(*) FILTER (WHERE cmem.role = 'partner') AS partner_members,
  COUNT(*) FILTER (WHERE cmem.role = 'moderator') AS moderators,
  MIN(cmem.joined_at) AS first_joined,
  MAX(cmem.joined_at) AS last_joined
FROM campaigns cm
LEFT JOIN community_members cmem ON cmem.campaign_id = cm.id
WHERE cm.engine = '8.5'
GROUP BY cm.campaign_slug
ORDER BY total_members DESC;

-- ------------------------------------------------------------
-- 7. 8.6 Signal-outreach performance — not campaign-scoped
--    (matches the table's own design), broken out by signal_type
--    instead, funnel from new -> queued -> sent -> replied.
-- ------------------------------------------------------------
CREATE OR REPLACE VIEW signal_outreach_performance AS
SELECT
  signal_type,
  COUNT(*) AS total_signals,
  ROUND(AVG(ai_score), 1) AS avg_ai_score,
  COUNT(*) FILTER (WHERE outreach_status = 'sent') AS sent,
  COUNT(*) FILTER (WHERE outreach_status = 'replied') AS replied,
  COUNT(*) FILTER (WHERE outreach_status = 'ignored') AS ignored_low_score,
  ROUND(100.0 * COUNT(*) FILTER (WHERE outreach_status = 'replied') / NULLIF(COUNT(*) FILTER (WHERE outreach_status = 'sent'), 0), 1) AS reply_rate_pct
FROM signal_leads
GROUP BY signal_type
ORDER BY total_signals DESC;

-- ------------------------------------------------------------
-- 8. Top-level rollup — one row per engine, for a single
--    "how's growth-hacking doing overall" glance.
-- ------------------------------------------------------------
CREATE OR REPLACE VIEW growth_engine_summary AS
SELECT
  engine,
  COUNT(DISTINCT id) AS active_campaigns,
  SUM(CASE WHEN status = 'active' THEN 1 ELSE 0 END) AS currently_active
FROM campaigns
GROUP BY engine
ORDER BY engine;

-- ============================================================
-- End of 8.7 Dashboard views.
-- Point Metabase at these 8 views directly -- no raw table
-- access needed for the dashboard build. If Metabase isn't live
-- yet, these are still queryable ad-hoc via psql/pgAdmin in the
-- meantime.
-- ============================================================
