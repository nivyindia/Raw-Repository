# S0.2 / S0.3 — `event_type` Taxonomy (living reference)

One row per cross-module hand-off, current or planned. "Wired" = a Hub-Dispatcher
Switch branch actually exists for it as of this batch. Everything else falls
through to `flagged_events` + the Odoo Discuss alert (S2.4) until it's built.

| event_type | Reported by | Consumed by | Wired in Dispatcher? |
|---|---|---|---|
| `lead.captured` | 1.3 (new, this batch) | *(nothing subscribes yet — logged for traceability)* | No — falls to flagged_events, harmless (informational event, no action expected) |
| `lead.qualified` | 1.4, 1.5 | 2.1 Outreach | **Yes** |
| `lead.booked` | 1.5 | 2.4 Proposal Generation | **Yes** |
| `proposal.ready` | 1.5 | 2.5 Contract E-sign | **Yes** |
| `client.won` | 1.5 | 2.7 Onboarding | **Yes** |
| `lead.replied` | 2.1 (planned, S4.1) | — | No — S4 |
| `contract.signed` | 2.5 (**built, this batch**) | 2.6 Invoice Payment | No — Dispatcher branch not wired yet, falls to flagged_events |
| `payment.received` | 2.6 (**built, this batch**) | 2.7 Onboarding | No — Dispatcher branch not wired yet, falls to flagged_events |
| `client.onboarded` | 2.7 (**built, this batch**) | — (hook for future Phase 6 work) | No — Dispatcher branch not wired yet, falls to flagged_events |
| `renewal.due` | 2.9 (**built, this batch** — not 2.8, see 2.8's README for why) | 6.x churn/win-back | No — Dispatcher branch not wired yet, falls to flagged_events |
| `renewal.overdue` | 2.9 (**built, this batch**) | 6.5 Churn Win-back (S6.6) | No — Dispatcher branch not wired yet, falls to flagged_events |
| `payment.failed` | 2.9 (**built, this batch**) | — | No — Dispatcher branch not wired yet, falls to flagged_events |
| `health.scored` | 6.1.1 (planned, S6.1) | 6.2.2, 6.4.1 | No — S6 |
| `reply.received` | 4.3.x (planned, S5.1) | 5.1.1 | No — S5 |
| `qualification.scored` / `qualification.written` | 5.1.1 / 5.1.2 (planned, S5.2/S5.3) | — | No — S5 |
| `deliverability.alert` | 7.1 (planned, S6.7) | — | No — S6 |
| `nps.promoter_flagged` | 6.6 (planned, S6.4) | 6.7, 6.8 | No — S6 |
| `advocate.flagged` | 6.9 (planned, S6.6) | — | No — S6 |
| `winback.escalated` | 6.5 (planned, S6.3) | — | No — S6 |

## Note on `lead.captured`

The plan's S0.2 minimum set didn't include this one, but S3.1 explicitly asks
1.3 to report `event_type: lead.captured` after `Insert into clients_master`.
It's wired into 1.3 and lands in `funnel_events` for traceability, but since
nothing currently needs to *react* to a raw capture (1.4 is triggered by its
own webhook, not by this event), it isn't given a Dispatcher branch yet — it'll
fall to `flagged_events` every time, which is expected, not a bug. If a future
module wants to react to raw captures, add its branch then; don't remove the
report from 1.3 in the meantime.

## Note on `contract.signed` (S4.4, this batch)

2.5 Contract E-Sign now reports `contract.signed` to the Hub instead of
calling 2.6 directly (`Execute Workflow - 2.6 Invoice + Payment` removed).
This is spoke-side only — Hub-Dispatcher's Switch node does **not** have a
`contract.signed` branch yet (that's the rest of S4, not built in this
step). Until that branch + 2.6's real workflow ID are added to the
Dispatcher, every `contract.signed` event lands in `funnel_events` and then
falls through to `flagged_events`, same as any other unwired event type —
invoices just need triggering manually until then, nothing breaks.

## Status

This is the S3 (Phase 1) + S4.4–S4.7 (S4b batch) snapshot. Phase 2 spoke-side
work is now complete: 2.5, 2.6, 2.7, 2.9 all report their events; 2.4 (S4.3)
and 2.8 (see 2.8's README) were confirmed to need no change or are still
pending in an earlier/later batch. Update this table each time S4c/S5/S6 wire
a new branch — this doc is the "one place" the whole plan is designed around,
so it needs to stay current or it becomes exactly the kind of stale doc the
audit kept finding.

**Still open after this batch:** none of the new event types above are wired
into Hub-Dispatcher's Switch node yet — that's Hub-Dispatcher's own file, not
a spoke change, and isn't part of S3/S4's scope. Every event lands safely in
`funnel_events` and falls through to `flagged_events` until it's wired.
