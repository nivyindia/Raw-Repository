# S4b — Phase 2 close-out: remaining spokes

Is batch me plan ke S4b steps (S4.5, S4.6, S4.7) cover kiye:

| Step | Module | Kya kiya |
|---|---|---|
| S4.5 | 2.6 Invoice + Payment | `Execute Workflow - 2.7` hataya, `Report to Hub` add kiya → `payment.received` |
| S4.6 | 2.7 Client Onboarding | Trigger node ko Dispatcher-triggered clarify kiya, `Report to Hub` add kiya → `client.onboarded` |
| S4.7 | 2.9 Renewal + Revenue Ops | 3 `Report to Hub` nodes add kiye → `renewal.due`, `renewal.overdue`, `payment.failed` |
| — | 2.8 Delivery Reporting | **Koi change nahi** — plan ne isko S4.7 me naam liya tha, lekin module me renewal logic hai hi nahi (dekho `2.8-delivery-reporting/README.md` ka naya section) |

## Common thread har module me

- Jahan bhi `Postgres - Mark ...` query me pehle se `RETURNING *` nahi tha (client_id/odoo_lead_id chahiye the Report to Hub node ke liye), wahan add kiya — 3 jagah ye fix bhi saath me hua.
- Har naya `Report to Hub` node parallel branch me hai (existing alert/email step ke saath), sequential nahi — taaki time-sensitive customer-facing steps (email, alert) Hub ke round-trip se block na ho.
- Har jagah `REPLACE_WITH_0.0_HUB_INTAKE_WORKFLOW_ID` placeholder use hua hai — Hub-Intake ka real ID import ke baad daalna hoga (README me likha hai).

## Jo abhi baaki hai (is batch me scope nahi)

- **Hub-Dispatcher ke Switch node me koi bhi naya branch wire nahi hua** — `payment.received`, `client.onboarded`, `renewal.due`, `renewal.overdue`, `payment.failed` — koi bhi abhi Dispatcher se kisi spoke ko trigger nahi karta. Events `funnel_events` me record honge, `flagged_events` me fall through honge. Ye Hub-Dispatcher ki apni file ka kaam hai, spoke files ka nahi.
- **S4c** (S4.8 test steps + end-to-end validation) is batch me nahi hai.
- 2.4 Proposal Generation (S4.3) is batch me touch nahi hua — pehle se S4 ke pehle 4-step batch me tha, is file me nahi.

## Files is zip me

```
2.6-invoice-payment/   workflow.json + README.md   (S4.5)
2.7-client-onboarding/ workflow.json + README.md   (S4.6)
2.8-delivery-reporting/ workflow.json + README.md  (as-is, note added)
2.9-renewal-revenue-ops/ workflow.json + README.md (S4.7)
docs/S0-EVENT-TYPE-TAXONOMY.md                     (updated)
```
