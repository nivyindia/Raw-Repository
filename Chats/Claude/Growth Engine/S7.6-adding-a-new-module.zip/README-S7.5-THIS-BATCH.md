# S7.5 — Deployment Guide + Module README Update (this batch)

## What S7.5 asks for (from the plan)

> Update `DEPLOYMENT-GUIDE.md` and the module READMEs: replace "copy this
> workflow ID into that placeholder" instructions with "point the
> Dispatcher's Switch node at this workflow's ID" — one place to document
> instead of five.

## Gap found before starting (disk-checked)

The plan's rollout order says do this **after** S4b, S4c, S5, S6 are done —
i.e. after every spoke is migrated. Checked what actually exists on disk:
only **S0–S3** (Hub + Phase 1) and **S4.2** (2.3 Booking Sync) + **S4.4**
(2.5 Contract E-sign) have been built. S4.1, S4.3, S4b, S4c, S5, S6 are all
still open. So a full "rewrite every module README for star topology" pass
right now would be documenting a topology that doesn't exist yet for 2.1,
2.4, 2.6, 2.7, 2.8, 2.9 — exactly the kind of stale doc the original audit
kept finding.

**Decision made this batch:** do S7.5 honestly against current state, not
against the finished plan. Docs now say plainly which modules are Hub-wired
and which are still mesh-wired, so nothing is misdocumented mid-migration.
Update this batch's status tables again after each future S4/S5/S6 batch.

**Second gap found:** `1.5-central-crm-sync/README.md`'s `workflow.json` was
already migrated to star topology back in S3.3, but its `README.md` was
never updated to match — it still documented the old 4-IF/4-Execute-Workflow
version. Fixed in this batch since it's a real doc-code mismatch, not a
premature one.

## What's actually in this zip

- `DEPLOYMENT-GUIDE.md` — Section 9 rewritten: Hub-Intake/Hub-Dispatcher
  import first, then a migration-status table so nobody wires an
  already-migrated spoke the old way (or vice versa), then the one place
  spoke workflow IDs now live (Hub-Dispatcher's Switch node). Section 10
  checklist updated to match. Small pointer added near Section 7 for the
  `funnel_events`/`flagged_events` tables (schema itself lives in
  `00-MASTER-MIGRATIONS.sql`, not duplicated here).
- `Growth Engline-n8n-workflow/README.md` — module status tables now show a
  `Wiring` column (⭐ Star / ⏳ Mesh / no hand-off), import order rewritten,
  "Zaroori" wiring-instructions block split into migrated vs. not-yet-migrated,
  Launch-Readiness Blockers updated with the partial-migration note.
- `Growth Engline-n8n-workflow/growth-engine-automation/phase-1/1.5-central-crm-sync/README.md` —
  full rewrite to match what `workflow.json` has actually done since S3.3:
  diagram, Setup Section 4, Test steps, and Known Limitations all now
  describe "Report to Hub" instead of the old 4-branch Execute Workflow fan-out.

## What's NOT touched (on purpose)

- `2.1-multichannel-outreach/README.md`, `2.4-proposal-generation/README.md`,
  `2.6-invoice-payment/README.md`, `2.7-client-onboarding/README.md`,
  `2.8-delivery-reporting/README.md`, `2.9-renewal-revenue-ops/README.md` —
  left exactly as-is. Their `workflow.json` files are still the old mesh
  version (S4.1/S4.3/S4b/S4c not built yet), so their current
  "copy this workflow ID into that placeholder" instructions are still
  **correct** for what's actually deployed. Rewriting them now would break
  deployment instructions for code that hasn't shipped. Rewrite each one in
  the same batch that migrates its `workflow.json` (S4.1, S4.3, S4.5–S4.8).
- `2.3-booking-sync/README.md` — already updated in the S4.2 batch, not
  touched again here.
- `2.5-contract-esign/README.md` — already updated in the S4.4 batch, not
  touched again here.
- `n8n-Automated-Funnel-Plan.md` — still describes the original mesh design
  end-to-end (it's the pre-star-topology master plan doc, superseded by
  `N8N-Star-Topology-Integration-Plan.md` for the connection-method parts).
  Not in S7.5's literal scope; flagging in case a future session wants a
  pass to reconcile the two, or to mark the old plan doc as superseded.

## Two copies note

Both uploaded zips (`00_Automation.zip`, `00_Marketing.zip`) contain an
identical `00 Automation/` folder — no divergence found this time. Apply
this batch's three changed files to **both** copies (or better, pick one as
canonical and delete the other, per the original audit's §1.1 recommendation)
so they don't start diverging again.

## Suggested next step

S4.1 (2.1 Multichannel Outreach → Hub) or S4.3 (2.4 Proposal Generation →
Hub) — either finishes off S4a properly, and either one's README then
becomes safe to rewrite the way 1.5's was in this batch. Say the word.
