# S7.6 — "Adding a New Module" One-Pager (this batch)

## What S7.6 asks for

> Write a one-page "adding a new module" doc: (1) build the spoke, (2) give
> it an `Execute Workflow Trigger` input if the Hub should call it, (3) add
> a "Report to Hub" node if other modules need to react to it, (4) add one
> Switch branch on the Dispatcher. That's the entire integration cost for
> module #15 onward.

## Why this one didn't have the same gap as S7.5

S7.5 (deployment guide + module READMEs) was partly premature because it
describes *specific* modules, and most of those aren't migrated yet.
S7.6 is different — it documents the *general* star-topology pattern, which
is already fully proven (Hub-Intake, Hub-Dispatcher, and 3 real spokes —
1.3/1.4/1.5 and 2.3, 2.5 — all built and working this way). Nothing here
depends on S4b/S4c/S5/S6 shipping first, so it's safe to write now, as-is.

## What's in this zip

- `Growth Engline-n8n-workflow/ADDING-A-NEW-MODULE.md` — the one-pager.
  Written against the actual node names in the built Hub-Intake/Hub-Dispatcher
  workflows (`Execute Workflow Trigger`, `Report to Hub`,
  `Switch - Route by Event Type`, the `REPLACE_WITH_0.0_HUB_INTAKE_WORKFLOW_ID`
  placeholder convention) — not generic advice, the real thing.
- `DEPLOYMENT-GUIDE.md`, `Growth Engline-n8n-workflow/README.md` — one-line
  pointers added to the new doc (Section 9.4 and the Master Plan section
  respectively). Everything else in both files is unchanged from the S7.5
  delivery — re-download and replace both if you only have the S7.5 copies.

## Suggested next step

Same as last time — S4.1 (2.1 → Hub) or S4.3 (2.4 → Hub) are the next open
items in the plan. Once either lands, its module README becomes safe to
rewrite the way 1.5's was, and this one-pager gets its first real test:
does module #15 (or #16, whichever comes first) actually cost just 4 steps?
