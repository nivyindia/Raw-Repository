# Adding a New Module — Star Topology (one page)

Module #15 se aage har naye module ke liye poora integration cost ye 4 steps hain. Kisi existing spoke ko chhuna nahi padta — sirf Hub-Dispatcher me ek Switch branch add hota hai.

---

## 1. Build the spoke

Apna workflow normal tarike se banao — apna trigger (webhook, schedule, ya Hub se `Execute Workflow Trigger`, Step 2 dekho), apna business logic, apna Postgres/Odoo/whatever step. Star topology ka is par koi asar nahi — ye sirf ye tay karta hai ki module doosre modules se **kaise baat karta hai**, andar kya karta hai wo tumhari marzi.

## 2. `Execute Workflow Trigger` input — sirf agar Hub isse call karega

Agar naya module kisi funnel event ke jawab me trigger hona chahiye (jaise 2.4 ko `lead.booked` par trigger hona hai), workflow ke shuru me ek `Execute Workflow Trigger` node lagao (Hub-Intake/1.5 me jaisa hai). Agar module apna khud ka external trigger already rakhta hai (webhook — Typebot, Cal.com, Documenso, payment gateway jaisa), to ye step **skip karo** — external triggers waise hi rehte hain, Hub unhe replace nahi karta.

## 3. "Report to Hub" node — sirf agar doosre modules ko react karna hai

Agar is module ka outcome kisi aur module ko trigger karna chahiye, workflow ke end me ek `Execute Workflow` node add karo:

- `workflowId`: `REPLACE_WITH_0.0_HUB_INTAKE_WORKFLOW_ID` (Hub-Intake ka actual ID — deployment ke time replace hoga, jaisa har spoke me hota hai)
- Input fields: `event_type` (naya ya existing taxonomy se — Step 4a dekho), `client_id`, `odoo_lead_id`, `source_module` (apna module number), `payload` (jo bhi downstream module ko chahiye)

Agar is module ka outcome kisi ko react karne ke kaam ka nahi (jaise 1.1/1.2/7.2 — koi cross-module hand-off nahi), to ye step bhi **skip karo**.

## 4. Ek Switch branch — Hub-Dispatcher me (yahi asli integration cost hai)

Hub-Dispatcher ke `Switch - Route by Event Type` node me ek naya rule add karo:

- Condition: `{{$json.event_type}}` equals `<naya event_type>`
- `outputKey`: same string
- Us output se ek `Execute Workflow` node jodo, `workflowId` = naye module ka actual workflow ID (import ke baad milega)

Bas. **Koi existing spoke edit nahi hota** — na jisne event report kiya, na jo isse react karega. Sirf Hub-Dispatcher me ek naya branch.

---

## Reference

- Naya `event_type` add karne se pehle `docs/S0-EVENT-TYPE-TAXONOMY.md` check karo — kahin already koi similar event to nahi hai. Naya add karo to us file me bhi row daal do (source module, consumer module, wired status) — ye file "ek jagah" ka poora point hai, stale mat hone do.
- Jab tak Switch branch wire nahi hota, event `funnel_events` me log hoke `flagged_events` me fall through hota hai (Odoo Discuss alert samet) — kuch crash nahi hota, bas automation manual rehta hai us hop ke liye.
- Hub-Intake aur Hub-Dispatcher dono ka `settings.errorWorkflow` audit ke Phase F1 wale shared error handler ko point karta hai — naye module ko apna alag error workflow set karne ki zaroorat nahi jab tak wo Hub ke through hi baat kar raha hai; sirf apni internal logic ke liye (jo Hub se pehle chalti hai) apna error handling rakhna better practice hai.
- Naya module deploy hone ke baad `DEPLOYMENT-GUIDE.md` Section 9.3 ki migration-status table aur top-level `README.md` ki module table dono me ek row add kar dena.
