# Module 1.5 — Central CRM Sync

> **S3.3 + S7.5 update (star topology):** Is workflow ka structure poori tarah badal gaya hai. Pehle ye khud 4 IF nodes se decide karta tha ki kaunsa Phase 2 module trigger karna hai, aur unhe seedha **Execute Workflow** se call karta tha (mesh). Ab ye sirf detect + upsert + "kya hua" batata hai — routing decision **Hub-Dispatcher** ka kaam hai. Neeche pura updated doc hai.

**Kya karta hai:** Ye woh "glue" workflow hai jo Master Plan ke Section 5 (Connection Method) ko actually implement karta hai. Har 5 minute me Odoo CRM (`crm_lead` table) ke andar stage changes detect karta hai, central `clients_master` table ko update (upsert) karta hai, phir jo bhi stage detect hua use ek `event_type` me map karke **Hub-Intake** ko report kar deta hai. Us event ka aage kya hoga (kaunsa Phase 2 module trigger hoga, agar Odoo Discuss alert bhejni hai) — ye sab ab **Hub-Dispatcher** decide karta hai, 1.5 nahi.

Ye module standalone kaam nahi karta — iska pura fayda tab hai jab Hub-Intake/Hub-Dispatcher already ban chuke hon (Phase 0), kyunki ye unhi ko report karta hai.

```
Every 5 min (Schedule)
        ↓
Postgres: crm_lead + crm_stage compare clients_master.status se
   (jo bhi lead ka stage badla hai ya naya hai)
        ↓
Postgres: clients_master UPSERT (naya status + updated_at)
        ↓
Map Stage to Event Type (Qualified→lead.qualified, Booked→lead.booked,
                          Proposal Sent→proposal.ready, Won→client.won)
        ↓
Report to Hub  (Execute Workflow → Hub-Intake)
```

Purane 4 IF nodes, 4 Execute Workflow nodes, aur unmatched-stage-logging/Odoo-Discuss-notify — sab is ek "Report to Hub" call me consolidate ho gaye hain. Unmatched stage (jo `stageMap` me nahi hai) ka event bhi Hub ko chala jaata hai `event_type: null` ke saath — Hub-Dispatcher isse `flagged_events` me daal deta hai (Odoo Discuss alert samet), jo pehle silently drop ho jaata tha.

\* **Note (Phase 2 batch 2 se carry-forward):** Module 2.5's primary/fast trigger ek dedicated webhook hai (client "Accept Proposal" link click karta hai — README 2.5 dekho). `proposal.ready` event yahan safety-net/reminder ke roop me hai — agar koi lead kisi aur tareeke se (phone call) verbally accept kare aur stage manually update ho, to ye polling isse bhi catch kar lega aur Hub ko report kar dega.

## Import Kaise Kare

1. n8n me: **Workflows → Import from File** → `workflow.json`
2. Neeche diye placeholders set karo
3. Workflow **Active** karo

## Setup Karne Se Pehle

### 1. `clients_master` table
Agar Module 1.3 se pehle already bana liya hai to kuch nahi karna. Nahi banaya to Module 1.3 ke README me diya SQL run karo.

### 2. Odoo CRM stages ka naam confirm karo
Ye workflow `crm_stage.name` ko literal string match karta hai (`Qualified`, `Won`, `Proposal Sent`). Odoo CRM → Configuration → Stages me jaake apne pipeline ke exact stage names Master Plan Section 1 wale funnel status ke mutabiq rename kar lo:

`New → Qualified → Contacted → Nurtured → Booked → Proposal Sent → Won → Onboarded → Delivered → Renewal`

Agar naam alag rakhne hain to Node 2 (`Detect CRM Stage Changes`) aur Nodes 4/5/6 (IF conditions) me exact string update kar dena.

### 3. Postgres credential
Same `Odoo Postgres` credential (1.1 se 1.4 tak jo use kiya).

### 4. Hub-Intake workflow ID (zaroori — bina iske ye module Hub ko kuch report nahi kar payega)
`Report to Hub` node me `REPLACE_WITH_0.0_HUB_INTAKE_WORKFLOW_ID` ko Hub-Intake ke actual workflow ID se replace karo (Phase 0 me pehle bana lo — `phase-0-hub/hub-intake/workflow.json`). **Bas ek hi ID chahiye** — 1.5 ko ab 2.1/2.4/2.5/2.7 ka koi ID nahi jaanna, wo routing Hub-Dispatcher ke Switch node me hoti hai (jo module abhi migrate nahi hue — 2.1, 2.4, abhi bhi purani mesh wiring par hain — unke apne Dispatcher branches khaali/placeholder rahenge jab tak unka star-topology batch nahi ban jaata; is se 1.5 ka kaam nahi rukta).

**Jab tak Hub-Intake ID placeholder rehta hai** — `Report to Hub` fail hoga but harmless hai; poora upsert/detect kaam already ho chuka hoga, sirf downstream event report nahi jayega. Production me Active karne se pehle real ID daal dena.

### 5. Odoo Discuss — Environment Variables
`ODOO_URL`, `ODOO_DB`, `ODOO_UID`, `ODOO_API_KEY`, `ODOO_DISCUSS_CHANNEL_ID` — same jo Module 1.4 me use kiye.

## Test Kaise Kare

1. Odoo CRM me ek test lead ka stage manually "Qualified" karo
2. n8n me workflow manually **Execute Workflow** se run karo (5 min wait mat karo)
3. `clients_master` table check karo — status update hua ya nahi (`SELECT * FROM clients_master WHERE odoo_lead_id = <id>;`)
4. `funnel_events` table check karo — ek naya row `event_type = 'lead.qualified'`, `source_module = '1.5'` ke saath aaya ya nahi (`SELECT * FROM funnel_events ORDER BY id DESC LIMIT 5;`)
5. Agar Hub-Dispatcher me is event_type ka Switch branch already wired hai (S3 batch tak sirf `lead.qualified`, `lead.booked`, `proposal.ready`, `client.won` wired hain), confirm karo correct Phase 2 spoke trigger hua aur `funnel_events.status` `done` ho gaya

## Known Limitations (v1)

- **Polling-based hai, real-time nahi** — 5 min ka delay hai, plus Hub-Dispatcher ka apna 1-2 min poll cycle upar se. Agar turant reaction chahiye (e.g. Won hote hi turant onboarding), Odoo Automation Rule (Module 1.4 jaisa) se direct webhook trigger better hoga — is polling module ko sirf "safety net / catch-all sync" ke roop me rakho
- Ab 4 stages (Qualified, Won, Proposal Sent, Booked) `stageMap` me hain (`Map Stage to Event Type` node); baaki stages (Contacted, Nurtured, Onboarded, Delivered, Renewal) abhi `event_type: null` bhejte hain jo Hub-Dispatcher `flagged_events` me log kar deta hai — jab Phase 2 close-out modules (2.8/2.9) ke event types wire ho jayein, `stageMap` me yahan naye entries add karne honge
- `LIMIT 25` per run hai — agar ek saath 25 se zyada leads ka stage change ho (bulk import jaisa case) to kuch is cycle me miss ho ke agle 5-min cycle me pick honge (data loss nahi, sirf delay)
- **Migration status**: 1.5 khud fully Hub-wired hai, lekin isse downstream (2.1, 2.4) abhi purani mesh wiring par hain — matlab `lead.qualified`/`lead.booked` events `funnel_events` me record ho rahe hain lekin `flagged_events` me fall through ho rahe hain jab tak unke Dispatcher branches me real workflow IDs na daale jayein (Section 9.4, `DEPLOYMENT-GUIDE.md`)
