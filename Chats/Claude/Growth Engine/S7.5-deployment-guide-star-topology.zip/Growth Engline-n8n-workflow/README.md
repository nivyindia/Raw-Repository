# Nivy Automated Funnel — n8n Workflows

Ye folder poore funnel ke ab tak ke **importable n8n workflows** rakhta hai — plan document (`n8n-Automated-Funnel-Plan.md`) ka implementation.

## Phase 0 — Hub (Star Topology)

| Module | Folder | Status |
|---|---|---|
| Hub-Intake | `growth-engine-automation/phase-0-hub/hub-intake/` | ✅ Built — sab spokes isko report karte hain |
| Hub-Dispatcher | `growth-engine-automation/phase-0-hub/hub-dispatcher/` | ✅ Built — abhi sirf `lead.qualified`, `lead.booked`, `proposal.ready`, `client.won` route karta hai |

## Phase 1 — Marketing Engine (Traffic → Qualified Lead)

| Module | Folder | Status | Wiring |
|---|---|---|---|
| 1.1 — Content → Social Factory | `growth-engine-automation/phase-1/1.1-content-social-factory/` | ✅ Built | Koi cross-module hand-off nahi |
| 1.2 — SEO Automation (Weekly) | `growth-engine-automation/phase-1/1.2-seo-automation/` | ✅ Built | Koi cross-module hand-off nahi |
| 1.3 — Website Lead Capture | `growth-engine-automation/phase-1/1.3-website-lead-capture/` | ✅ Built | ⭐ Star (Hub) |
| 1.4 — Inbound Form Qualification | `growth-engine-automation/phase-1/1.4-inbound-form-qualification/` | ✅ Built | ⭐ Star (Hub) |
| 1.5 — Central CRM Sync | `growth-engine-automation/phase-1/1.5-central-crm-sync/` | ✅ Built | ⭐ Star (Hub) |

Phase 1 (1.1 → 1.5) **complete** hai, aur poora Hub-based star topology par migrate ho chuka hai.

## Phase 2 — Sales + Delivery Engine (Lead → Paying Client → Delivery)

| Module | Folder | Status | Wiring |
|---|---|---|---|
| 2.1 — Multi-channel Outreach | `growth-engine-automation/phase-2/2.1-multichannel-outreach/` | ✅ Built | ⏳ Mesh (purana) — S4.1 pending |
| 2.2 — Nurture Sequence | `growth-engine-automation/phase-2/2.2-nurture-sequence/` | ✅ Built | Koi cross-module hand-off nahi |
| 2.3 — Booking Sync | `growth-engine-automation/phase-2/2.3-booking-sync/` | ✅ Built | ⭐ Star (Hub) |
| 2.4 — Proposal Generation | `growth-engine-automation/phase-2/2.4-proposal-generation/` | ✅ Built | ⏳ Mesh (purana) — S4.3 pending |
| 2.5 — Contract + E-sign | `growth-engine-automation/phase-2/2.5-contract-esign/` | ✅ Built | ⭐ Star (Hub) |
| 2.6 — Invoice + Payment | `growth-engine-automation/phase-2/2.6-invoice-payment/` | ✅ Built | ⏳ Mesh (purana) — S4.5 pending |
| 2.7 — Client Onboarding | `growth-engine-automation/phase-2/2.7-client-onboarding/` | ✅ Built | ⏳ Mesh (purana) — S4.6 pending |
| 2.8 — Delivery + Reporting | `growth-engine-automation/phase-2/2.8-delivery-reporting/` | ✅ Built | ⏳ Mesh (purana) — S4.7 pending |
| 2.9 — Renewal + Revenue Ops | `growth-engine-automation/phase-2/2.9-renewal-revenue-ops/` | ✅ Built | ⏳ Mesh (purana) — S4.8 pending |

Phase 2 (2.1 → 2.9) ab **complete** hai — poora funnel plan (traffic se lekar renewal tak) ab importable workflows me ban chuka hai. **⏳ Mesh** wale modules abhi bhi kaam karte hain (koi regression nahi), sirf unka wiring style star-topology batches (S4b/S4c) ban ne tak purana hi rahega — `N8N-Star-Topology-Integration-Plan.md` ka progress tracker follow karte raho.

> **S7.5 update — star topology in progress:** Ye system module-to-module direct calls (mesh) se ek Hub-based star topology par migrate ho raha hai — poora reasoning `N8N-Star-Topology-Integration-Plan.md` me hai. **1.3, 1.4, 1.5, 2.3, 2.5 aur Hub-Intake/Hub-Dispatcher khud already migrate ho chuke hain.** Baaki (2.1, 2.4, 2.6, 2.7, 2.8, 2.9) abhi bhi neeche wali purani mesh-style wiring use karte hain, jab tak unka apna batch (S4/S5/S6) nahi ban jaata.

**Migrated modules ke liye (star topology):** ab kisi module ko doosre module ka workflow ID nahi chahiye. Har spoke sirf ek cheez jaanta hai — **Hub-Intake** ka workflow ID (import karne ke baad milta hai, `Report to Hub` node me placeholder `REPLACE_WITH_0.0_HUB_INTAKE_WORKFLOW_ID` ki jagah daal do). Kaun kis event par kis module ko trigger karega, ye ab sirf **Hub-Dispatcher** ke `Switch - Route by Event Type` node me — ek hi jagah — decide hota hai. Poore steps `DEPLOYMENT-GUIDE.md` Section 9 me hain.

**Abhi tak migrate nahi hue modules ke liye (purani mesh wiring, jab tak S4b/S4c/S5/S6 nahi bante):**
- `2.6` ka ID → `2.5-contract-esign/workflow.json` ke `Execute Workflow - 2.6 Invoice + Payment` node me — ⚠️ ye node ab hata diya gaya hai (S4.4 batch), isliye ye step **ab lagu nahi hota** — 2.5 ab Hub ko report karta hai
- `2.7` ka ID → `2.6-invoice-payment/workflow.json` me naya **Execute Workflow** node add karke daalo (abhi wahan placeholder node nahi hai — `2.7-client-onboarding/README.md` ke "Wiring" section me exact steps hain) — **abhi bhi lagu hai**, S4b batch tak

## Common Setup (sabhi modules ke liye zaroori)

Sab modules 2 cheezein share karte hain — pehle inhe ek baar setup kar lo:

### 1. n8n me Postgres credential banao
- **Credentials → New → Postgres**
- Odoo instance ki database ke connection details daalo (Host, Port, Database name, User, Password)
- Name: `Odoo Postgres` (sab workflows me isi naam se reference hai)

### 2. `clients_master` control table banao (ek baar, Postgres par)
```sql
CREATE TABLE clients_master (
  id SERIAL PRIMARY KEY,
  odoo_lead_id INTEGER UNIQUE,
  name TEXT,
  email TEXT,
  phone TEXT,
  company TEXT,
  service_type TEXT,
  intent_summary TEXT,
  urgency TEXT,
  score TEXT,
  score_reason TEXT,
  source TEXT,
  status TEXT DEFAULT 'New',
  created_at TIMESTAMP DEFAULT now(),
  updated_at TIMESTAMP DEFAULT now()
);
```
Ye Master Plan ke Section 5.1 wala central sync table hai — Module 1.3, 1.4, aur 1.5 sab isi ko read/write karte hain.

### 3. Ollama server chalu rakho
```bash
ollama serve
ollama pull qwen2.5:7b
```
Sab workflows `http://localhost:11434` assume karte hain — agar Ollama alag machine/container par hai to har workflow ke HTTP nodes me URL update karna hoga.

### 4. Odoo API access (Modules 1.3, 1.4, 1.5 ke liye)
n8n → Settings → Variables me ye set karo:

| Variable | Kya daalna hai |
|---|---|
| `ODOO_URL` | Odoo instance ka base URL |
| `ODOO_DB` | Odoo database ka naam |
| `ODOO_UID` | API user ka internal user ID |
| `ODOO_API_KEY` | Odoo → Settings → Users → API Key |
| `ODOO_DISCUSS_CHANNEL_ID` | Sales team ke Discuss channel ID |
| `ODOO_LINKEDIN_ACTIVITY_TYPE_ID` | Odoo Activity Type ID (Module 2.1 ke LinkedIn task ke liye) |
| `ODOO_SALES_USER_ID` | Sales rep ka Odoo user ID (Module 2.1 ke LinkedIn task assignee) |
| `WAHA_URL`, `WAHA_API_KEY`, `WAHA_SESSION` | Waha WhatsApp gateway details (Module 2.1, 2.2 ke liye) |
| `PROPOSAL_CUSTOM_THRESHOLD_INR` | Is se upar recommended-tier price ho to custom-branded PDF banega (Module 2.4) |
| `ODOO_FALLBACK_PARTNER_ID` | Generic/placeholder Odoo Contact ID jab tak per-lead `odoo_partner_id` available nahi (Module 2.4, 2.6) |
| `GOTENBERG_URL` | Self-hosted Gotenberg base URL (Module 2.4) |
| `NEXTCLOUD_URL` | Self-hosted Nextcloud base URL (Module 2.4) |
| `PROPOSAL_ACCEPT_BASE_URL` | n8n instance ka public base URL — accept/webhook links banane ke liye (Module 2.4, 2.5) |
| `DOCUMENSO_API_URL`, `DOCUMENSO_API_KEY`, `DOCUMENSO_CONTRACT_TEMPLATE_ID` | Self-hosted Documenso details (Module 2.5) |
| `ODOO_WON_STAGE_ID` | Odoo CRM "Won" stage ki internal ID (Module 2.5) |
| `ODOO_DELIVERY_TEAM_PARTNER_IDS` | Odoo partner IDs ka JSON array — delivery team jo har client Discuss channel me default add hoti hai (Module 2.7) |
| `METABASE_URL`, `METABASE_API_KEY`, `METABASE_CLIENT_CARD_ID`, `METABASE_CLIENT_DASHBOARD_PUBLIC_UUID` | Self-hosted Metabase details — saved question + public dashboard (Module 2.8) |
| `ODOO_RENEWAL_ACTIVITY_TYPE_ID` | Odoo Activity Type ID renewal-call activity ke liye (Module 2.9) |

Naye credentials bhi chahiye: **Nextcloud WebDAV** (HTTP Basic Auth, Module 2.4 aur 2.7 dono me reuse hoti hai).

## Import Order

Poora, up-to-date order (star-topology modules + abhi bhi mesh wale modules dono) `DEPLOYMENT-GUIDE.md` ke Section 9 me hai — wahi single source of truth hai. Short version:

1. `hub-intake/workflow.json`, `hub-dispatcher/workflow.json` — sabse pehle, dono Active karo, Hub-Intake ka ID copy karo
2. `1.1-content-social-factory/workflow.json`, `1.2-seo-automation/workflow.json` — import, README follow karo, test karo
3. `1.3-website-lead-capture/workflow.json` — import, **Hub-Intake ID daalo**, Typebot webhook connect karo, test karo
4. `1.4-inbound-form-qualification/workflow.json` — import, **Hub-Intake ID daalo**, Odoo Automation Rule connect karo, test karo
5. `2.3-booking-sync/workflow.json` — import, **Hub-Intake ID daalo**, Cal.com webhook connect karo, test karo
6. `2.5-contract-esign/workflow.json` — import, **Hub-Intake ID daalo**, Documenso setup karo, test karo
7. `1.5-central-crm-sync/workflow.json` — import, **Hub-Intake ID daalo**, test karo
8. `2.1-multichannel-outreach/workflow.json`, `2.2-nurture-sequence/workflow.json`, `2.4-proposal-generation/workflow.json`, `2.6-invoice-payment/workflow.json`, `2.7-client-onboarding/workflow.json`, `2.8-delivery-reporting/workflow.json`, `2.9-renewal-revenue-ops/workflow.json` — inke apne README abhi mesh-style wiring bataate hain (workflow ID copy karke doosre module me daalna) — wahi follow karo jab tak inka star-topology batch nahi ban jaata
9. Hub-Dispatcher ke `Switch - Route by Event Type` node me migrate ho chuke spokes (2.1, 2.4, 2.5, 2.7) ke workflow IDs daalo — ye ab woh **ek jagah** hai jahan "doosre module ka ID copy karo" wala kaam hota hai

Har module ke apne folder me detailed README hai (credentials, placeholders, test steps, known limitations).

## Master Plan File

Poora funnel plan, tool stack, aur progress tracker `n8n-Automated-Funnel-Plan.md` me hai — us file ke Section 9 me progress tracker update kiya gaya hai (1.1–1.5 aur 2.1–2.9 sab ✅ Done — poora funnel ab built hai).

## Launch-Readiness Blockers (in modules ko live karne se pehle)

Ye woh cheezein hain jo abhi placeholder/assume kiya gaya hai — har module ke README ke "Known Limitations" me detail hai, yahan sirf summary:

- **Pricing** (Module 2.4): Ollama-generated hai, ek fixed rate card se replace karna chahiye — abhi AI-hallucinated numbers client ko ja sakte hain
- **Contact/Partner linking** (Module 2.4, 2.6): `odoo_partner_id` per-lead abhi populate nahi hota, fallback generic contact use ho raha hai — real Odoo Contacts se link karna zaroori hai
- **Security** (Module 2.5 accept-link, Module 2.6 payment webhook): dono par abhi koi signature/token verification nahi hai — production se pehle add karna zaroori hai
- **Gotenberg wiring** (Module 2.4): binary-conversion step import ke baad manually wire karna hoga, warna custom-proposal path fail hoga
- **Odoo portal access** (Module 2.4, 2.6): payment/proposal links tabhi login-less kaam karenge jab Contacts ka portal access properly configured ho
- **2.6 → 2.7 wiring pending**: Module 2.6 me abhi Module 2.7 ko call karne wala Execute Workflow node manually add karna hai (README 2.7 dekho) — tab tak onboarding auto-trigger nahi hoga. (Star-topology S4b batch ban ne ke baad ye direct link hat jayega, dono Hub ke through connect honge.)
- **Star-topology migration abhi partial hai**: 2.1, 2.4, 2.6, 2.7, 2.8, 2.9 abhi bhi purani mesh wiring par hain — inke Hub-Dispatcher Switch branches khaali/placeholder hain jab tak S4b/S4c/S5/S6 nahi bante. Tab tak in modules ka funnel behavior bilkul waisa hi hai jaisa migration se pehle tha (koi regression nahi).
- **`renewal_date` auto-population nahi hai** (Module 2.9): abhi manually set karna padega, warna renewal reminders aur churn detection kaam nahi karenge
- **Failed-payment webhook signature verification missing** (Module 2.9, same class of issue as Module 2.6's payment webhook) — production se pehle add karna zaroori hai
- **Metabase PDF export nahi hai** (Module 2.8): Community edition me API se PDF nahi milta, v1 me public dashboard link bhej rahe hain instead — sensitive data ho to signed/embedded link me upgrade karo launch se pehle
