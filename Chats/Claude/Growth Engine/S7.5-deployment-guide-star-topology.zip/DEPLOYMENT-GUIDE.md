# Growth Engine — Deployment Guide

Ye guide poore stack (Postgres, n8n, Odoo, Ollama, Postal, Nextcloud, Documenso, Mixpost, Metabase, Cal.com, Waha, Typebot) ko ek VPS par live karne ka step-by-step process hai, phir sabhi n8n workflows import + wire karne ka — **star topology** ke hisaab se (Hub-Intake + Hub-Dispatcher ke through, seedhe module-to-module calls ke bajaye — Section 9 dekho).

---

## 0. VPS Provision

**Minimum spec** (sab tools + Ollama 7B model ek saath chalane ke liye):

| Resource | Minimum | Recommended |
|---|---|---|
| RAM | 16 GB | 32 GB |
| vCPU | 4 | 8 |
| Storage | 100 GB SSD | 200 GB SSD |
| OS | Ubuntu 22.04/24.04 LTS | same |

**Provider:** koi bhi (Hetzner, DigitalOcean, Contabo, AWS Lightsail). Hetzner CPX41 (8vCPU/32GB) is a common cost-effective pick for this kind of self-hosted stack.

**DNS — ek baar setup karo, subdomains sabke liye chahiye:**

```
n8n.yourdomain.com       -> VPS IP
odoo.yourdomain.com      -> VPS IP
mail.yourdomain.com      -> VPS IP   (Postal)
files.yourdomain.com     -> VPS IP   (Nextcloud)
sign.yourdomain.com      -> VPS IP   (Documenso)
social.yourdomain.com    -> VPS IP   (Mixpost)
bi.yourdomain.com        -> VPS IP   (Metabase)
cal.yourdomain.com       -> VPS IP   (Cal.com)
wa.yourdomain.com        -> VPS IP   (Waha)
bot.yourdomain.com       -> VPS IP   (Typebot)
```

A-records add karo, phir aage badho (propagate hone me 5-30 min lagega).

---

## 1. Base Setup

```bash
# SSH in, then:
apt update && apt upgrade -y
apt install -y docker.io docker-compose-plugin ufw fail2ban

# Firewall — sirf zaroori ports khulo
ufw allow 22/tcp
ufw allow 80/tcp
ufw allow 443/tcp
ufw allow 25/tcp    # Postal SMTP
ufw allow 587/tcp   # Postal submission
ufw enable

systemctl enable docker
```

**Reverse proxy + auto-SSL (Caddy — sabse simple):**

```bash
apt install -y debian-keyring debian-archive-keyring apt-transport-https
curl -1sLf 'https://dl.cloudsmith.io/public/caddy/stable/gpg.key' | gpg --dearmor -o /usr/share/keyrings/caddy-stable-archive-keyring.gpg
curl -1sLf 'https://dl.cloudsmith.io/public/caddy/stable/debian.deb.txt' | tee /etc/apt/sources.list.d/caddy-stable.list
apt update && apt install -y caddy
```

Caddyfile (`/etc/caddy/Caddyfile`) — har subdomain ke liye ek block, Caddy khud Let's Encrypt SSL handle karega:

```
n8n.yourdomain.com {
    reverse_proxy localhost:5678
}
odoo.yourdomain.com {
    reverse_proxy localhost:8069
}
files.yourdomain.com {
    reverse_proxy localhost:8080
}
sign.yourdomain.com {
    reverse_proxy localhost:3001
}
social.yourdomain.com {
    reverse_proxy localhost:4200
}
bi.yourdomain.com {
    reverse_proxy localhost:3000
}
cal.yourdomain.com {
    reverse_proxy localhost:3002
}
wa.yourdomain.com {
    reverse_proxy localhost:3003
}
bot.yourdomain.com {
    reverse_proxy localhost:8081
}
```

```bash
systemctl restart caddy
```

---

## 2. Core Infra — Postgres + n8n + Ollama

`docker-compose.yml` (mkdir `/opt/growth-engine`, put this there):

```yaml
version: "3.8"
services:
  postgres:
    image: postgres:16
    restart: unless-stopped
    environment:
      POSTGRES_USER: growthengine
      POSTGRES_PASSWORD: CHANGE_ME_STRONG_PASSWORD
      POSTGRES_DB: growthengine
    volumes:
      - pg_data:/var/lib/postgresql/data
    ports:
      - "127.0.0.1:5432:5432"

  n8n:
    image: n8nio/n8n:latest
    restart: unless-stopped
    environment:
      N8N_HOST: n8n.yourdomain.com
      N8N_PROTOCOL: https
      WEBHOOK_URL: https://n8n.yourdomain.com/
      GENERIC_TIMEZONE: Asia/Kolkata
      N8N_ENCRYPTION_KEY: CHANGE_ME_RANDOM_32_CHARS
    volumes:
      - n8n_data:/home/node/.n8n
    ports:
      - "127.0.0.1:5678:5678"

volumes:
  pg_data:
  n8n_data:
```

```bash
cd /opt/growth-engine
docker compose up -d
```

**Ollama (bare-metal, Docker se bahar — GPU/CPU access simpler hai):**

```bash
curl -fsSL https://ollama.com/install.sh | sh
ollama serve &
ollama pull qwen2.5:7b
ollama pull mistral:7b   # backup model
```

Ollama `http://localhost:11434` par listen karega — sab n8n workflows isi ko assume karte hain (agar Ollama alag machine par hai to workflow ke HTTP nodes me URL badalna hoga).

---

## 3. Odoo Community

```bash
mkdir -p /opt/odoo && cd /opt/odoo
```

`docker-compose.yml`:

```yaml
version: "3.8"
services:
  odoo-db:
    image: postgres:15
    restart: unless-stopped
    environment:
      POSTGRES_USER: odoo
      POSTGRES_PASSWORD: CHANGE_ME
      POSTGRES_DB: postgres
    volumes:
      - odoo_db_data:/var/lib/postgresql/data

  odoo:
    image: odoo:17.0
    restart: unless-stopped
    depends_on:
      - odoo-db
    environment:
      HOST: odoo-db
      USER: odoo
      PASSWORD: CHANGE_ME
    volumes:
      - odoo_web_data:/var/lib/odoo
    ports:
      - "127.0.0.1:8069:8069"

volumes:
  odoo_db_data:
  odoo_web_data:
```

```bash
docker compose up -d
```

- `https://odoo.yourdomain.com` khol ke database create karo, admin password set karo
- **Apps activate karo:** CRM, Sales, Invoicing, Project, Website, Discuss, Email Marketing
- **API access:** Settings → Users → apna user → API Keys → naya key generate karo (ye `ODOO_API_KEY` banega)
- User ka internal ID note karo (Settings → Users, URL me `id=` dikhega) — ye `ODOO_UID` hai

---

## 4. Postal (Email Sending)

Postal ka apna installer hai (Docker-based internally), separate se install hota hai:

```bash
git clone https://github.com/postalserver/install /opt/postal-install
cd /opt/postal-install
./postal bootstrap mail.yourdomain.com
# config edit karo: /opt/postal/config/postal.yml (DB creds, domain)
./postal initialize
./postal make-user   # admin account banao
./postal start
```

- DNS me SPF, DKIM, DMARC, MX, rDNS records add karo (Postal install ke output me exact records milenge — `./postal default-dkim-record` se dobara nikaal sakte ho)
- Postal admin UI (`https://mail.yourdomain.com`) me ek Organization + Mail Server banao, SMTP credentials generate karo
- Ye SMTP creds Odoo (Settings → Technical → Outgoing Mail Servers) aur n8n (Credentials → SMTP, naam: `Postal SMTP`) dono me daalo

---

## 5. Nextcloud

```bash
mkdir -p /opt/nextcloud && cd /opt/nextcloud
```

```yaml
version: "3.8"
services:
  nextcloud-db:
    image: postgres:15
    restart: unless-stopped
    environment:
      POSTGRES_USER: nextcloud
      POSTGRES_PASSWORD: CHANGE_ME
      POSTGRES_DB: nextcloud
    volumes:
      - nc_db_data:/var/lib/postgresql/data

  nextcloud:
    image: nextcloud:latest
    restart: unless-stopped
    depends_on:
      - nextcloud-db
    environment:
      POSTGRES_HOST: nextcloud-db
      POSTGRES_DB: nextcloud
      POSTGRES_USER: nextcloud
      POSTGRES_PASSWORD: CHANGE_ME
      NEXTCLOUD_TRUSTED_DOMAINS: files.yourdomain.com
    volumes:
      - nc_data:/var/www/html
    ports:
      - "127.0.0.1:8080:80"

volumes:
  nc_db_data:
  nc_data:
```

```bash
docker compose up -d
```

`https://files.yourdomain.com` khol ke admin account banao. Ek automation/API user bhi bana lo (n8n isi user ke naam se WebDAV calls karega) — ye `NEXTCLOUD_USER` hoga, uska password `Nextcloud WebDAV` credential (HTTP Basic Auth) me n8n me daalo.

---

## 6. Documenso, Mixpost, Metabase, Cal.com, Waha, Typebot

Sab officially Docker-first hain — inke apne GitHub repos ke `docker-compose.yml` use karo (versions/images change hote rehte hain, isliye latest official docs follow karna best hai, exact commands yaha freeze nahi kar raha):

| Tool | Official self-host doc |
|---|---|
| Documenso | github.com/documenso/documenso → `docker` folder |
| Mixpost | github.com/inovector/mixpost → self-hosted install docs |
| Metabase | hub.docker.com/r/metabase/metabase (single container, apni Postgres se connect karo) |
| Cal.com | github.com/calcom/cal.com → self-hosting docs |
| Waha (WhatsApp) | github.com/devlikeapro/waha → docker run |
| Typebot | github.com/baptisteArno/typebot.io → docker-compose (builder + viewer + Postgres) |

Har ek ke liye same pattern:
1. `docker-compose.yml` unke repo se le lo, apni Postgres/domain/ports fill karo
2. Caddy me subdomain block already daal chuke ho (Section 1)
3. `docker compose up -d`
4. Admin account banao, API key/token nikaalo jahan zaroorat ho

**Priority order agar time kam hai:** Cal.com aur Typebot pehle (Phase 1 lead-capture ke liye zaroori), Documenso aur Metabase baad me (Phase 2 ke later modules — 2.5 aur 2.8 — ke liye chahiye), Mixpost aur Waha jab respective modules (1.1, 2.1) test karne ho.

---

## 7. Central Control Table

Postgres (`growthengine` DB) me connect karke (`docker exec -it <postgres-container> psql -U growthengine`):

```sql
CREATE TABLE clients_master (
  id SERIAL PRIMARY KEY,
  odoo_lead_id INTEGER UNIQUE,
  name TEXT,
  email TEXT,
  phone TEXT,
  company TEXT,
  service_type TEXT,
  intent_summary TEXT,
  urgency TEXT,
  score TEXT,
  score_reason TEXT,
  source TEXT,
  status TEXT DEFAULT 'New',
  odoo_partner_id INTEGER,
  odoo_invoice_id INTEGER,
  nextcloud_folder_url TEXT,
  odoo_project_id INTEGER,
  odoo_discuss_channel_id INTEGER,
  last_report_sent_at TIMESTAMP,
  renewal_date DATE,
  renewal_reminder_sent_at TIMESTAMP,
  dunning_attempts INTEGER DEFAULT 0,
  created_at TIMESTAMP DEFAULT now(),
  updated_at TIMESTAMP DEFAULT now()
);
```

(Ye sab columns individual module READMEs me bhi hain — ek saath yaha daal diya taaki ek hi baar chalana pade.)

**Star topology spine:** `funnel_events` aur `flagged_events` tables bhi isi DB me chahiye — inka SQL yaha nahi, `00-MASTER-MIGRATIONS.sql` me hai (S0.1). Ye Hub-Intake/Hub-Dispatcher ke liye zaroori hain — Section 9 se pehle ye migration run kar lena.

---

## 8. n8n — Credentials + Environment Variables

n8n UI (`https://n8n.yourdomain.com`) me:

**Credentials → New:**
- Postgres → name it `Odoo Postgres` (points to `growthengine` DB from Section 7)
- SMTP → name it `Postal SMTP` (Section 4 ke creds)
- HTTP Basic Auth → name it `Nextcloud WebDAV` (Section 5 ke automation-user creds)

**Settings → Variables** — sab env vars ek jagah daal do (poori list module READMEs me bikhri hai, consolidated yaha hai):

```
ODOO_URL=https://odoo.yourdomain.com
ODOO_DB=<odoo db name>
ODOO_UID=<api user internal id>
ODOO_API_KEY=<odoo api key>
ODOO_DISCUSS_CHANNEL_ID=<internal sales/ops channel id>
ODOO_LINKEDIN_ACTIVITY_TYPE_ID=<activity type id>
ODOO_SALES_USER_ID=<sales rep odoo user id>
ODOO_FALLBACK_PARTNER_ID=<generic contact id>
ODOO_WON_STAGE_ID=<crm won stage id>
ODOO_DELIVERY_TEAM_PARTNER_IDS=[12,15,18]
ODOO_RENEWAL_ACTIVITY_TYPE_ID=<activity type id>
NEXTCLOUD_URL=https://files.yourdomain.com
NEXTCLOUD_USER=<automation user>
WAHA_URL=https://wa.yourdomain.com
WAHA_API_KEY=<waha key>
WAHA_SESSION=default
PROPOSAL_CUSTOM_THRESHOLD_INR=<amount>
GOTENBERG_URL=<gotenberg url, if self-hosted separately>
PROPOSAL_ACCEPT_BASE_URL=https://n8n.yourdomain.com
DOCUMENSO_API_URL=https://sign.yourdomain.com/api
DOCUMENSO_API_KEY=<documenso key>
DOCUMENSO_CONTRACT_TEMPLATE_ID=<template id>
METABASE_URL=https://bi.yourdomain.com
METABASE_API_KEY=<metabase key>
METABASE_CLIENT_CARD_ID=<card id>
METABASE_CLIENT_DASHBOARD_PUBLIC_UUID=<public dashboard uuid>
OUTREACH_FROM_EMAIL=hello@yourdomain.com
```

---

## 9. Import + Wire the Workflows (Star Topology)

> **S7.5 update:** Ye poora section rewrite hua hai. Purana version module-to-module chain tha — har chain wale module ka apna workflow ID copy karke doosre module ke andar ek placeholder me manually daalna padta tha (5 alag jagah: 1.5, 2.4, 2.5, 2.6, 2.7). Ab **star topology** hai: har module (spoke) sirf ek cheez ke baare me jaanta hai — **Hub-Intake** ka workflow ID. Kaun kis ko trigger karega, ye faisla ab sirf ek jagah hota hai — **Hub-Dispatcher** ke Switch node me. Poora reasoning `N8N-Star-Topology-Integration-Plan.md` me hai; ye section sirf operational "kaise karo" hai.

### 9.1 Sabse pehle: spine + Hub

1. `funnel_events` (aur `flagged_events`) tables banao — `00-MASTER-MIGRATIONS.sql` me already hain (Section 7 dekho).
2. `phase-0-hub/hub-intake/workflow.json` → import, **Active** karo, iska workflow ID copy karo (n8n workflow URL me dikhega, ya top-right "..." → Copy). **Yahi ek ID hai jo har spoke ko chahiye.**
3. `phase-0-hub/hub-dispatcher/workflow.json` → import, **Active** karo (ye khud poll karega, kisi ko trigger nahi karna).

### 9.2 Har spoke import karte waqt sirf ek placeholder replace karna hai

Spoke ke `workflow.json` me ek `Report to Hub` node hoga jisme `REPLACE_WITH_0.0_HUB_INTAKE_WORKFLOW_ID` likha hoga — usko Step 9.1.2 wale Hub-Intake ID se replace karo. **Bas itna hi.** Spoke ko kisi doosre spoke ka ID nahi chahiye, chahe wo aage kitne bhi modules ko trigger kare.

### 9.3 Migration status — kaun sa module already Hub-wired hai

⚠️ **Ye migration abhi poori nahi hui hai.** Star-topology plan ke S0–S7 phases me se sirf **S0–S3 aur S4.2/S4.4** ban chuke hain. Baaki modules abhi bhi **purani mesh-style wiring** use karte hain (apna workflow ID copy karke doosre module ke andar placeholder me daalna). Import karte waqt neeche wali table dekh ke sahi tareeka follow karo — galat tareeka mix mat karo, warna dono style ek saath tootengi.

| Module | Wiring style | Kya karna hai |
|---|---|---|
| Hub-Intake, Hub-Dispatcher | — (ye khud Hub hain) | 9.1 follow karo |
| 1.1, 1.2 | No cross-module hand-off | Bas import + test, koi ID wiring nahi |
| 1.3, 1.4, 1.5 | ✅ **Star (Hub)** | Sirf Hub-Intake ID daalo (9.2). 1.5 ab kisi bhi Phase 2 module ka ID nahi maangta — Dispatcher ka Switch node hi 2.1/2.4/2.5/2.7 ko route karta hai |
| 2.3 (Booking Sync) | ✅ **Star (Hub)** | Sirf Hub-Intake ID daalo (9.2) |
| 2.5 (Contract E-sign) | ✅ **Star (Hub)** | Sirf Hub-Intake ID daalo (9.2) — ab isko 2.6 ka ID nahi chahiye |
| 2.1, 2.4 | ⏳ **Mesh (purana)** — S4.1/S4.3 pending | README me diye purane steps follow karo (Dispatcher inhe already trigger kar sakta hai unke workflow ID Hub-Dispatcher me daal ke — Section 9.4 dekho) |
| 2.6, 2.7, 2.8, 2.9 | ⏳ **Mesh (purana)** — S4b/S4c pending | README me diye purane steps follow karo — inka apna doc abhi purana hi hai (workflow ID copy karke placeholder me daalna) |

Jab-jab agla star-topology batch (S4b, S4c, S5, S6) ban ke aaye, is table ko aur Section 9.4 ko update karna — abhi ke liye ye guide dono state ko honestly reflect karta hai taaki deployment karte waqt confusion na ho.

### 9.4 Hub-Dispatcher me spoke workflow IDs daalna (jo bhi migrate ho chuka hai)

Hub-Dispatcher ke `Switch - Route by Event Type` ke aage 4 `Execute Workflow` node hain — inme har spoke ka apna workflow ID daalna hai (import karne ke baad milta hai). **Ye ab poore system me ek hi jagah hai jahan "doosre module ka ID copy karke daalo" wala kaam hota hai** — pehle ye kaam 1.5, 2.4, 2.5, 2.6 char alag jagah hota tha:

- `Execute Workflow - 2.1 Outreach` → 2.1 ka workflow ID (`lead.qualified` event)
- `Execute Workflow - 2.4 Proposal Generation` → 2.4 ka workflow ID (`lead.booked` event)
- `Execute Workflow - 2.5 Contract E-sign` → 2.5 ka workflow ID (`proposal.ready` event)
- `Execute Workflow - 2.7 Onboarding` → 2.7 ka workflow ID (`client.won` event)

Jab tak koi ID placeholder rehta hai, us `event_type` ka event `funnel_events` me safely log hoke `flagged_events` me fall through hoga (Odoo Discuss alert bhi jayega) — kuch crash nahi hoga, sirf us hop ka automation manual rehta hai tab tak.

### 9.5 Import order

1. `hub-intake`, `hub-dispatcher` → sabse pehle (9.1)
2. `1.1-content-social-factory`, `1.2-seo-automation` → import, test
3. `1.3-website-lead-capture` → import, Hub-Intake ID daalo, Typebot webhook URL point karo, test
4. `1.4-inbound-form-qualification` → import, Hub-Intake ID daalo, Odoo Automation Rule connect karo, test
5. `2.3-booking-sync` → import, Hub-Intake ID daalo, Cal.com webhook connect karo, test
6. `2.5-contract-esign` → import, Hub-Intake ID daalo, Documenso setup, test
7. `1.5-central-crm-sync` → import, Hub-Intake ID daalo, test
8. `2.1-multichannel-outreach`, `2.2-nurture-sequence`, `2.4-proposal-generation`, `2.6-invoice-payment`, `2.7-client-onboarding`, `2.8-delivery-reporting`, `2.9-renewal-revenue-ops` → **abhi mesh-style hain**, unke apne README ke purane wiring steps follow karo
9. Jo bhi Hub-wired spokes migrate ho chuke hain (Step 6 ki list), unke workflow IDs Hub-Dispatcher me daalo (9.4)

Har module ko import karte hi **Active** toggle on karo, aur uske README ke "Test Kaise Kare" section follow karke ek dry-run zaroor karo before moving to the next one.

---

## 10. Go-Live Checklist

Launch se pehle in blockers ko close karo (poori list `README.md` ke "Launch-Readiness Blockers" section me hai):

- [ ] Pricing (Module 2.4): Ollama-generated numbers ko fixed rate card se replace karo
- [ ] `odoo_partner_id` per-lead properly link karo (Module 2.4, 2.6, 2.7 abhi fallback generic contact use kar rahe hain)
- [ ] Payment webhook (Module 2.6) + Failed-payment webhook (Module 2.9) par signature verification add karo
- [ ] Gotenberg wiring (Module 2.4) manually complete karo
- [ ] Odoo Contacts portal-access properly enable karo (Module 2.4, 2.6 ke payment/proposal links ke liye)
- [ ] Module 2.6 → 2.7 hand-off wire karo (abhi mesh: 2.6 me manually Execute Workflow node add karo; jab S4b batch ban jaye, ye Hub-based ho jayega — Section 9.3 ki table check karte rehna)
- [ ] Hub-Dispatcher ke 4 Switch branches (2.1, 2.4, 2.5, 2.7) me real workflow IDs daalo — jab tak placeholder hai, un modules ka automation manual rehta hai (Section 9.4)
- [ ] `renewal_date` column ko populate karne ka actual process decide + implement karo
- [ ] Metabase public dashboard link ko sensitive-data-safe (signed/embedded) banao agar zaroorat ho

## 11. Backups (mat bhoolna)

```bash
# Daily cron -- Postgres dump (n8n, Odoo, Nextcloud sab databases)
0 3 * * * docker exec growth-engine-postgres-1 pg_dumpall -U growthengine > /backups/growthengine-$(date +\%F).sql
```
Volumes (`n8n_data`, `odoo_web_data`, `nc_data`, Postal's mail storage) bhi periodically off-site backup karo (rsync/restic to S3-compatible storage) — sab client data yahi par hai.
