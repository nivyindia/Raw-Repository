# Press Release Templates — Phase 8
*Used for the PR-partner feature promised in the 8.1 contest prize table ("Feature story + backlink
on Nivy Next's international press/PR partners" — $500 value component). These are the source drafts
to send to PR partners/journalists — they will typically rewrite in their own house style, but this
gives them accurate facts to work from.*

`last_updated: {{last_updated_date}}`

---

## Template 1 — Launch announcement

**FOR IMMEDIATE RELEASE**

### {{legal_entity_name}} Launches {{campaign_name}}, Recognizing {{number_of_winners}} Businesses Across {{eligible_countries_count}} Countries

**{{city}}, {{country}} — {{press_release_date}}** — {{legal_entity_name}} today announced the launch
of {{campaign_name}}, a free-to-enter competition recognizing outstanding small and mid-sized
businesses across {{number_of_categories}} categories, including {{category_example_1}} and
{{category_example_2}}.

The competition is open to businesses with annual revenue under {{revenue_cap}} operating in
{{eligible_countries_list}}. Entries close {{entry_deadline}}, with winners announced
{{winner_announcement_date}}.

"{{founder_quote}}" said {{founder_name}}, {{founder_title}} at {{legal_entity_name}}.

Winners will receive {{prize_summary}}, valued at approximately {{arv_usd}} per winning business.
There is no entry fee and no purchase necessary to participate.

Full eligibility, judging criteria, and Official Rules are available at {{official_rules_url}}.
Entries can be submitted at {{campaign_url}}.

**About {{legal_entity_name}}**
{{company_boilerplate_2_3_sentences}}

**Media contact:**
{{pr_contact_name}}
{{pr_contact_email}}
{{pr_contact_phone}}

---

## Template 2 — Winner announcement

**FOR IMMEDIATE RELEASE**

### {{legal_entity_name}} Announces {{number_of_winners}} Winners of {{campaign_name}}

**{{city}}, {{country}} — {{press_release_date}}** — {{legal_entity_name}} today announced the winners
of {{campaign_name}}, selected from {{total_entries}} entries across {{eligible_countries_count}}
countries.

Winners were chosen by an independent judging panel based on published criteria including impact,
innovation, customer evidence, and growth trajectory, followed by a public community-vote round for
finalists.

Notable winners include: {{winner_highlight_1}}, {{winner_highlight_2}}, {{winner_highlight_3}}.

"{{winner_announcement_quote}}" said {{founder_name}}, {{founder_title}}.

The full winner list is available at {{winner_page_url}}.

**About {{legal_entity_name}}**
{{company_boilerplate_2_3_sentences}}

**Media contact:**
{{pr_contact_name}}
{{pr_contact_email}}
{{pr_contact_phone}}

---
## Notes for distribution
- Send launch PR ~1 week before entries open (embargo) or same-day as launch — coordinate with the social-launch date in `05-Social-Media-Launch-Copy.md`.
- Winner PR goes out same day as the public winner announcement, not before — winners must be notified privately first (see `04-Email-WhatsApp-Communication-Templates.md`, winner email).
- Keep all factual claims (entry counts, ARV, eligibility) consistent with `02-Official-Contest-Rules-nivy-top-100-2026.md` — a journalist repeating a wrong number becomes a real compliance headache.
