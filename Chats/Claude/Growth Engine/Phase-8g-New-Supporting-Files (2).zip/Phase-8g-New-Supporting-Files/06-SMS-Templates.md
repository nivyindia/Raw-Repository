# SMS Templates — Phase 8

*SMS = strictest character/compliance channel (carrier filtering, per-message cost, TCPA in the US,
must include opt-out on first message of a thread). Keep under 160 chars where possible. Always
include brand name since SMS has no logo/context.*

`last_updated: {{last_updated_date}}`

---

## 8.1 Contest

**Entry confirmation:**
> {{legal_entity_name}}: Entry confirmed for {{campaign_name}}, ID {{entry_id}}. Winners announced {{winner_announcement_date}}. Reply STOP to opt out.

**Winner notification:**
> {{legal_entity_name}}: Congrats! You won {{category}} in {{campaign_name}}. Check your email for claim steps. Reply STOP to opt out.

## 8.2 Referral

**Code issued:**
> {{legal_entity_name}}: Your referral link: {{referral_link_short}}. Earn {{meeting_booked_reward}} per booked meeting. Reply STOP to opt out.

**Reward earned:**
> {{legal_entity_name}}: Your referral reward of {{reward_amount}} is confirmed. Details by email. Reply STOP to opt out.

## 8.3 Free-Audit

**Report ready:**
> {{legal_entity_name}}: Your {{audit_type}} report is ready — scored {{score}}/100. View: {{report_link_short}}. Reply STOP to opt out.

## 8.6 Signal-Outreach

**Initial outreach (only where SMS opt-in/legal basis confirmed):**
> {{legal_entity_name}}: Hi {{first_name}}, saw {{trigger_context_short}} — worth a quick chat? {{booking_link_short}} Reply STOP to opt out.

**Opt-out confirmation (auto-reply to STOP):**
> {{legal_entity_name}}: You've been unsubscribed and won't receive further texts. Contact {{support_email}} for questions.

---
## Compliance notes
- Every first SMS in a thread must include a way to opt out ("Reply STOP") — required under TCPA (US), CASL (Canada), and equivalent regimes.
- SMS to Canada/UK/EU numbers needs the same express-consent basis as email under CASL/PECR — do not send 8.6 outreach SMS to those regions without confirmed opt-in (see `01-Outbound-Compliance-Notes.md`).
- Keep sender ID/brand name in every message — unbranded SMS has higher spam-report rates and hurts future deliverability.
