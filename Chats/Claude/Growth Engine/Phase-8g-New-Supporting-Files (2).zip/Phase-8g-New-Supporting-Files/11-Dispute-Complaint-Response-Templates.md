# Dispute & Complaint Response Templates — Phase 8
*Internal-use response templates for sensitive/escalated messages (per the escalation triggers in
`08-Support-Canned-Responses.md`). These are calmer, more careful than routine canned responses —
review before sending, don't auto-send.*

`last_updated: {{last_updated_date}}`

---

## 1. "I should have won / the results are unfair"

> Hi {{first_name}},
>
> Thank you for reaching out, and I understand the disappointment — {{campaign_name}} was genuinely
> competitive this round, with {{total_entries}} entries.
>
> Winners are selected through a structured process: independent judge scoring against published
> criteria ({{judging_criteria_summary}}), followed by a public community-vote round for finalists,
> with final sign-off by our team. We apply this process consistently to every entry.
>
> We don't share individual scores or comparative feedback between entrants, as this protects the
> fairness of the process for everyone. I'd genuinely encourage you to enter the next round — your
> business clearly has {{genuine_positive_observation}}.
>
> If you have a specific factual concern (e.g., you believe your entry was not scored at all, or was
> disqualified in error), let me know the details and I'll have that checked.

## 2. Fraud accusation against another entrant

> Hi {{first_name}},
>
> Thank you for flagging this — we take entry integrity seriously and every entry goes through an
> automated fraud check plus manual review before any winner is confirmed.
>
> I've logged your report for our review team to look into. I'm not able to share the outcome of an
> individual investigation, but I can confirm any confirmed violation of the Official Rules
> ({{official_rules_url}}) results in disqualification.
>
> [Internal: route to reviewer per `09-Internal-Judging-Approval-SOP.md` Section 2.2 — do not confirm
> or deny specifics about another entrant to the person reporting.]

## 3. Fraud accusation against us / "this is a scam"

> Hi {{first_name}},
>
> I understand the concern — happy to address it directly. {{legal_entity_name}} is a registered
> business ({{registration_number}}, {{registered_address}}), and this program is free to enter with
> no purchase necessary at any stage. Full Official Rules: {{official_rules_url}}. Full company
> details: {{impressum_url}}.
>
> Is there something specific that raised the concern? I'd rather address the actual issue directly
> than just reassure you generically.

## 4. Referral/contest payout disagreement (amount or timing)

> Hi {{first_name}},
>
> Let me walk through exactly how this was calculated so we're on the same page:
> [Internal: pull the actual record from `referral_ledger` or `contest_entries`, recalculate per
> `09-Internal-Judging-Approval-SOP.md` Section 3.2, and state the calculation transparently — don't
> just restate the number.]
>
> {{payout_calculation_explanation}}
>
> If you believe there's a genuine error in this calculation (not just a disagreement with the terms
> themselves), please share what you're seeing on your end and I'll have it re-checked by a second
> person.

## 5. Legal threat / regulator mention

> Hi {{first_name}},
>
> Thank you for letting us know — I want to make sure this gets the right attention. I'm escalating
> this to {{legal_escalation_contact}} directly, and someone will follow up with you within
> {{legal_response_sla_days}} business days.
>
> [Internal: do NOT continue negotiating, admitting fault, or making commitments in this thread —
> hand off immediately per the escalation trigger list. Do not send further canned responses on this
> thread without legal sign-off.]

## 6. Data deletion / "remove all my data" beyond simple unsubscribe

> Hi {{first_name}},
>
> For a full data request (access, deletion, correction, or export), please use our data-rights form:
> {{dsar_page_url}} — this ensures it's tracked and handled within the required legal timeframe
> ({{data_response_sla_days}} days). If you'd just like to stop receiving messages, I can also do that
> immediately — let me know which you'd prefer.

---

## General escalation principles (apply to all of the above)
1. **Acknowledge, don't argue.** Even a wrong accusation deserves a calm, factual answer — not a defensive one.
2. **Never promise an outcome you can't guarantee** (e.g., "I'll make sure you win next time," "you'll definitely get paid by Friday").
3. **Never share another entrant's/referrer's personal data or score** in response to a complaint about them.
4. **Escalate before you improvise** on anything involving legal language, large payout amounts, or repeated fraud accusations — see `09-Internal-Judging-Approval-SOP.md` Section 5 for record-keeping requirements on every escalated case.
