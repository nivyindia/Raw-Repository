# Frequently Asked Questions — {{campaign_name}}
*Conversational companion to the Official Rules (`02-Official-Contest-Rules-nivy-top-100-2026.md`) — link
this from the contest entry page and winner page. Where FAQ and Official Rules conflict, Official Rules govern.*

`last_updated: {{last_updated_date}}`

**Is there a fee to enter?**
No. Entry is completely free — no purchase or payment is required at any stage.

**Who can enter?**
Businesses legally operating in {{eligible_countries_list}}, with annual revenue under {{revenue_cap}}. See full eligibility in the Official Rules.

**Can I enter more than once?**
One entry per business per category. Multiple category entries for the same business are allowed if genuinely applicable to each.

**Can I nominate someone else's business?**
Yes — self-nomination and third-party nomination are both accepted.

**How are winners chosen?**
A judging panel scores entries against published criteria ({{judging_criteria_summary}}), with a public community-vote round for finalists. All final selections go through internal review before being announced — see the Official Rules for the full weighting.

**When will I know if I won?**
Winners are announced on {{winner_announcement_date}} at {{winner_announcement_url}}. All entrants — winners and non-winners — receive an email either way.

**What do winners actually get?**
{{prize_summary}} (approximate total value {{arv_usd}} per winner). Full prize breakdown is in the Official Rules. Prizes are services, not cash.

**Do I have to pay tax on the prize?**
Prizes may be considered taxable income depending on your jurisdiction. We'll provide any required tax documentation, but you're responsible for your own tax filings — we recommend checking with a local tax advisor.

**Is this a lottery / game of chance?**
No. This is a merit-judged competition — winners are selected based on published judging criteria, not a random draw.

**How is my data used?**
See `03-Privacy-Notice-Contest-Data.md` for full details on what we collect and why.

**Can I withdraw my entry?**
Yes — email {{support_email}} with your Entry ID and we'll remove it before judging begins.

**I think there's an error / I have a dispute about my entry or the results.**
Contact {{support_email}} within {{dispute_window_days}} days of the relevant event. See our dispute-handling process in `11-Dispute-Complaint-Response-Templates.md` (internal) for how this is handled.

**Where can I ask something not covered here?**
{{support_email}} or WhatsApp {{support_whatsapp}}.
