# Internal SOP — Judging & Human-Approval Gates
*Internal-only document for whoever staffs the "human-approval" nodes in 8.1 (winner selection) and
8.2 (referral payout approval) — these currently exist in the workflow as an Odoo Discuss review step
with no written criteria attached. Do not publish externally.*

`last_updated: {{last_updated_date}}`

---

## 1. Why this exists
The n8n workflows deliberately do **not** auto-approve winners or payouts — every contest winner and
every referral payout routes to a human via an Odoo Discuss notification. That gate is only as good as
the judgment applied by whoever reviews it. This SOP makes that judgment consistent across reviewers
and over time.

## 2. 8.1 Contest — Entry review & winner selection

### 2.1 Automatic fraud screen (already in workflow, informational)
Every entry gets a `fraud_score` (0–100, per-campaign threshold, default 50) based on: disposable-email
detection, duplicate-entry detection, proof-URL heuristic. Entries above threshold are auto-flagged —
**flagged does not mean disqualified**, it means a human looks at it first.

### 2.2 Reviewer checklist before approving a flagged entry
- [ ] Is the business real and verifiable (website/social presence matches entry)?
- [ ] Does the entry meet eligibility (country, revenue cap, one entry per business/category)?
- [ ] Is the fraud flag explainable (e.g., legitimate use of a business email that looks generic) or a genuine red flag (e.g., 10 entries from the same IP/device fingerprint)?
- [ ] If still unsure after these checks, escalate to {{escalation_contact}} rather than guess.

### 2.3 Winner scoring rubric (apply consistently — don't freelance criteria)
Use the published weights from the Official Rules — do not deviate per-judge:

| Criterion | Weight | What "good" looks like |
|---|---|---|
| Impact & results demonstrated | 30 | Specific, verifiable numbers/outcomes, not vague claims |
| Innovation / differentiation | 25 | Clearly different from category peers, not generic |
| Customer/community testimonials & evidence | 20 | Real, checkable evidence (links, screenshots) |
| Growth trajectory | 15 | Directional evidence of growth, not just current-state |
| Overall pitch quality | 10 | Clear, well-written, on-topic |

- Each judge scores independently first, then compares — don't anchor on another judge's score before scoring your own.
- Top 3 per category advance to the public community-vote round (25% blended weight) per the Official Rules — do not skip this step even if a clear frontrunner emerges from judge scores alone.
- **Final selections still require the human-approval gate in the workflow before the "winner" status is written and any notification goes out** — scoring is input to that decision, not a replacement for it.

### 2.4 What to do if you're unsure
Never approve/reject alone if: eligibility is ambiguous, fraud signals are strong but not conclusive, or an entry raises any legal/reputational concern. Escalate to {{escalation_contact}} — a wrong winner selection is far more costly to fix publicly than a short delay.

---

## 3. 8.2 Referral — Payout approval

### 3.1 Before approving a "meeting booked" reward
- [ ] Confirm the referral code was actually used at signup (not manually attributed after the fact)
- [ ] Confirm the meeting was genuinely booked (not a cancelled/no-show meeting counted by mistake)

### 3.2 Before approving a "converted" reward (higher value — extra care)
- [ ] Confirm the referred business is now an actual paying client (contract/invoice exists)
- [ ] Confirm reward calculation: {{converted_reward_pct}} of first invoice, capped at {{converted_reward_cap}} — recalculate, don't trust the pre-filled number blindly
- [ ] Check for self-referral (referrer and referred business being the same person/entity) — not eligible per Referral Program Terms

### 3.3 Payout release
Once approved, payout method and timeline: {{payout_method}}, within {{payout_processing_days}} business days — matches the commitment already made in the referral reward-earned email template (`04-Email-WhatsApp-Communication-Templates.md`).

---

## 4. Review turnaround targets
| Gate | Target turnaround |
|---|---|
| Fraud-flagged contest entry | {{fraud_review_sla_days}} business days |
| Contest final winner sign-off (after scoring complete) | {{winner_signoff_sla_days}} business days |
| Referral payout approval | {{payout_approval_sla_days}} business days |

## 5. Record-keeping
Log every approval/rejection decision with reviewer name, timestamp, and one-line reason — this is your evidence trail if a decision is ever disputed (see `11-Dispute-Complaint-Response-Templates.md`) or reviewed by legal/regulator.
