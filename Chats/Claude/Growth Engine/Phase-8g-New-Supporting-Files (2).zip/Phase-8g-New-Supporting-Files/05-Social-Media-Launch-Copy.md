# Social Media Launch Copy — Phase 8 (All Engines)

*Positioning: confident, hype-free, service-value framing (never "cash"), single CTA per post,
"No purchase necessary" reminder on contest posts. Swap {{...}} before publishing.*

`last_updated: {{last_updated_date}}`

---

## 8.1 Contest — Launch announcement

**LinkedIn / Facebook (long-form):**
> We're launching **{{campaign_name}}** — recognizing {{number_of_winners}} businesses across {{number_of_categories}} categories for {{what_it_celebrates}}.
>
> No entry fee. Open to businesses in 🇺🇸 🇬🇧 🇨🇦 🇦🇺 🇦🇪 🇮🇳.
> Winners get {{prize_summary}} (approx. value {{arv_usd}} per winner).
>
> Entries close {{entry_deadline}}. Enter here → {{campaign_url}}
> *No purchase necessary. Official Rules: {{official_rules_url}}*

**Instagram caption:**
> {{number_of_winners}} spots. {{number_of_categories}} categories. Zero entry fee. 🏆
> {{campaign_name}} is open now → link in bio
> Deadline: {{entry_deadline}}
> #{{hashtag_1}} #{{hashtag_2}}

**X / Twitter:**
> {{campaign_name}} is live. {{number_of_winners}} winners, {{arv_usd}} in prizes each, no entry fee. Closes {{entry_deadline}}. Enter → {{campaign_url}}

**Telegram channel post:**
> 📢 {{campaign_name}} entries are open!
> ✅ Free to enter ✅ {{number_of_categories}} categories ✅ Closes {{entry_deadline}}
> Enter: {{campaign_url}}

## 8.1 Contest — Mid-campaign reminder (T-7 days)
**All channels (short):**
> ⏳ 1 week left to enter {{campaign_name}}. {{entries_so_far}}+ businesses already in. Don't miss it → {{campaign_url}}

## 8.1 Contest — Winner announcement (public)
**LinkedIn:**
> Congratulations to our {{campaign_name}} winners! 🏆
> {{number_of_winners}} businesses across {{number_of_categories}} categories, chosen from {{total_entries}} entries.
> See the full winner list → {{winner_page_url}}
> Watch for the next round — follow us for updates.

**Instagram:**
> Meet the winners of {{campaign_name}} 🎉 Full list in bio.
> #{{hashtag_1}} #{{winner_hashtag}}

---

## 8.2 Referral — Launch

**LinkedIn:**
> Know a business that could use {{value_prop}}? Refer them and earn {{meeting_booked_reward}} when they book a meeting, plus {{converted_reward_pct}} of their first invoice if they become a client.
> Get your link → {{referral_campaign_url}}

**Instagram / Facebook:**
> Refer a friend, earn rewards. Simple. 💸
> {{meeting_booked_reward}} per booked meeting + {{converted_reward_pct}} on conversion.
> Get started → link in bio

## 8.2 Referral — Pre-filled share snippet (what the referrer posts/sends)
*This is the text a referrer copies to share their own link — pre-fill it in the referral landing page's "Share" button.*

**WhatsApp status / DM:**
> I've been working with {{legal_entity_name}} and thought of you — here's my referral link, you'll also get {{referred_friend_perk}} if you check them out: {{referral_link}}

**LinkedIn post (referrer's own):**
> Been really happy working with {{legal_entity_name}} on {{value_prop}}. If you're looking for something similar, here's my referral link: {{referral_link}}

---

## 8.3 Free-Audit — Launch

**All channels:**
> Free {{audit_type}}, no strings attached. Get your score in {{turnaround_time}} → {{audit_campaign_url}}

**LinkedIn (slightly longer):**
> Curious how your {{audit_subject}} actually performs? We built a free {{audit_type}} tool — plug in your URL, get a scored report with top fixes. No cost, no obligation.
> Try it → {{audit_campaign_url}}

---

## 8.4 UGC / Showcase — Launch

**Instagram:**
> Show us your {{ugc_topic}} and earn points, badges, and a shot at the leaderboard 🏅
> Submit → link in bio | Full terms: {{ugc_terms_url}}

**LinkedIn:**
> We're spotlighting the best {{ugc_topic}} from our community. Submit yours for a chance to be featured (plus points toward future rewards).
> Submit here → {{showcase_url}}

---

## 8.5 Community / Founders Circle — Launch

**LinkedIn:**
> Introducing **{{community_name}}** — an invite-only space for {{target_audience}} to {{community_value_prop}}.
> Request access → {{founders_circle_url}}

**Instagram:**
> Building something for {{target_audience}}: {{community_name}}. Invite-only, request access via link in bio.

---

## General usage notes
1. Post cadence suggestion: launch post day 1, reminder at 50%-time-elapsed, final reminder at T-3 days, winner/results post after selection.
2. Every contest-related post that mentions a prize must carry (in-post or first-comment) the "No purchase necessary" line and a link to Official Rules — required by US sweepstakes-adjacent promo law even for merit-judged contests, as good practice.
3. Hashtags: keep to 2–3 max per post, consistent across the campaign (`{{hashtag_1}}`, `{{hashtag_2}}`) so cross-platform discovery works.
4. Do not post cash-value framing ("win $X") anywhere — always service-value framing ("{{arv_usd}} in services"), consistent with the prize structure decision in the Official Rules.
