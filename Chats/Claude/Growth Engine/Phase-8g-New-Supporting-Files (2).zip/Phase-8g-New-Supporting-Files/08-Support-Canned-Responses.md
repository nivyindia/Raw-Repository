# Support Canned Responses — Phase 8
*For the support/ops team handling WhatsApp, email, and social DMs during any active campaign.
Copy-paste and fill {{...}} — don't send with placeholders visible.*

`last_updated: {{last_updated_date}}`

---

## General / cross-engine

**"Did you get my entry/submission/audit request?"**
> Hi {{first_name}}, yes — we have it on file, ID `{{reference_id}}`, received {{submitted_at}}. You'll hear from us by {{expected_response_date}}. Nothing more needed from your side right now.

**"I didn't get a confirmation."**
> Sorry about that, {{first_name}} — let me check. [Look up by email/phone in `{{table_name}}`.] Found it — confirmation resent to {{email}} just now. If it's still not there, check spam/promotions folder.

**"How do I contact a human?"**
> You're talking to one now 🙂 — I'm {{agent_name}} from {{legal_entity_name}}. What can I help with?

**"Is this legit / not a scam?"**
> Totally understand the question. We're {{legal_entity_name}} — you can verify us at {{official_website_url}}, and full program terms are here: {{terms_url}}. Happy to answer anything specific.

---

## 8.1 Contest

**"When do I find out if I won?"**
> Winners are announced {{winner_announcement_date}} at {{winner_page_url}}. You'll get an email either way — no need to keep checking.

**"I won — when do I get my prize?"**
> Congratulations again! Check your email for the claim steps — you'll need to confirm details by {{claim_deadline}}. Once confirmed, {{badge_delivery_days}} business days for your badge/certificate, and our team will reach out to schedule the {{prize_component}} onboarding.

**"Why didn't I win?"**
> I hear you, {{first_name}} — competition this round was strong, {{total_entries}} entries across {{number_of_categories}} categories. Judging was based on published criteria (impact, innovation, testimonials, growth, pitch quality). We don't share individual scores, but we'd love to have you enter the next round.

**"Can I see my score / judge feedback?"**
> We don't share individual judge scores or written feedback — this keeps the judging process fair and consistent across all entrants. What I can tell you is the four scoring categories used: {{judging_criteria_summary}}.

---

## 8.2 Referral

**"My friend signed up — where's my reward?"**
> Let me check the status. [Look up `referral_ledger` by referral_code.] Looks like {{referred_business_name}} is at the "{{current_stage}}" stage — reward for this stage: {{reward_amount}}. You'll get the meeting-booked reward once they book, and the conversion reward once they become a client.

**"How do I get my referral link?"**
> Sure! Fill this in and we'll send your link: {{referral_request_url}}. Or if you already have a code, confirm it here: {{referral_confirm_url}}.

---

## 8.3 Free-Audit

**"My report didn't arrive."**
> Sorry about that — let me resend it. [Look up `audit_requests` by URL/email.] Just resent to {{email}}, should land within a few minutes. Check spam if not.

**"My score seems wrong / low."**
> The score is generated automatically based on {{audit_criteria_summary}} — it's a quick automated estimate, not a full manual audit. Happy to have a real person walk through it with you: {{cta_book_call}}.

---

## 8.4 UGC

**"My submission wasn't approved — why?"**
> Thanks for submitting! Submissions are reviewed against {{ugc_review_criteria}} — common reasons for non-approval: {{common_rejection_reasons}}. You're welcome to resubmit with adjustments.

---

## 8.6 Signal-Outreach

**"How did you get my info / why am I getting this?"**
> Good question — we reached out based on {{trigger_context}}, which is public information (e.g. a hiring post, company update). If you'd rather not hear from us, just reply STOP or click here: {{unsubscribe_url}} — you'll be removed immediately.

**"Remove me / unsubscribe."**
> Done — you've been removed from our outreach list as of now. Sorry for the interruption, and thanks for letting us know.

---

## Escalation triggers (don't self-answer, route to Section 11 dispute templates + a human lead)
- Any message alleging fraud, discrimination, or unfair judging
- Any legal threat or mention of a lawyer/regulator
- Any data-deletion or GDPR/CCPA rights request beyond a simple unsubscribe (route to `03-DSAR-Request-Page.html` flow)
- Any request involving a large payout dispute (referral/contest prize value disagreement)
