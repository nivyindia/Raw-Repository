# Winner Certificate & Digital Badge — Copy Content
*Text content for the "digital badge + certificate for winner's website" prize component
(${{badge_certificate_value}} line item in the Official Rules prize table). This is copy only —
actual graphic design of the certificate/badge is a separate design task, not covered here.*

`last_updated: {{last_updated_date}}`

---

## Certificate (PDF, for download/print)

**Header:** {{legal_entity_name}} presents

**Main line (large text):**
> Certificate of Recognition

**Body:**
> This certifies that
>
> **{{winner_business_name}}**
>
> has been recognized as a **{{category}}** winner of **{{campaign_name}}**
>
> {{winner_announcement_date}}

**Footer:**
> {{legal_entity_name}} · {{campaign_url}}
> Verify this certificate: {{certificate_verification_url}}

**Signature line (optional):**
> {{founder_name}}, {{founder_title}}

---

## Digital badge (small graphic, for embedding on winner's own website)

**Badge primary text (short — fits on a compact badge):**
> {{campaign_short_name}} Winner {{award_year}}

**Badge secondary text (smaller, if space allows):**
> {{category}}

**Alt text (for accessibility — required, see `02-Accessibility-Statement.md`):**
> "{{winner_business_name}} — {{category}} winner of {{campaign_name}} {{award_year}}, awarded by {{legal_entity_name}}"

**Embed snippet (HTML — goes to winner by email alongside the certificate):**
```html
<a href="{{certificate_verification_url}}" target="_blank" rel="noopener">
  <img src="{{badge_image_url}}"
       alt="{{winner_business_name}} — {{category}} winner of {{campaign_name}} {{award_year}}, awarded by {{legal_entity_name}}"
       width="160" height="160">
</a>
```

---

## Winner spotlight — website/social bio snippet (given to winners as suggested copy)
*Winners often want ready-made copy to post about their own win — this reduces friction and increases the odds they'll share it (free amplification for the campaign).*

> Proud to be recognized as a {{category}} winner of {{campaign_name}} by {{legal_entity_name}} — see the full list of {{campaign_short_name}} {{award_year}} winners at {{winner_page_url}}.

---
## Delivery notes
- Certificate + badge delivery timeline matches the winner email commitment in `04-Email-WhatsApp-Communication-Templates.md`: within {{badge_delivery_days}} business days of claim confirmation.
- `{{certificate_verification_url}}` should resolve to a real page (winner page filtered to that entry, or a dedicated verify-by-ID lookup) so the certificate is checkable, not just a static claim — supports authenticity and reduces "is this real" support tickets (see `08-Support-Canned-Responses.md`).
