# Database Setup Guide — Growth Engine

Ye guide batata hai **kahan** aur **kaise** `00-MASTER-MIGRATIONS.sql` chalana hai. Poori funnel automate karne se pehle ye zaroori hai — bina in tables ke Hub-Intake khud hi kaam nahi karega.

## ⚠️ Sabse pehle: kaunsi database?

`DEPLOYMENT-GUIDE.md` ke Section 1 aur 7 me likha hai ki `clients_master` aur baaki growth-engine tables ek **alag, khaali** Postgres container (`growthengine` DB) me banane hain, aur Odoo apni khud ki alag Postgres container me chalta hai.

**Ye kaam nahi karega.** Module 1.5 (Central CRM Sync) ek hi Postgres node me `crm_lead` / `crm_stage` (Odoo ke apne tables) **aur** `clients_master` dono query karta hai — same credential (`Odoo Postgres`) se. Postgres do alag databases ke beech seedha JOIN nahi kar sakta (dblink/FDW ke bina, jo iss build me kahi setup nahi hai). Matlab **`crm_lead` aur `clients_master` dono ek hi physical database me hone chahiye.**

### Do options:

**Option A (recommended, simplest):** Growth-engine ke saare tables **Odoo ke apne Postgres database** ke andar banao — wahi database jisme `crm_lead` already hai. Alag `growthengine` container ki zaroorat hi nahi. n8n ka "Odoo Postgres" credential seedha Odoo ke Postgres se connect karo (jo waise bhi uska naam suggest karta hai).

**Option B (agar databases alag hi rakhne hain):** `postgres_fdw` extension use karke `growthengine` DB se Odoo ke DB ka `crm_lead`/`crm_stage` table ek foreign table ke roop me mount karo. Zyada complex, extra maintenance — sirf tab karo agar koi specific wajah ho (jaise Odoo DB par access restrict karna).

Ye guide **Option A** maan ke likha gaya hai. Agar Option B chahiye to bolna, alag setup steps de dunga.

## Step 1 — Confirm karo kaunsi DB hai

```bash
docker exec -it <odoo-postgres-container> psql -U odoo -l
```

Odoo ka actual database name dekho (default setup me usually `odoo` ya jo bhi Odoo installer ke waqt diya tha — `postgres` sirf bootstrap DB hota hai, Odoo apna kaam-ka DB alag banata hai).

## Step 2 — Migration file copy + run karo

```bash
docker cp 00-MASTER-MIGRATIONS.sql <odoo-postgres-container>:/tmp/
docker exec -it <odoo-postgres-container> psql -U odoo -d <odoo_actual_db_name> -f /tmp/00-MASTER-MIGRATIONS.sql
```

File **safe hai re-run karne ke liye** — har statement `IF NOT EXISTS` use karta hai, dobara chalane se kuch nahi tootega.

## Step 3 — n8n credential check karo

n8n me "Odoo Postgres" credential kholo, confirm karo `database` field me wahi `<odoo_actual_db_name>` hai jisme Step 2 chalaya (na ki `growthengine`, na ki bootstrap `postgres`).

## Step 4 — Verify karo sab tables ban gaye

```sql
SELECT table_name FROM information_schema.tables
WHERE table_schema = 'public'
  AND table_name IN (
    'funnel_events','flagged_events','clients_master','automation_errors',
    'webhook_events','nps_responses','nps_survey_tokens','case_studies',
    'referrals','unmatched_stage_events','communication_events',
    'linkedin_processed_messages','n8n_processed_posts','qualification_records',
    'workflow_errors'
  )
ORDER BY table_name;
```

15 rows aane chahiye. Agar koi kam hai, migration dobara run karo — idempotent hai, koi nuksaan nahi.

## Kya "database create" nahi karna padega

`crm_lead` jaisa Odoo ka koi table iss file me nahi hai, aur na hona chahiye — wo Odoo khud apne installation ke waqt banata hai. Ye file sirf **growth-engine ke naye tables** banati hai (`clients_master`, `funnel_events`, wagera) usi database ke andar jahan Odoo ke tables already hain — koi naya `CREATE DATABASE` statement nahi chahiye, tables `IF NOT EXISTS` se ban jayenge.

## Naye vs. purane tables — kya change hua

Pehle wali `00-MASTER-MIGRATIONS.sql` (jo reconciled zip me thi) me ye poori tarah missing tha:

| Missing | Kisko chahiye tha |
|---|---|
| `funnel_events` | Hub-Intake, Hub-Dispatcher — **poora star topology isi par khada hai** |
| `flagged_events` | Hub-Dispatcher (jab koi event ka Switch branch wired nahi hota) |
| `workflow_errors` | 4.3.3, 5.1.1, 5.1.2, 6.1.1, 6.2.1, 6.3.1, 6.4.1 |
| `qualification_records` | 5.1.1, 5.1.2 |
| `communication_events` | 4.3.1, 4.3.2, 4.3.3, 6.1.1 (inline fallback tha 2 modules me, ab yaha bhi consolidated) |
| `linkedin_processed_messages` | 4.3.2 (inline fallback bhi tha, ab yaha bhi) |
| `n8n_processed_posts` | 1.1 |
| `clients_master.last_reply_channel`, `.last_reply_at`, `.linkedin_profile_url`, `.adoption_checklist_created_at` | 4.3.x, 6.1.1, 6.2.1 |

Poori tarah 36 `workflow.json` files ke andar har Postgres node aur code node grep karke ye list banayi hai — nothing assumed, sab file-verified.

## Agla step

Migration run karne ke baad `N8N-Import-Order-Guide.md` follow karo — ab jitne bhi workflows import karoge, "column does not exist" ya "relation does not exist" error nahi aayega.
