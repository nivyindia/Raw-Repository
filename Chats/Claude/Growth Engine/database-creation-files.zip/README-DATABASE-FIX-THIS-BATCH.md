# Database Creation Files — Gap Found + Fixed

## Kya poocha gaya tha

Reconciled star-topology tree (`RECONCILED-star-topology-v6.zip`) me jitni
bhi databases/tables chahiye, unme se koi bhi actually create nahi ho rahi
thi — poori funnel automate karni thi lekin table-creation files adhoori
thi.

## Kya mila (disk-checked, file-by-file)

Saare 36 `workflow.json` files (reconciled tree ke andar) ke har Postgres
node aur code node ko grep kiya, har `CREATE TABLE`/`INSERT INTO`/
`UPDATE`/`SELECT ... FROM` ke table names nikaale, aur unhe already-shipped
`master-migrations/00-MASTER-MIGRATIONS.sql` se compare kiya.

**Sabse bada gap:** `funnel_events` aur `flagged_events` — Hub-Intake aur
Hub-Dispatcher ki apni **spine tables**, jo poore star-topology system ka
foundation hain — kahin bhi kisi migration file me define hi nahi thi.
Bina inke Hub-Intake khud hi kaam nahi karega, chahe upar ke saare 36
modules perfectly wired ho.

**6 aur missing tables:** `workflow_errors`, `qualification_records`,
`communication_events`, `linkedin_processed_messages`,
`n8n_processed_posts` — 10+ modules inhe use karte hain, kabhi kisi ek
jagah define nahi hue (kuch modules ke andar inline "run once" fallback
node tha, but master file me nahi tha).

**4 missing columns** `clients_master` par: `last_reply_channel`,
`last_reply_at`, `linkedin_profile_url`, `adoption_checklist_created_at`.

**Ek architecture-level gap** jo separate se flag kar raha hoon: existing
`DEPLOYMENT-GUIDE.md` (Section 1/7) ke hisaab se growth-engine tables ek
alag, khaali `growthengine` Postgres container me banane the. Lekin Module
1.5 ek hi Postgres connection me `crm_lead` (Odoo ka table) aur
`clients_master` (growth-engine ka table) dono query karta hai — ye tabhi
kaam karega jab dono same physical database me hon. `DATABASE-SETUP-GUIDE.md`
me poora explain kiya hai aur recommended fix diya hai (Odoo ke apne DB me
hi sab kuch banao, alag container ki zaroorat nahi).

## Files in this delivery

- `master-migrations/00-MASTER-MIGRATIONS.sql` — updated: naya **Section 0**
  (funnel_events, flagged_events — sabse pehle rakha, kyunki sab kuch isi
  par depend karta hai), naya **Section 6** (baaki 5 missing tables), aur
  4 missing columns Section 1 me add kiye. Baaki poora file same hai
  (idempotent, safe to re-run).
- `master-migrations/00-COMBINED-DB-SCHEMA-ADDENDUM.sql` — unchanged, isi
  reference ke liye carry kiya (already superseded by the master file, per
  its own header note).
- `DATABASE-SETUP-GUIDE.md` — kahan run karna hai (single-DB explanation
  + fix), exact commands, verification query, aur missing-tables ka pura
  table.

## Verification

`00-MASTER-MIGRATIONS.sql` ab 12 `CREATE TABLE` aur 23 `ALTER TABLE`
statements rakhta hai (pehle 8 CREATE TABLE the) — sab
`IF NOT EXISTS`/`ADD COLUMN IF NOT EXISTS`, dobara run karne se kuch nahi
tootega. File syntactically clean hai.

## Jo nahi chua

`00-COMBINED-DB-SCHEMA-ADDENDUM.sql` ko edit nahi kiya — wo already
superseded document hai (uske apne header me likha hai), sirf reference ke
liye carry kiya. `crm_lead`/`crm_stage` ke liye koi CREATE TABLE nahi diya —
wo Odoo apne aap banata hai, humein touch nahi karna.

## Suggested next step

Migration run karo (`DATABASE-SETUP-GUIDE.md` follow karke), phir
`N8N-Import-Order-Guide.md` ke Step 1 se shuru karo. Agar Option B
(databases alag hi rakhne hain, FDW ke saath) chahiye instead, bolo —
alag setup instructions de dunga.
