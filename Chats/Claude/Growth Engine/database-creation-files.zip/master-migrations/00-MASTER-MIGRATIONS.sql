-- ============================================================
-- 00-MASTER-MIGRATIONS.sql
-- Growth Engine — ONE file, run once, in this order, before
-- importing/activating ANY workflow (Phase 1 through Phase 7).
-- Replaces the previously scattered migration steps:
--   - DEPLOYMENT-GUIDE.md §7 (base clients_master table)
--   - 00-COMBINED-DB-SCHEMA-ADDENDUM.sql (Modules 6.5 -> 7.2)
--   - 001_phase4_sms_calling_schema.sql (Modules 4.1.3 -> 4.2.2)
--   - automation_errors (new — needed by the 0.0 Shared Error
--     Handler workflow introduced in the audit's Phase F1 fix)
--   - v2 update: Section 0 (funnel_events / flagged_events — the
--     star-topology Hub's own spine tables). These were used by
--     every single workflow.json in the reconciled tree but were
--     NEVER actually defined anywhere in any migration file —
--     genuinely missing until now, not previously documented as
--     a known gap. Without this section the Hub itself cannot run.
--   - v2 update: Section 6 (workflow_errors, qualification_records,
--     communication_events, linkedin_processed_messages,
--     n8n_processed_posts) — same situation: referenced by 10+
--     modules' Postgres nodes, never centrally defined. Some had
--     an inline "run once, disabled by default" CREATE TABLE node
--     inside their own workflow.json as a fallback (4.3.2, 4.3.3) —
--     those inline nodes are left as-is (harmless, IF NOT EXISTS),
--     but this file is now the actual single source of truth so
--     you don't have to hunt through 36 workflow.json files to
--     find out what your DB is supposed to look like.
--   - v2 update: 4 columns on clients_master that were being
--     ALTERed inline by individual modules (4.3.x, 6.1.1, 6.2.1)
--     but not listed here: last_reply_channel, last_reply_at,
--     linkedin_profile_url, adoption_checklist_created_at.
-- Safe to re-run: every statement is idempotent
-- (CREATE TABLE IF NOT EXISTS / ADD COLUMN IF NOT EXISTS).
--
-- ⚠️ WHICH DATABASE TO RUN THIS ON — read before running.
-- Module 1.5 (Central CRM Sync) queries Odoo's own `crm_lead` /
-- `crm_stage` tables AND `clients_master` in the same Postgres
-- node, using the credential named "Odoo Postgres". Postgres
-- can't join across two separate databases without dblink/FDW,
-- which nothing in this build sets up — so `crm_lead` and every
-- table in this file MUST live in the same physical database.
-- That means: run this file against Odoo's own Postgres database
-- (the one `crm_lead` already lives in), NOT the separate empty
-- `growthengine` container described in DEPLOYMENT-GUIDE.md §1/§7.
-- See DATABASE-SETUP-GUIDE.md in this delivery for the full
-- explanation and the two ways to resolve it.
-- ============================================================

-- ------------------------------------------------------------
-- SECTION 0 — Star Topology Spine (Hub-Intake + Hub-Dispatcher)
-- Every spoke's "Report to Hub" node inserts into funnel_events;
-- Hub-Dispatcher polls it, and anything without a wired Switch
-- branch falls into flagged_events. Nothing in Phase 0 onward
-- works without these two tables — create them FIRST.
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS funnel_events (
  id SERIAL PRIMARY KEY,
  event_type TEXT NOT NULL,
  source_module TEXT,
  client_id INTEGER,
  odoo_lead_id INTEGER,
  payload JSONB DEFAULT '{}'::jsonb,
  status TEXT DEFAULT 'pending',
  created_at TIMESTAMP DEFAULT now(),
  dispatched_at TIMESTAMP,
  completed_at TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_funnel_events_pending
  ON funnel_events (status, created_at) WHERE status = 'pending';

CREATE TABLE IF NOT EXISTS flagged_events (
  id SERIAL PRIMARY KEY,
  funnel_event_id INTEGER REFERENCES funnel_events(id),
  event_type TEXT,
  client_id INTEGER,
  payload JSONB DEFAULT '{}'::jsonb,
  flagged_at TIMESTAMP DEFAULT now(),
  reviewed BOOLEAN DEFAULT false
);
CREATE INDEX IF NOT EXISTS idx_flagged_events_unreviewed
  ON flagged_events (reviewed, flagged_at) WHERE reviewed = false;

-- ------------------------------------------------------------
-- SECTION 1 — Base Control Table (was DEPLOYMENT-GUIDE.md §7)
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS clients_master (
  id SERIAL PRIMARY KEY,
  odoo_lead_id INTEGER UNIQUE,
  name TEXT,
  email TEXT,
  phone TEXT,
  company TEXT,
  service_type TEXT,
  intent_summary TEXT,
  urgency TEXT,
  score TEXT,
  score_reason TEXT,
  source TEXT,
  status TEXT DEFAULT 'New',
  odoo_partner_id INTEGER,
  odoo_invoice_id INTEGER,
  nextcloud_folder_url TEXT,
  odoo_project_id INTEGER,
  odoo_discuss_channel_id INTEGER,
  last_report_sent_at TIMESTAMP,
  renewal_date DATE,
  renewal_reminder_sent_at TIMESTAMP,
  dunning_attempts INTEGER DEFAULT 0,
  created_at TIMESTAMP DEFAULT now(),
  updated_at TIMESTAMP DEFAULT now()
);

-- v2 addition — 4 columns individual modules were ALTERing inline
-- (4.3.x reply tracking, 6.1.1/6.2.1 onboarding/health) but were
-- never listed in this file:
ALTER TABLE clients_master ADD COLUMN IF NOT EXISTS last_reply_channel TEXT;
ALTER TABLE clients_master ADD COLUMN IF NOT EXISTS last_reply_at TIMESTAMP;
ALTER TABLE clients_master ADD COLUMN IF NOT EXISTS linkedin_profile_url TEXT;
ALTER TABLE clients_master ADD COLUMN IF NOT EXISTS adoption_checklist_created_at TIMESTAMP;

-- ------------------------------------------------------------
-- SECTION 2 — NEW: automation_errors (for the 0.0 Shared Error
-- Handler workflow — every module's settings.errorWorkflow now
-- points at that workflow, and it writes failures here)
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS automation_errors (
  id SERIAL PRIMARY KEY,
  workflow_id TEXT,
  workflow_name TEXT,
  failed_node_name TEXT,
  failed_node_type TEXT,
  error_message TEXT,
  execution_id TEXT,
  execution_url TEXT,
  occurred_at TIMESTAMP DEFAULT now(),
  reviewed BOOLEAN DEFAULT false
);
CREATE INDEX IF NOT EXISTS idx_automation_errors_unreviewed
  ON automation_errors (reviewed, occurred_at) WHERE reviewed = false;

-- ------------------------------------------------------------
-- SECTION 3 — Phase 4.1.3 / 4.2 (SMS + Cold Calling)
-- (was 001_phase4_sms_calling_schema.sql)
-- ------------------------------------------------------------
-- Consent / suppression columns (needed by 4.1.3 to scope to consented leads only)
ALTER TABLE clients_master ADD COLUMN IF NOT EXISTS sms_opt_out BOOLEAN DEFAULT false;
ALTER TABLE clients_master ADD COLUMN IF NOT EXISTS call_dnc BOOLEAN DEFAULT false;
ALTER TABLE clients_master ADD COLUMN IF NOT EXISTS active_sequence_suppressed BOOLEAN DEFAULT false;

-- 4.1.3 SMS Re-engagement
ALTER TABLE clients_master ADD COLUMN IF NOT EXISTS last_sms_sent_at TIMESTAMP;

-- 4.2.1 / 4.2.2 Cold Calling
ALTER TABLE clients_master ADD COLUMN IF NOT EXISTS last_call_at TIMESTAMP;
ALTER TABLE clients_master ADD COLUMN IF NOT EXISTS call_attempts INTEGER DEFAULT 0;
ALTER TABLE clients_master ADD COLUMN IF NOT EXISTS last_call_outcome TEXT;

-- Shared idempotency table (also reused by 4.2.2's Call Outcome Webhook
-- and by the Phase 3.0.1 HMAC patches, if/when those get built for real)
CREATE TABLE IF NOT EXISTS webhook_events (
  event_id TEXT PRIMARY KEY,
  source TEXT NOT NULL,
  received_at TIMESTAMP DEFAULT now(),
  processed_at TIMESTAMP,
  status TEXT DEFAULT 'received',
  attempts INTEGER DEFAULT 0,
  last_error TEXT,
  raw_payload JSONB
);

-- ------------------------------------------------------------
-- SECTION 4 — Phase 6.5 -> 7.2 (Retention/Advocacy/Deliverability)
-- (was 00-COMBINED-DB-SCHEMA-ADDENDUM.sql)
-- ------------------------------------------------------------

-- 6.1.1 Account Health Rollup + 6.3.1 Support Ticketing Wiring
-- (F6.1 closure: 6.1.1 reads this column that 6.3.1 writes — must exist before either
-- module's FIRST run, so it's here instead of only inline in 6.3.1's own query.)
ALTER TABLE clients_master ADD COLUMN IF NOT EXISTS support_ticket_count INTEGER DEFAULT 0;
ALTER TABLE clients_master ADD COLUMN IF NOT EXISTS health_score INTEGER;
ALTER TABLE clients_master ADD COLUMN IF NOT EXISTS health_score_snapshot_at TIMESTAMP;

-- 6.5 Churn Win-back
ALTER TABLE clients_master ADD COLUMN IF NOT EXISTS winback_step INTEGER DEFAULT 0;
ALTER TABLE clients_master ADD COLUMN IF NOT EXISTS last_winback_sent_at TIMESTAMP;

-- 6.6 NPS
CREATE TABLE IF NOT EXISTS nps_responses (
  id SERIAL PRIMARY KEY,
  client_id INTEGER REFERENCES clients_master(id),
  score INTEGER,
  feedback_text TEXT,
  submitted_at TIMESTAMP DEFAULT now()
);
ALTER TABLE clients_master ADD COLUMN IF NOT EXISTS last_nps_sent_at TIMESTAMP;
ALTER TABLE clients_master ADD COLUMN IF NOT EXISTS promoter_flag BOOLEAN DEFAULT false;
ALTER TABLE clients_master ADD COLUMN IF NOT EXISTS promoter_flagged_at TIMESTAMP;
-- Only needed if using the token-lookup approach noted in 6.6's README:
CREATE TABLE IF NOT EXISTS nps_survey_tokens (
  token TEXT PRIMARY KEY,
  client_id INTEGER REFERENCES clients_master(id),
  created_at TIMESTAMP DEFAULT now()
);

-- 6.7 Case Studies
CREATE TABLE IF NOT EXISTS case_studies (
  id SERIAL PRIMARY KEY,
  client_id INTEGER REFERENCES clients_master(id),
  raw_reply TEXT,
  polished_quote TEXT,
  status TEXT DEFAULT 'pending_client_approval',
  created_at TIMESTAMP DEFAULT now()
);
ALTER TABLE clients_master ADD COLUMN IF NOT EXISTS testimonial_ask_sent_at TIMESTAMP;

-- 6.8 Referral Program
CREATE TABLE IF NOT EXISTS referrals (
  id SERIAL PRIMARY KEY,
  referrer_client_id INTEGER REFERENCES clients_master(id),
  referral_code TEXT UNIQUE,
  status TEXT DEFAULT 'link_generated',
  converted_at TIMESTAMP,
  created_at TIMESTAMP DEFAULT now()
);
ALTER TABLE clients_master ADD COLUMN IF NOT EXISTS referral_code_used TEXT;
-- Still open per the original module README: referral_code_used isn't
-- populated by any workflow yet — needs a small patch in Module 1.3/1.4
-- to capture ?ref=<code> from the inbound lead source.

-- 6.9 Advocacy
ALTER TABLE clients_master ADD COLUMN IF NOT EXISTS advocate_flag BOOLEAN DEFAULT false;
-- Still open per the original module README: not auto-set by any
-- workflow yet — set manually after human review for now.

-- 7.2 List Segmentation
ALTER TABLE clients_master ADD COLUMN IF NOT EXISTS list_segment TEXT;

-- ------------------------------------------------------------
-- SECTION 5 — F3 fix: unmatched-stage / unwired-branch logging
-- (needed by the 1.5 Central CRM Sync fix — see F3.1)
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS unmatched_stage_events (
  id SERIAL PRIMARY KEY,
  client_id INTEGER REFERENCES clients_master(id),
  odoo_lead_id INTEGER,
  detected_stage TEXT,
  source_workflow TEXT DEFAULT '1.5-central-crm-sync',
  detected_at TIMESTAMP DEFAULT now(),
  reviewed BOOLEAN DEFAULT false
);

-- ------------------------------------------------------------
-- SECTION 6 — v2 addition: tables referenced by 10+ modules'
-- Postgres nodes but never centrally defined anywhere
-- ------------------------------------------------------------

-- Used by: 4.3.1, 4.3.2, 4.3.3 (reply channels), 6.1.1 (last-contact
-- rollup query). Each of 4.3.2/4.3.3 also has its own inline
-- "run once" fallback CREATE TABLE — left in place, harmless
-- (IF NOT EXISTS), this is just the one place to see it up front.
CREATE TABLE IF NOT EXISTS communication_events (
  id SERIAL PRIMARY KEY,
  client_id INTEGER REFERENCES clients_master(id),
  channel TEXT,
  direction TEXT,
  content TEXT,
  occurred_at TIMESTAMP DEFAULT now(),
  workflow_source TEXT
);

-- Used by: 4.3.2 (LinkedIn reply-check dedup). Inline fallback
-- also exists in that module's own workflow.json.
CREATE TABLE IF NOT EXISTS linkedin_processed_messages (
  message_id TEXT PRIMARY KEY,
  processed_at TIMESTAMP DEFAULT now()
);

-- Used by: 1.1 (Content → Social Factory) to avoid re-posting the
-- same blog_post row twice. `blog_post` itself is Odoo's own CMS
-- table (or whatever CMS you're on) — do not create it here, only
-- the dedup-tracking table is ours.
CREATE TABLE IF NOT EXISTS n8n_processed_posts (
  post_id INTEGER PRIMARY KEY,
  processed_at TIMESTAMP DEFAULT now()
);

-- Used by: 5.1.1 (BANT/MEDDIC Extraction writes), 5.1.2 (Write
-- Qualification to Odoo reads, joined against clients_master).
CREATE TABLE IF NOT EXISTS qualification_records (
  id SERIAL PRIMARY KEY,
  client_id INTEGER REFERENCES clients_master(id),
  framework TEXT,
  assessment JSONB,
  decision TEXT,
  assessed_by TEXT,
  assessed_at TIMESTAMP DEFAULT now()
);

-- Used by: 4.3.3, 5.1.1, 5.1.2, 6.1.1, 6.2.1, 6.3.1, 6.4.1 — each
-- module's own inline validation/business-logic error branches
-- (e.g. "no matching client_id found", "Odoo write failed").
-- NOT the same table as `automation_errors` (Section 2 above) —
-- that one is written by the shared n8n-level error workflow when
-- a node throws unexpectedly. `workflow_errors` is written
-- deliberately, mid-workflow, by a module's own logic when it
-- hits an expected-but-unhappy case it still wants a human to
-- review. Both are needed; they serve different layers.
CREATE TABLE IF NOT EXISTS workflow_errors (
  id SERIAL PRIMARY KEY,
  workflow_name TEXT,
  execution_id TEXT,
  node_name TEXT,
  error_message TEXT,
  input_payload JSONB,
  occurred_at TIMESTAMP DEFAULT now(),
  reviewed BOOLEAN DEFAULT false
);
CREATE INDEX IF NOT EXISTS idx_workflow_errors_unreviewed
  ON workflow_errors (reviewed, occurred_at) WHERE reviewed = false;

-- ============================================================
-- END — after running this once, every module in the zip can be
-- imported and activated without hitting "column does not exist"
-- or "relation does not exist".
-- ============================================================
