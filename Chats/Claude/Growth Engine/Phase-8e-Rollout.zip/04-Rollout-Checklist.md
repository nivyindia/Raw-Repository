# Phase 8e — Rollout Checklist

Launch se pehle ka single checklist — technical (already ready) + business
(aapka kaam) dono ek jagah, taaki kuch bhoola na jaaye.

## Technical — already done across 8a/8b/8c (✅ ready, verify once)

- [ ] `01-PHASE-8-MIGRATIONS.sql` (v2, from `8a.zip`) Postgres pe run ho chuka hai
- [ ] `02-CAMPAIGN-SEED-DATA.sql` (from `8b_supporting_files.zip`) run ho chuka hai — 4 draft campaigns dikhne chahiye
- [ ] 8.1, 8.2, 8.3 `workflow.json` files n8n me import ho chuke hain, Hub-Intake ID bhara hai (Plan task #5–7)
- [ ] Hub-Dispatcher me `contest.*`, `referral.*`, `audit.completed` branches add ho chuke hain (Plan task #10)
- [ ] **`00-PRELAUNCH-QA-FINDINGS.md` ke dono fixes apply ho chuke hain** (contest_id + referral manual issuance) — is package ka sabse zaroori item
- [ ] `01-ACTIVATE-LAUNCH-CAMPAIGNS.sql` (is package) run ho chuka hai

## Credentials — aapka kaam (❌), koi bhi ek missing ho to launch mat karo

- [ ] WhatsApp/Telegram/Email NoOp nodes real credentials se wire (8.1, 8.2, 8.3)
- [ ] Firecrawl + PageSpeed API keys (8.3, agar audit engine me use ho raha hai)
- [ ] Odoo Discuss webhook working (winner-approval aur payout-approval dono isi pe depend karte hain)
- [ ] Landing pages (8b) ke `WEBHOOK_URL` placeholders real n8n webhook URLs se bhar diye

## Legal/business — aapka kaam (❌), Section 7 ki guardrails

- [ ] Reward amounts / contest prize components final ho chuke (abhi placeholder hain, `02-CAMPAIGN-SEED-DATA.sql` me)
- [ ] `03-Country-Specific-Legal-Notes.md` (8b) padha aur target countries ke liye applicable clauses check kiye
- [ ] Contest T&C, Official Rules, Privacy Notice — kam se kam ek lawyer-eyes pass ho chuka (khaas kar agar chance-element ya cash prize > $5k ho)
- [ ] Referral program payout process (Odoo vendor bill / expense) actually kaam karta hai, sirf placeholder nahi

## Go-live

- [ ] Sabse pehle **sirf 3 campaigns** active karo (1 contest + 1 referral + 1 audit) — Plan Section 3.3
- [ ] Ek internal test-entry khud daal ke poora funnel end-to-end check karo (entry → fraud score → Hub event → dashboard view me dikhna chahiye) — real users ko bhejne se pehle
- [ ] `02-WEEKLY-REVIEW-DASHBOARD-QUERIES.sql` ka Query #5 (summary) day-1 pe ek baar chala ke confirm karo ki data flow ho raha hai
