# Phase 8e — Scale-or-Kill Decision Framework

Task #23 ("jo kaam kare usko scale, jo na kare band"). Ye framework subjective
"lag raha hai achha chal raha hai" feeling ki jagah **objective threshold**
deta hai — 2 hafte ke baad in numbers ko `02-WEEKLY-REVIEW-DASHBOARD-QUERIES.sql`
se nikaal ke seedha yahan match karo.

> Threshold numbers **starting suggestions** hain, business-specific nahi —
> aapke actual CAC/LTV/margins ke hisab se pehle 2 hafte ke baad khud se
> calibrate karna, ye sirf pehla decision-pass hai jab tak koi baseline nahi
> hai.

---

## 8.1 — Contest Engine (`nivy-top-100-2026`)

| Signal | Kill | Watch | Scale |
|---|---|---|---|
| Entries in 14 days | < 20 | 20–100 | > 100 |
| Fraud rate | > 25% | 10–25% | < 10% |
| Verified-entry rate | < 40% | 40–70% | > 70% |

**Kill ka matlab:** contest format khud kaam nahi kar raha ya distribution
channel galat hai — dobara category/prize/channel change karke retry karo,
turant band mat karo permanently pehli baar me.

**Scale ka matlab:** next category/theme launch karo (dusra `contests` row,
same `campaigns` row ya naya campaign — Section 3.2 pattern), aur channels
badhao (LinkedIn already hai, Instagram/Facebook add karne ka waqt hai).

---

## 8.2 — Referral Engine (`refer-and-earn-global`)

| Signal | Kill | Watch | Scale |
|---|---|---|---|
| Referrals in 14 days (per 10 codes issued) | < 1 | 1–3 | > 3 |
| Meeting-booked rate | < 15% | 15–35% | > 35% |
| Reward liability vs. revenue from converted referrals | liability > revenue | roughly even | revenue clearly > liability |

**Kill se pehle check karo:** kya ye engine ka fault hai ya sirf itna kam
codes issue hue the (Finding 2, Option A manual issuance) ki sample size
hi chota tha? Agar < 20 codes issued the, "kill" mat bolo — pehle Option B
(self-serve generation) build karo aur zyada referrers ko reach karo.

**Scale ka matlab:** manual issuance se self-serve (Option B) pe move karo,
aur `diwali-referral-2026` jaise time-boxed variant ko bhi activate karo.

---

## 8.3 — Free-Audit Engine (`free-global-audit`)

| Signal | Kill | Watch | Scale |
|---|---|---|---|
| Audit requests in 14 days | < 15 | 15–50 | > 50 |
| Later-qualified rate (`later_qualified_count` / `total_requests`) | < 5% | 5–15% | > 15% |
| Avg turnaround vs. 24h SLA (config'd) | consistently late | occasionally late | on-time |

**Kill ka matlab yahan alag hai:** ye engine sirf lead-magnet hai, revenue
directly nahi banata — "kill" ka matlab hoga ki koi audit-requester aage
qualify hi nahi ho raha, jiska matlab lead quality kharab hai ya nurture
follow-up (2.1 Outreach handoff) toot gaya hai — pehle wahan dekho, engine
ko band karne se pehle.

---

## Cross-engine reality check (sabke liye)

- **2 hafte kaafi kam hai statistically confident hone ke liye** agar
  volume bahut chota hai (jaise 5 entries) — aisi situation me "extend
  another week" bhi ek valid decision hai, forced scale/kill nahi.
- **Operational bandwidth ka bhi dhyaan rakho** (Plan Section 3.3 ka point):
  agar contest entries scale kar rahe hain lekin fraud-review manual queue
  overflow ho rahi hai, wo bhi ek "kill/pause tak" signal hai — engine kaam
  kar raha hai lekin aap manage nahi kar pa rahe, alag problem hai.
- **Ek engine kill hone ka matlab poora Phase 8 fail nahi** — har engine
  independent spoke hai (Hub-Dispatcher pattern), baaki 2 chalte reh sakte
  hain bina kisi impact ke.
