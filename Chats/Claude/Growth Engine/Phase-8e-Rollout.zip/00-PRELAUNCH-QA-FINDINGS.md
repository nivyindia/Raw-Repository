# Phase 8e — Pre-launch QA Findings

Rollout se pehle maine 8a's actual `workflow.json` files (jo asli source of
truth hain) ko 8b ke landing pages/seed-data ke saath cross-check kiya —
kyunki activation ka matlab hi ye hai ki ab ye sab pehli baar real traffic
handle karega. **2 genuine wiring mismatches mile**, dono ka fix neeche hai.
Koi bhi n8n workflow.json edit nahi karna pada — dono fixes landing-page/SQL
side pe hain.

---

## Finding 1 — 8.1 Contest: landing page `campaign_slug` bhejta hai, workflow `contest_id` maangta hai

**Kya hai:** `8b/04-landing-page-contest-entry.html` apne form-submit payload
me `campaign_slug` bhejta hai. Lekin `8.1-Reward-Contest-Engine.json` ke
`Set - Normalize Input` node me sirf ye line hai:

```
contest_id: {{$json.body.contest_id}}
```

`campaign_slug` field ko workflow kahin bhi padhta hi nahi — seedha
`contests` table me `id` se lookup karta hai (`Postgres - Lookup Contest
Config`). Matlab agar landing page waise ki waise chhodi to har entry
`contest_id: undefined` ke saath jaayegi aur `IF - Contest Selection Valid`
step pe reject ho jaayegi — **koi bhi real entry save nahi hogi.**

**Kyun hua:** 8a (workflow) aur 8b (landing page) alag batches me bane the,
dono ne plan ke Section 3.2 ka "campaign-aware" pattern generically follow
kiya lekin 8.1 ka actual DB schema (`contests` ek alag table hai, `campaigns`
se separate) dono jagah match nahi hua.

**Fix (landing page me, ~3 lines):** `04-landing-page-contest-entry.html`
ke `<script>` block me, `WEBHOOK_URL` ke paas ye add karo:

```js
// Fix: workflow needs contest_id (from `contests` table), not campaign_slug.
// 01-ACTIVATE-LAUNCH-CAMPAIGNS.sql chalane ke baad us script ka RAISE NOTICE
// output ya `SELECT id FROM contests WHERE campaign_id = (SELECT id FROM campaigns WHERE campaign_slug='nivy-top-100-2026')`
// se real contest_id number nikaal ke yahan daalo:
const CONTEST_ID = REPLACE_WITH_CONTEST_ID; // e.g. 1

const payload = {
  contest_id: CONTEST_ID,        // <-- add this line, workflow reads only this
  campaign_slug: campaignSlug,   // harmless to keep, workflow ignores it today
  business: document.getElementById('business').value,
  ...
```

`01-ACTIVATE-LAUNCH-CAMPAIGNS.sql` (is package me) chalane ke baad uska
output tumhe exact `contest_id` de dega — wahi number `CONTEST_ID` me daal
dena.

---

## Finding 2 — 8.2 Referral: landing page self-serve code-generation assume karta hai, workflow me wo endpoint hai hi nahi

**Kya hai:** `8b/02-landing-page-referral.html` ek form hai jahan referrer
apna naam/email/tier daal ke submit karta hai, aur comment kehta hai
*"connect WEBHOOK_URL for a real tracked code"* — matlab ye maan ke chala
gaya hai ki webhook ek naya `referral_code` **generate karke return**
karega.

Lekin `8.2-Referral-Engine-Universal.json` me sirf **ek** webhook hai —
`Webhook - Referral Submitted` (path `referral-submit`) — jo ek **existing**
`referral_code` ko `referral_codes` table me lookup karta hai
(`Postgres - Resolve Referral Code`). Ye webhook us **referred person** ke
liye hai (jisko code mila), naya code **banane** wala koi endpoint workflow
me nahi hai.

**Kyun hua:** Plan ka Section 2 generic pattern ("Entry point → ... → Core
action: insert record, calculate score, generate code/link") 8.2 ke liye
code-generation ko implicitly cover karta hai, lekin actual 8.2 build sirf
redemption side pe focus kar gaya — generation side reserved reh gaya
(jaisa 8c README me 8.4/8.5 ke liye already flag kiya gaya "not this
batch's scope" pattern).

**Fix (do options, aapki call):**

**Option A — Manual issuance (abhi ke liye, launch block nahi karta):**
Pehle batch of referrers (jaise top 10-20 existing clients) ko codes manually
issue karo via SQL — template `01-ACTIVATE-LAUNCH-CAMPAIGNS.sql` ke Section 3
me diya hai. Referral landing page ka public self-serve form **launch pe mat
lagao abhi** — sirf pre-issued codes wale clients ko unka code email/WhatsApp
se seedha bhejo, wo apna link share karein.

**Option B — Proper fix (naya workflow node, out of this package's scope):**
`8.2-Referral-Engine-Universal.json` me ek naya webhook branch add karo
(`/referral-generate-code`) jo naya `referral_codes` row insert kare aur code
return kare, phir landing page ka `WEBHOOK_URL` usse point karo. Ye n8n
workflow edit hai — agla batch me bolna to bana dunga.

**Recommendation:** Launch Option A se karo (koi extra build nahi chahiye,
aaj hi ready hai), Option B parallel me schedule kar do agle batch ke liye
jab referral program self-serve scale karna ho.

---

## Kya check kiya, koi aur gap nahi mila

- ✅ 8.3 Free-Audit: landing page `campaign_slug` bhejta hai, workflow's
  campaign-lookup optional hai (`campaign_id` nullable) aur `Set - Normalize
  Input` `campaign_slug` hi padhta hai — **match hai, koi fix nahi chahiye**
- ✅ 8.1/8.2/8.3 sabke Report-to-Hub nodes ka event-type naming Plan ke
  Section 2 table se match karta hai
- ⚠️ 8.4/8.5/8.6 abhi 8e ke launch batch me nahi hain (Section 3.3 ke
  mutabik pehle sirf 3 launch karo) — inka QA next rollout wave (task #24)
  pe hoga jab inhe activate karoge
