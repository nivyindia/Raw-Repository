# Phase 8e — Rollout (Business Side)

Implementation Plan ke Section 6 aur Section 9 (Progress Tracker) ke
**8e — Rollout** tasks #20–23 ka package. 8a (foundation), 8b (3 engines ke
supporting files), 8c (4 baaki engines + dashboard) already ban chuke hain —
ab yahi sab pehli baar **live** karne ka step hai.

> **Important:** Plan ki apni Section 8 table ke mutabik "kaunsa campaign
> pehle live karna hai, kitna budget, reward/legal terms finalize" — ye sab
> **business decisions** hain jo main khud nahi le sakta. Is package me
> maine wahi kiya jo main kar sakta hoon: activation SQL, monitoring
> queries, aur decision-*framework* — final numbers/go-live call aapka hai.

---

## Is package me kya hai

| File | Kya karta hai |
|---|---|
| `00-PRELAUNCH-QA-FINDINGS.md` | **Pehle ye padho.** Rollout-readiness check karte waqt 2 real wiring gaps mile (8a ↔ 8b ke beech) — dono ka fix diya hai |
| `01-ACTIVATE-LAUNCH-CAMPAIGNS.sql` | Plan Section 3.3 ke suggestion (1 contest + 1 referral + 1 free-audit) ko `draft` → `active` karta hai, **plus** missing `contests` / `referral_codes` child rows jo 8b ki seed data me chhoot gayi thi |
| `02-WEEKLY-REVIEW-DASHBOARD-QUERIES.sql` | Task #22 ("2 hafte data dekho") ke liye ready-made queries — 8c ke `growth_*` views ke upar, last-14-days filtered |
| `03-Scale-or-Kill-Decision-Framework.md` | Task #23 — har engine ke liye objective scale/pause/kill criteria, guesswork nahi |
| `04-Rollout-Checklist.md` | Launch se pehle ka combined checklist — technical (mera kaam, ✅ ready) + business (aapka kaam, ❌ pending) dono ek jagah |

---

## Sequence — is order me chalo

1. `00-PRELAUNCH-QA-FINDINGS.md` padho, 2 patches apply karo (5 min ka kaam, dono chhote hain)
2. `01-ACTIVATE-LAUNCH-CAMPAIGNS.sql` run karo (Postgres) — isse 3 campaigns live ho jaayenge DB-side
3. Landing pages (8b package) ke `WEBHOOK_URL` placeholders real n8n webhook URLs se bharo (jab 8.1/8.2/8.3 import ho chuke ho — Phase 8b/8d ka kaam)
4. 2 hafte chalne do, roz na sahi to har 2-3 din `02-WEEKLY-REVIEW-DASHBOARD-QUERIES.sql` chalao
5. Din 14 pe `03-Scale-or-Kill-Decision-Framework.md` ke criteria se decide karo — scale, pause, ya kill
6. Jo scale karna hai uske liye 8.4/8.5/8.6 campaigns dheere-dheere add karo (plan task #24, isi pattern se)

---

## Plan ke Section 9 tracker se mapping

| # | Task | Is package me kahan |
|---|---|---|
| 20 | Reward amounts / contest copy / legal terms finalize | ❌ Aapka kaam — 8b ke draft docs edit karo |
| 21 | Pehle 2-3 campaigns `active` karo | ✅ `01-ACTIVATE-LAUNCH-CAMPAIGNS.sql` |
| 22 | 2 hafte data monitor karo | ✅ `02-WEEKLY-REVIEW-DASHBOARD-QUERIES.sql` |
| 23 | Scale/kill decide karo | ✅ framework diya, final call aapka |
