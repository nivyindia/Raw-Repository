-- ============================================================
-- Phase 8e — Weekly / bi-weekly review queries
-- Task #22 ("2 hafte data dekho"). Run these against the same
-- Postgres DB, any time after 01-ACTIVATE-LAUNCH-CAMPAIGNS.sql.
-- Builds on the 8 views from 02-PHASE-8c-DASHBOARD-VIEWS.sql —
-- run that file first if you haven't (safe, all CREATE OR REPLACE).
-- Every query below is read-only (SELECT), safe to run anytime.
-- ============================================================

-- ------------------------------------------------------------
-- 1. Snapshot — the 3 launched campaigns, one row each, at a
--    glance. Start here every time you check in.
-- ------------------------------------------------------------
SELECT * FROM growth_campaign_performance
WHERE campaign_slug IN ('nivy-top-100-2026', 'refer-and-earn-global', 'free-global-audit');

-- ------------------------------------------------------------
-- 2. 8.1 Contest — entries, fraud rate, day-by-day trend since
--    launch (spot a stall/spike early, don't wait the full 2 weeks
--    to notice zero entries on day 3).
-- ------------------------------------------------------------
SELECT * FROM contest_performance WHERE campaign_slug = 'nivy-top-100-2026';

SELECT
  DATE(ce.submitted_at) AS day,
  COUNT(*) AS entries,
  COUNT(*) FILTER (WHERE ce.verified) AS verified,
  ROUND(AVG(ce.fraud_score), 1) AS avg_fraud_score
FROM contest_entries ce
JOIN contests ct ON ct.id = ce.contest_id
JOIN campaigns c ON c.id = ct.campaign_id
WHERE c.campaign_slug = 'nivy-top-100-2026'
  AND ce.submitted_at >= now() - interval '14 days'
GROUP BY DATE(ce.submitted_at)
ORDER BY day;

-- ------------------------------------------------------------
-- 3. 8.2 Referral — funnel + running reward liability (what
--    you'd owe if every pending reward got approved today —
--    watch this doesn't run away from your budget).
-- ------------------------------------------------------------
SELECT * FROM referral_performance WHERE campaign_slug = 'refer-and-earn-global';

SELECT
  DATE(rl.created_at) AS day,
  COUNT(*) AS new_referrals,
  COUNT(*) FILTER (WHERE rl.stage IN ('meeting_booked','converted','paid')) AS progressed
FROM referral_ledger rl
JOIN referral_codes rc ON rc.id = rl.referral_code_id
JOIN campaigns c ON c.id = rc.campaign_id
WHERE c.campaign_slug = 'refer-and-earn-global'
  AND rl.created_at >= now() - interval '14 days'
GROUP BY DATE(rl.created_at)
ORDER BY day;

-- ------------------------------------------------------------
-- 4. 8.3 Free-Audit — volume + how many later became a real,
--    qualified lead in the main funnel (this is the number that
--    actually justifies the engine's existence).
-- ------------------------------------------------------------
SELECT * FROM audit_engine_performance WHERE campaign_slug = 'free-global-audit';

SELECT
  DATE(ar.completed_at) AS day,
  COUNT(*) AS audits_completed,
  ROUND(AVG(ar.score), 1) AS avg_score
FROM audit_requests ar
JOIN campaigns c ON c.id = ar.campaign_id
WHERE c.campaign_slug = 'free-global-audit'
  AND ar.completed_at >= now() - interval '14 days'
GROUP BY DATE(ar.completed_at)
ORDER BY day;

-- ------------------------------------------------------------
-- 5. One-glance summary table — paste this into your weekly
--    review doc / Slack update.
-- ------------------------------------------------------------
SELECT
  c.campaign_slug,
  c.engine,
  c.status,
  EXTRACT(DAY FROM now() - c.starts_at)::int AS days_live,
  COUNT(fe.id) AS total_events,
  COUNT(DISTINCT fe.client_id) AS unique_participants
FROM campaigns c
LEFT JOIN funnel_events fe ON (fe.payload->>'campaign_id')::int = c.id
WHERE c.campaign_slug IN ('nivy-top-100-2026', 'refer-and-earn-global', 'free-global-audit')
GROUP BY c.campaign_slug, c.engine, c.status, c.starts_at
ORDER BY c.engine;

-- ============================================================
-- Tip: run query #5 every 2-3 days and keep the outputs (copy
-- into a sheet or Odoo note) — you need at least 3-4 data points
-- across the 2 weeks to tell a real trend from day-to-day noise,
-- one snapshot at day 14 alone isn't enough.
-- ============================================================
