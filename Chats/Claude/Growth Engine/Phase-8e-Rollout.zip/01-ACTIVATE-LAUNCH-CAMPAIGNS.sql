-- ============================================================
-- Phase 8e — Activate first launch campaigns
-- Run AFTER: 01-PHASE-8-MIGRATIONS.sql (v2, from 8a.zip) and
-- 02-CAMPAIGN-SEED-DATA.sql (from 8b_supporting_files.zip).
--
-- Implements Plan Section 3.3 + Section 9 task #21: launch the
-- first 3 campaigns (1 contest + 1 referral + 1 free-audit),
-- NOT all six at once.
--
-- Also fixes a real gap: 02-CAMPAIGN-SEED-DATA.sql only inserted
-- `campaigns` rows — it never created the child `contests` /
-- `referral_codes` rows that 8.1's and 8.2's actual workflow.json
-- Postgres nodes require (see 00-PRELAUNCH-QA-FINDINGS.md,
-- Finding 1 & 2). This script creates those too.
--
-- Safe to re-run: every INSERT is guarded with a NOT EXISTS /
-- ON CONFLICT check.
-- ============================================================

-- ------------------------------------------------------------
-- 0. Sanity check — make sure the 3 target campaigns exist as
--    'draft' before we touch anything. If this returns fewer
--    than 3 rows, run 02-CAMPAIGN-SEED-DATA.sql first.
-- ------------------------------------------------------------
-- SELECT campaign_slug, engine, status FROM campaigns
-- WHERE campaign_slug IN ('nivy-top-100-2026','refer-and-earn-global','free-global-audit');

-- ------------------------------------------------------------
-- 1. 8.1 Contest — create the missing `contests` row
--    (8.1's workflow looks up `contests`, not `campaigns`,
--    see QA Finding 1). campaign.config is reused as-is since
--    it already has fraud_threshold etc.
-- ------------------------------------------------------------
INSERT INTO contests (campaign_id, name, status, config, starts_at, ends_at)
SELECT c.id, c.config->>'name', 'active', c.config, c.starts_at, c.ends_at
FROM campaigns c
WHERE c.campaign_slug = 'nivy-top-100-2026'
  AND NOT EXISTS (SELECT 1 FROM contests ct WHERE ct.campaign_id = c.id);

-- ⚠️ Take note of the id this created — the landing page needs it
-- (00-PRELAUNCH-QA-FINDINGS.md, Finding 1, CONTEST_ID constant):
SELECT ct.id AS contest_id, ct.name, c.campaign_slug
FROM contests ct JOIN campaigns c ON c.id = ct.campaign_id
WHERE c.campaign_slug = 'nivy-top-100-2026';

-- ------------------------------------------------------------
-- 2. 8.2 Referral — manual code issuance (QA Finding 2, Option A).
--    Template only: fill in real referrer emails before running.
--    Skips referrers who already have a code for this campaign
--    (won't double-issue on re-run).
--
--    HOW TO USE: replace the VALUES rows below with your actual
--    first-wave referrer list (existing happy clients are the
--    best first batch), then uncomment and run just this block.
-- ------------------------------------------------------------
-- WITH target_campaign AS (
--   SELECT id FROM campaigns WHERE campaign_slug = 'refer-and-earn-global'
-- ),
-- referrers(email, tier) AS (
--   VALUES
--     ('REPLACE_WITH_CLIENT_EMAIL_1@example.com', 'standard'),
--     ('REPLACE_WITH_CLIENT_EMAIL_2@example.com', 'alumni')
--     -- add more rows as needed
-- )
-- INSERT INTO referral_codes (campaign_id, code, referrer_client_id, referrer_type)
-- SELECT
--   tc.id,
--   'NIVY-' || UPPER(SUBSTRING(MD5(cm.email || tc.id::text), 1, 6)),  -- e.g. NIVY-4F9A2C
--   cm.id,
--   'client'
-- FROM referrers r
-- JOIN clients_master cm ON cm.email = r.email
-- CROSS JOIN target_campaign tc
-- WHERE NOT EXISTS (
--   SELECT 1 FROM referral_codes rc WHERE rc.referrer_client_id = cm.id AND rc.campaign_id = tc.id
-- );
--
-- -- Check what got issued, so you can message each referrer their code:
-- SELECT rc.code, cm.email, cm.company_name
-- FROM referral_codes rc JOIN clients_master cm ON cm.id = rc.referrer_client_id
-- JOIN campaigns c ON c.id = rc.campaign_id
-- WHERE c.campaign_slug = 'refer-and-earn-global';

-- ------------------------------------------------------------
-- 3. 8.3 Free-Audit — no child table needed, campaign_id is
--    nullable in `audit_requests` (organic requests work fine).
--    Nothing to do here beyond the status flip below.
-- ------------------------------------------------------------

-- ------------------------------------------------------------
-- 4. Flip all 3 to 'active' — the actual "go live" moment.
--    Do this LAST, after Section 1/2 are done, so nothing goes
--    live half-wired.
-- ------------------------------------------------------------
UPDATE campaigns
SET status = 'active', updated_at = now()
WHERE campaign_slug IN ('nivy-top-100-2026', 'refer-and-earn-global', 'free-global-audit')
  AND status = 'draft';

-- ------------------------------------------------------------
-- 5. Confirm
-- ------------------------------------------------------------
SELECT campaign_slug, engine, campaign_type, status, starts_at, ends_at
FROM campaigns
WHERE campaign_slug IN ('nivy-top-100-2026', 'refer-and-earn-global', 'free-global-audit')
ORDER BY engine;

-- ============================================================
-- Reminder: diwali-referral-2026, nivy-showcase-2026 (8.4) and
-- founders-circle-global (8.5) STAY 'draft' on purpose — per
-- Plan Section 3.3, don't launch more than 2-3 at once. Add
-- them in a later wave once these 3 have 2 weeks of clean data
-- (see 03-Scale-or-Kill-Decision-Framework.md).
-- ============================================================
