-- BONUS (not in the plan's S7.3 spec, optional) -- a one-row summary strip
-- across the top of the dashboard: total pending / dispatched / done / failed.
-- Metabase viz: "Table" with "Conditional formatting" on the failed column
-- (e.g. red background if failed > 0), or split into 4 separate "Number" cards.

SELECT
  COUNT(*) FILTER (WHERE status = 'pending')    AS pending,
  COUNT(*) FILTER (WHERE status = 'dispatched') AS dispatched,
  COUNT(*) FILTER (WHERE status = 'done')       AS done,
  COUNT(*) FILTER (WHERE status = 'failed')     AS failed,
  COUNT(*)                                      AS total
FROM funnel_events;
