-- Panel 1: Counts by event_type and status
-- Metabase viz: "Pivot Table" (rows = event_type, columns = status) OR "Bar chart, stacked" (x = event_type, series = status)
-- This is the main "what's flowing through the funnel right now" view.

SELECT
  event_type,
  status,
  COUNT(*) AS event_count
FROM funnel_events
GROUP BY event_type, status
ORDER BY event_type, status;
