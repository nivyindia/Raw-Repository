# S7.3 — Funnel Health Dashboard (Metabase, on `funnel_events`)

> Plan step: *"Build one simple dashboard (Metabase, already in the stack per module 2.8) on `funnel_events`: counts by `event_type` and `status`, oldest pending event age, failed-event list. This becomes the single screen that shows the health of the entire funnel."*

## ⚠️ Blocker — `funnel_events` table doesn't exist yet

This dashboard needs **S0.1** done first (create the `funnel_events` table, plan §0.1). None of the SQL below will run until that table exists — and it'll show an empty dashboard until Hub-Intake (S1) is actually receiving events from at least one rewired spoke. Everything here is ready to paste in the moment S0.1 lands; no other dependency (this dashboard only reads the table, it doesn't need the Hub-Dispatcher or any spoke to be finished).

## What's in this folder

Four SQL queries, one per dashboard panel (`04` is a bonus, not in the original spec):

| File | Panel | Metabase viz |
|---|---|---|
| `01-counts-by-event-type-and-status.sql` | Counts by event_type and status | Pivot Table or stacked Bar chart |
| `02-oldest-pending-event-age.sql` | Oldest pending event age (+ optional drill-down queue) | Number, with linked Table |
| `03-failed-event-list.sql` | Failed-event list | Table |
| `04-bonus-status-summary.sql` | *(bonus, optional)* overall pending/dispatched/done/failed counts | Table or 4x Number |

## Setup (same pattern as Module 2.8's Metabase integration)

Nivy already has Metabase self-hosted with Postgres connected (per 2.8's README) — no new infra needed, just new saved questions on the same database connection.

1. **Metabase → New → SQL Query** — for each `.sql` file above, paste the query, save as a **Card** (e.g. "Funnel — Counts by Type/Status", "Funnel — Oldest Pending Age", "Funnel — Failed Events").
2. **Metabase → New → Dashboard** — name it something like "Growth Engine — Funnel Health", add all 3 (or 4, if using the bonus) cards to it.
3. Set the **Number** card (02) to auto-refresh — Dashboard settings → Auto-refresh → 1 or 2 min, matching the Hub-Dispatcher's own poll interval (plan §0.2), so the number stays live without manual refresh.
4. *(Optional, matching 2.8's pattern)* Enable **Public Sharing** on this dashboard if it needs to be glanceable outside Metabase logins — same Admin → Sharing → Public Sharing toggle 2.8 already uses for client dashboards. For an internal ops dashboard this is probably unnecessary; a normal Metabase login is fine unless Nivy wants it on a wall-mounted screen or similar.
5. No new env vars needed in n8n — this dashboard doesn't touch any workflow, it's a direct Metabase-to-Postgres read. `METABASE_URL` / `METABASE_API_KEY` (already set per 2.8) aren't even required unless you later want to embed this dashboard's data back into an n8n alert.

## Suggested layout

```
┌─────────────────────────────────────────────────────┐
│  [Bonus] Pending: 3   Dispatched: 1   Done: 214  Failed: 2  │
├───────────────────────────┬───────────────────────────┤
│  Oldest Pending Age        │  Counts by Type/Status    │
│  (Number, big)             │  (Pivot table)            │
├───────────────────────────┴───────────────────────────┤
│  Failed Events (Table, newest first)                    │
└─────────────────────────────────────────────────────┘
```

## Known Limitations

- **No alerting wired here** — this is a passive dashboard, someone has to look at it. If Nivy wants a push alert (e.g. Odoo Discuss ping when `failed` count > 0, or oldest-pending age exceeds N minutes), that would be a small new n8n workflow polling this same table — not in scope for S7.3 as written, but a natural follow-on once S0–S2 are live. Say the word and I'll build it.
- **Chart types above are suggestions** — Metabase auto-suggests a viz per query shape; the table above is what I'd pick, but swap freely.
- Dashboard is **read-only intelligence** — it doesn't retry failed events or requeue anything. Retry logic lives in the Hub-Dispatcher's own error handling (plan §0.2, point 3), not here.
