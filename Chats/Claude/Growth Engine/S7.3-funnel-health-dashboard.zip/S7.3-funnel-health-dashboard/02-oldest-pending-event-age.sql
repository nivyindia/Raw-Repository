-- Panel 2a: Oldest pending event age (single "Number" card)
-- Metabase viz: "Number" -- this is the headline health metric for the dashboard.
-- If this number is high, the Hub-Dispatcher's schedule poll is falling behind or stuck.

SELECT
  ROUND(EXTRACT(EPOCH FROM (now() - MIN(created_at))) / 60) AS oldest_pending_age_minutes
FROM funnel_events
WHERE status = 'pending';

-- ============================================================

-- Panel 2b (optional drill-down): full pending queue, oldest first
-- Metabase viz: "Table" -- link this from the Panel 2a number card so
-- clicking the headline metric shows exactly which events are stuck.
-- Uses idx_funnel_events_pending (status, created_at) from the plan's §0.1 DDL, so this stays fast even as the table grows.

SELECT
  id,
  event_type,
  source_module,
  client_id,
  odoo_lead_id,
  created_at,
  ROUND(EXTRACT(EPOCH FROM (now() - created_at)) / 60) AS age_minutes
FROM funnel_events
WHERE status = 'pending'
ORDER BY created_at ASC;
