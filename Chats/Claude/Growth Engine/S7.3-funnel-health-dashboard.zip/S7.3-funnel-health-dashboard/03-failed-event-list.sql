-- Panel 3: Failed-event list
-- Metabase viz: "Table" -- most recent failures first, so whoever's on
-- funnel-health duty sees new failures at the top without re-sorting.
-- error_message comes from the Hub-Dispatcher's error handling (plan §0.2,
-- point 3) -- every spoke's routing failure lands here in one place.

SELECT
  id,
  event_type,
  source_module,
  client_id,
  odoo_lead_id,
  error_message,
  created_at,
  dispatched_at
FROM funnel_events
WHERE status = 'failed'
ORDER BY created_at DESC;
