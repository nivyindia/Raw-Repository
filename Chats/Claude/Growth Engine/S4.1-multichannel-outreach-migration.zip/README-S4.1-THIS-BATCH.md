# S4.1 — Migrate 2.1 Multichannel Outreach (this batch)

## Scope

Plan step **S4.1** only:

> 2.1 Multichannel Outreach: add "Report to Hub" on reply-received path →
> `event_type: lead.replied` (currently this loops back into nurture logic
> inline — decide in S0.3 whether that stays inline or also routes through
> the Hub; recommend keeping same-module internal loops inline, only
> cross-module hops go through the Hub).

Nothing else in S4 (2.3–2.9) was touched — those are separate steps, still open.

## What changed in `2.1-multichannel-outreach/workflow.json`

- **`Mark Lead as Replied` (Postgres node):** query's `RETURNING` clause
  extended from `odoo_lead_id, name` to `id, odoo_lead_id, name` — the Hub
  payload needs `client_id` (`clients_master.id`), which wasn't previously
  selected anywhere on this webhook-triggered branch.
- **New node `Report to Hub`** (`n8n-nodes-base.executeWorkflow`, same
  shape as 1.3/1.4's Report to Hub nodes from the S0-S3 batch): fires
  `event_type: lead.replied`, `source_module: 2.1`, `client_id`,
  `odoo_lead_id`, and `payload: { name }`.
- **Wiring:** `Mark Lead as Replied` now fans out to **both**
  `Odoo Discuss - Notify Reply` (unchanged) and `Report to Hub`, in
  parallel — same pattern as 1.4's S3.2 change, so the new Hub report
  doesn't sit in front of or delay the existing Postal webhook response.

The outbound-message half of this workflow (Fetch Lead Detail → Ollama →
Send Email/WhatsApp/LinkedIn → Update clients_master (Contacted)) is
untouched — S4.1 only concerns the *reply-received* path, per the plan.

**Nurture-loop decision (per S0.3 note above):** no inline nurture-loop
logic currently exists in this workflow to route through the Hub — the
reply path only marks the lead and alerts Odoo Discuss, it doesn't loop
back into anything internally. So there's nothing to "keep inline" yet;
noting this here in case a future nurture step gets added to this module.

## What's NOT done (by design — S4.1 is one step of S4)

- `2.1` still has no `Execute Workflow Trigger` input for the
  *outbound* side — the plan doesn't ask for one at S4.1 (2.1 is already
  called directly today and Hub-Dispatcher's `lead.qualified` branch
  already points at it from the S0–S3 batch's Hub-Dispatcher build).
- `lead.replied` is **not** wired into Hub-Dispatcher's `Switch` node —
  per `S0-EVENT-TYPE-TAXONOMY.md`, nothing currently subscribes to it, so
  it correctly falls through to `flagged_events` (same treatment as
  `lead.captured`). Add a Dispatcher branch later if/when a consumer
  module needs to react to replies.
- S4.2–S4.9 (2.3, 2.4, 2.5, 2.6, 2.7, 2.8, 2.9, end-to-end test) — still
  open. Say the word for the next batch.

## Files in this delivery

- `growth-engine-automation/phase-2/2.1-multichannel-outreach/workflow.json`
  — the updated workflow (S4.1)
- `docs/S0-EVENT-TYPE-TAXONOMY.md` — updated to mark `lead.replied` as
  reported (this batch) instead of planned

## Suggested test

1. Import the updated `2.1` workflow, fill in the real `Hub-Intake`
   workflow ID on the new `Report to Hub` node (same
   `REPLACE_WITH_0.0_HUB_INTAKE_WORKFLOW_ID` placeholder convention as
   every other spoke).
2. Trigger the Postal inbound webhook with a test reply.
3. Confirm `Mark Lead as Replied` still updates `clients_master` as before,
   the Odoo Discuss alert still fires, **and** a new row lands in
   `funnel_events` with `event_type = 'lead.replied'`, `source_module = '2.1'`.
