# S0.2 / S0.3 — `event_type` Taxonomy (living reference)

One row per cross-module hand-off, current or planned. "Wired" = a Hub-Dispatcher
Switch branch actually exists for it as of this batch. Everything else falls
through to `flagged_events` + the Odoo Discuss alert (S2.4) until it's built.

| event_type | Reported by | Consumed by | Wired in Dispatcher? |
|---|---|---|---|
| `lead.captured` | 1.3 (new, this batch) | *(nothing subscribes yet — logged for traceability)* | No — falls to flagged_events, harmless (informational event, no action expected) |
| `lead.qualified` | 1.4, 1.5 | 2.1 Outreach | **Yes** |
| `lead.booked` | 1.5 | 2.4 Proposal Generation | **Yes** |
| `proposal.ready` | 1.5 | 2.5 Contract E-sign | **Yes** |
| `client.won` | 1.5 | 2.7 Onboarding | **Yes** |
| `lead.replied` | 2.1 (**this batch, S4.1**) | *(nothing subscribes yet — logged for traceability, same as `lead.captured`)* | No — falls to flagged_events, harmless until a Phase 5 module needs it |
| `contract.signed` | 2.5 (planned, S4.4) | 2.6 Invoice Payment | No — S4 |
| `payment.received` | 2.6 (planned, S4.5) | 2.7 Onboarding | No — S4 |
| `client.onboarded` | 2.7 (planned, S4.6) | — | No — S4 |
| `renewal.due` / `payment.failed` | 2.8/2.9 (planned, S4.7) | 6.x churn/win-back | No — S4 |
| `health.scored` | 6.1.1 (planned, S6.1) | 6.2.2, 6.4.1 | No — S6 |
| `reply.received` | 4.3.x (planned, S5.1) | 5.1.1 | No — S5 |
| `qualification.scored` / `qualification.written` | 5.1.1 / 5.1.2 (planned, S5.2/S5.3) | — | No — S5 |
| `deliverability.alert` | 7.1 (planned, S6.7) | — | No — S6 |
| `nps.promoter_flagged` | 6.6 (planned, S6.4) | 6.7, 6.8 | No — S6 |
| `advocate.flagged` | 6.9 (planned, S6.6) | — | No — S6 |
| `winback.escalated` | 6.5 (planned, S6.3) | — | No — S6 |

## Note on `lead.captured`

The plan's S0.2 minimum set didn't include this one, but S3.1 explicitly asks
1.3 to report `event_type: lead.captured` after `Insert into clients_master`.
It's wired into 1.3 and lands in `funnel_events` for traceability, but since
nothing currently needs to *react* to a raw capture (1.4 is triggered by its
own webhook, not by this event), it isn't given a Dispatcher branch yet — it'll
fall to `flagged_events` every time, which is expected, not a bug. If a future
module wants to react to raw captures, add its branch then; don't remove the
report from 1.3 in the meantime.

## Status

This is the **S4.1 snapshot** (Phase 1 complete + first Phase 2 spoke).
Update this table each time S4/S5/S6 wire a new branch — this doc is the
"one place" the whole plan is designed around, so it needs to stay current or
it becomes exactly the kind of stale doc the audit kept finding.
