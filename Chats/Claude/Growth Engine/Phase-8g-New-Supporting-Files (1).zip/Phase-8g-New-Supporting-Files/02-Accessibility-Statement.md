# Accessibility Statement
*Site-wide — link from footer of all 6 Phase 8 landing pages.*

`last_updated: {{last_updated_date}}`

## 1. Our commitment
**{{legal_entity_name}}** is committed to making its contest, referral, free-audit, UGC showcase, and community pages accessible to the widest possible audience, including people with disabilities, in line with:
- **WCAG 2.1 Level AA** (Web Content Accessibility Guidelines) as the technical standard;
- the **European Accessibility Act** (Directive (EU) 2019/882, in force since 28 June 2025) for EU/EEA visitors;
- **EN 301 549** (the EU's harmonized accessibility standard);
- general good-practice alignment with the US ADA/Section 508 approach and the UK Equality Act 2010.

## 2. Conformance status
Target conformance level: **WCAG 2.1 AA**.
Current status: `{{conformance_status}}` — e.g. "partially conformant, full audit scheduled before public launch" or "fully conformant as of [date] per third-party audit."

> This statement describes the accessibility *target and process*. The actual conformance level must be confirmed through a real automated + manual audit before it is published as a factual claim — see Section 5 of the completion plan (legal/compliance review).

## 3. Measures taken
- Semantic HTML structure on all form pages (contest entry, referral, audit request, UGC submission, community signup).
- Keyboard-navigable forms and buttons.
- Sufficient color contrast for text and interactive elements.
- Alt text on all meaningful images (winner badges, prize graphics, UGC thumbnails).
- Form fields with associated labels and clear error messaging.

## 4. Known limitations
`{{known_limitations}}` — list any known gaps here (e.g., third-party embedded widgets, countdown timers not fully screen-reader announced) so visitors have an accurate picture, and update as issues are fixed.

## 5. Feedback and contact
If you encounter an accessibility barrier on any page, please contact us:
- Email: {{support_email}}
- WhatsApp: {{support_whatsapp}}

Please include the page URL and a description of the issue. We aim to respond within `{{accessibility_response_sla}}` (e.g., 5 business days) and to remediate confirmed issues within a reasonable timeframe.

## 6. Alternative access
If a specific form or tool (e.g., the free-audit request, contest entry) is inaccessible to you, contact us using the details above and we will offer an alternative method (e.g., manual submission via email or WhatsApp) so you are not excluded from participating.

---
*Drafted to an international best-practice baseline (WCAG 2.1 AA). Publishing this as a conformance claim without an actual audit is itself a compliance and reputational risk — treat Section 2's status line as a placeholder until real testing is done.*
