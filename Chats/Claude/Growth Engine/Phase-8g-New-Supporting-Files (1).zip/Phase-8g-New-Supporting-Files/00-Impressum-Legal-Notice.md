# Impressum / Legal Notice
*Applies site-wide — link this from the footer of all Phase 8 landing pages (contest entry, winner announcement, referral, free-audit, showcase, founders-circle, opt-out).*

`last_updated: {{last_updated_date}}`

## 1. Site operator
**{{legal_entity_name}}**
Registered address: `{{registered_address}}`
Country of registration: `{{country_of_registration}}`
Company registration / CIN number: `{{registration_number}}`
Tax / GST / VAT ID (where applicable): `{{tax_id}}`

## 2. Authorized representative
`{{authorized_representative_name}}`, `{{authorized_representative_title}}`

## 3. Contact
- General / support: {{support_email}}
- Privacy & data protection: {{privacy_contact_email}}
- WhatsApp: {{support_whatsapp}}

## 4. Regulatory / supervisory notes
This notice is provided to satisfy general commercial-website identification requirements in jurisdictions that require it (e.g., Germany/Austria §5 TMG-style "Impressum", EU e-Commerce Directive Art. 5 disclosure duties) and as good-practice transparency for all other visitors, regardless of jurisdiction.

This is an identity-disclosure notice only. It does not replace:
- the campaign-specific **Terms & Conditions / Official Rules** for any individual Phase 8 engine (8.1 Contest, 8.2 Referral, 8.3 Free-Audit, 8.4 UGC, 8.5 Community);
- the **Privacy Notice(s)** covering personal-data processing;
- the site-wide **Terms of Use** (`01-Website-Terms-of-Use.md`).

## 5. Dispute / liability notice
{{legal_entity_name}} makes reasonable efforts to keep the content of this website accurate and current but assumes no liability for the accuracy, completeness, or timeliness of the content. External links referenced from this site are the responsibility of their respective operators.

## 6. Content responsibility
Content on this domain and its campaign sub-pages is the responsibility of {{legal_entity_name}} unless a page explicitly states it was submitted by a third party (e.g., UGC submissions under the 8.4 engine, governed separately by `01-UGC-Submission-Terms.md`).

---
*Placeholders (`{{...}}`) must be filled with real, verifiable company details before this page goes live — an inaccurate Impressum is itself a compliance risk in jurisdictions where it is legally required.*
