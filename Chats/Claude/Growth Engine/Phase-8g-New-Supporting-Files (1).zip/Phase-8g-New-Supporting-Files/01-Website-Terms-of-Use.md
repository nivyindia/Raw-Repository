# Website Terms of Use
*Site-wide terms — governs use of all Phase 8 domains/landing pages generally. Campaign-specific rules (contest entry, referral, free-audit, UGC, community) sit on top of these as additional terms and take precedence for their specific engine where the two conflict.*

`last_updated: {{last_updated_date}}`

## 1. Acceptance
By accessing or using any page on this domain (including contest entry pages, referral pages, the free-audit tool, the UGC showcase, and the Founders Circle page), you agree to these Terms of Use. If you do not agree, do not use the site.

## 2. Who operates this site
See `00-Impressum-Legal-Notice.md` for full operator identity. Owned and operated by **{{legal_entity_name}}**.

## 3. Eligibility to use the site generally
The general site has no age restriction beyond the legal minimum age to enter into a binding agreement in your jurisdiction (typically 18, or the age of majority where you reside). Individual campaigns (e.g., the contest under the 8.1 engine) may set additional eligibility rules — see that campaign's Official Rules.

## 4. Intellectual property
- All site design, copy, logos, and branding are the property of {{legal_entity_name}} or its licensors, except content submitted by users under a specific license (see `01-UGC-Submission-Terms.md` for the 8.4 UGC engine).
- You may not copy, reproduce, or redistribute site content for commercial purposes without written permission.

## 5. User conduct
You agree not to:
- submit false or fraudulent information on any form (contest entry, referral, audit request, UGC submission, community signup);
- attempt to circumvent fraud-prevention or deduplication controls;
- use automated means (bots, scrapers) to submit entries or harvest data;
- upload content that is unlawful, infringing, defamatory, or that violates a third party's rights.

Violation may result in disqualification from any active campaign, removal of submitted content, and/or termination of access.

## 6. No warranty
The site, its tools (including the free-audit tool under the 8.3 engine), and their outputs are provided "as is" without warranties of any kind, express or implied, including accuracy, completeness, or fitness for a particular purpose. Free-audit scores and reports are automated estimates, not professional advice.

## 7. Limitation of liability
To the maximum extent permitted by applicable law, {{legal_entity_name}} is not liable for indirect, incidental, or consequential damages arising from use of this site. Nothing in these Terms limits liability that cannot be limited under applicable law (e.g., liability for fraud or for death/personal injury caused by negligence, where such limitations are unlawful).

## 8. Third-party links and channels
This site may link to or integrate with third-party channels (WhatsApp, Telegram, LinkedIn, Instagram/Facebook, email). Your use of those channels is also subject to that platform's own terms.

## 9. Changes
These Terms may be updated periodically. The `last_updated` date above reflects the most recent revision. Continued use of the site after an update constitutes acceptance of the revised Terms.

## 10. Governing law
Governing law and venue: `{{governing_law_jurisdiction}}` — to be confirmed by legal counsel based on the operating entity's registration and primary target markets (see `03-Country-Specific-Legal-Notes.md` for the six launch countries: US, UK, Canada, Australia, UAE, India).

## 11. Contact
{{support_email}} · {{privacy_contact_email}} for privacy-specific queries.

---
*This is a general-purpose Terms of Use template drafted to international best-practice baseline. Final governing-law clause and any jurisdiction-specific mandatory disclosures should be confirmed by legal counsel before go-live — see Section 5 of the completion plan.*
