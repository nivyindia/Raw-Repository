# Email & WhatsApp Communication Templates — Phase 8 (Contest / Referral / Audit / UGC / Community / Outreach)

*Har engine ke `noOp` "configure" node abhi tak sirf 1-line generic placeholder text use kar raha tha
(e.g. 8.1 ka Notify-Winner node: `"Congratulations! You won. Our team will reach out about your reward."`).
Ye file har touchpoint ka real, brand-ready copy deti hai — WhatsApp version short/casual, Email version
full HTML-ready with subject line. Sabhi `{{...}}` merge-fields hain, jo `contest_entries`/`referral_ledger`/
`audit_requests`/`ugc_submissions`/`community_members` table ke columns se aa sakte hain — n8n me Set node
se map karo.*

`last_updated: {{last_updated_date}}`

---

## 8.1 — Reward / Contest Engine

### 1. Entry confirmation (immediately after submit)
**WhatsApp:**
> Hi {{first_name}}! 🎉 Your entry for **{{campaign_name}}** is in — Entry ID `{{entry_id}}`.
> Category: {{category}}. Judging starts {{judging_start_date}}, winners announced {{winner_announcement_date}}.
> No action needed — we'll message you here with updates. Good luck!

**Email — Subject:** `Entry confirmed — {{campaign_name}} (ID {{entry_id}})`
> Hi {{first_name}},
>
> Thanks for entering **{{campaign_name}}**! Here's your confirmation:
>
> - Entry ID: **{{entry_id}}**
> - Category: {{category}}
> - Submitted: {{submitted_at}}
>
> **What happens next:**
> 1. Entries close {{entry_deadline}}
> 2. Judging: {{judging_start_date}} – {{judging_end_date}}
> 3. Winners announced: {{winner_announcement_date}}
>
> No further action is needed from you. Full rules: [{{official_rules_url}}]({{official_rules_url}})
>
> Good luck,
> The {{legal_entity_name}} Team

### 2. Reminder — deadline approaching (T-3 days, optional automation)
**WhatsApp:**
> ⏰ Reminder: **{{campaign_name}}** entries close in 3 days ({{entry_deadline}}). Haven't entered yet, or want to share with a friend? {{campaign_url}}

### 3. Winner notification (post human-approval)
**WhatsApp:**
> 🏆 Congratulations {{first_name}}! You've been selected as a winner in **{{category}}** for {{campaign_name}}!
> Your prize: {{prize_summary}}. Our team will email you within {{claim_window_days}} days with next steps to claim it. Reply here if you have questions.

**Email — Subject:** `🏆 You won — {{campaign_name}} ({{category}})`
> Hi {{first_name}},
>
> Congratulations — your business has been selected as a **{{category}}** winner in {{campaign_name}}!
>
> **Your prize:** {{prize_summary}} (Approx. Retail Value: {{arv_usd}})
>
> **To claim it:**
> 1. Reply to this email confirming your business/mailing details by {{claim_deadline}}.
> 2. Our team will schedule your onboarding call for the prize package.
> 3. You'll receive your digital winner badge and certificate within {{badge_delivery_days}} business days.
>
> Public announcement: your win will be featured at {{winner_page_url}} on {{public_announcement_date}} unless you opt out — reply if you'd prefer not to be listed publicly.
>
> Warm congratulations from all of us,
> The {{legal_entity_name}} Team

### 4. Non-winner (optional, good practice for goodwill/nurture)
**Email — Subject:** `Thank you for entering {{campaign_name}}`
> Hi {{first_name}},
>
> Thank you for entering {{campaign_name}} — this year's competition in {{category}} was closely contested.
> While your entry wasn't selected as a winner this round, we'd love to stay in touch: {{nurture_offer_cta}}.
>
> Watch for our next {{campaign_family_name}} round — follow {{social_handle}} for the announcement.
>
> Best,
> The {{legal_entity_name}} Team

---

## 8.2 — Referral Engine

### 1. Referral code issued (after manual/request flow — see Phase 8f patched page)
**WhatsApp:**
> Hi {{first_name}}! Here's your referral link: {{referral_link}}
> You earn {{meeting_booked_reward}} when someone you refer books a meeting, plus {{converted_reward_pct}} of their first invoice (up to {{converted_reward_cap}}) when they become a client. Share away!

**Email — Subject:** `Your referral link is ready`
> Hi {{first_name}},
>
> Your unique referral link: **{{referral_link}}**
>
> **How rewards work:**
> | Stage | Reward |
> |---|---|
> | They book a meeting | {{meeting_booked_reward}} |
> | They become a client | {{converted_reward_pct}} of first invoice (capped {{converted_reward_cap}}) |
>
> Full terms: {{referral_terms_url}}
>
> Thanks for spreading the word,
> The {{legal_entity_name}} Team

### 2. Reward earned — meeting booked
**WhatsApp:**
> 🎉 Good news {{first_name}}! Someone you referred just booked a meeting with us. Your reward of {{meeting_booked_reward}} is confirmed — payout details coming by email.

### 3. Reward earned — converted to client (final payout)
**Email — Subject:** `Your referral reward is confirmed — {{converted_reward_amount}}`
> Hi {{first_name}},
>
> Great news — {{referred_business_name}} is now a client, thanks to your referral! Your reward:
> **{{converted_reward_amount}}**
>
> Payout method: {{payout_method}}. Expect it within {{payout_processing_days}} business days.
>
> Thank you for trusting us with your network,
> The {{legal_entity_name}} Team

### 4. Referred friend — welcome (the person who was referred)
**WhatsApp:**
> Hi {{first_name}}! {{referrer_name}} thought you'd be a great fit for {{legal_entity_name}}. Thanks for booking time with us — talk soon!

---

## 8.3 — Free-Audit Engine

### 1. Report delivery
**Email — Subject:** `Your {{audit_type}} results are ready ({{score}}/100)`
> Hi {{first_name}},
>
> Your free {{audit_type}} for **{{input_url}}** is complete. Overall score: **{{score}}/100**.
>
> **Top 3 findings:**
> {{finding_1}}
> {{finding_2}}
> {{finding_3}}
>
> Full report attached / view online: {{report_url}}
>
> Want help fixing these? {{cta_book_call}}
>
> Best,
> The {{legal_entity_name}} Team

**WhatsApp (short notify, if requested via that channel):**
> Hi {{first_name}}! Your {{audit_type}} report for {{input_url}} is ready — scored {{score}}/100. Check your email or view here: {{report_url}}

---

## 8.4 — UGC / Share Engine

### 1. Submission received
**Email/WhatsApp:**
> Hi {{first_name}}, thanks for your submission to {{campaign_name}}! We'll review it within {{review_sla_days}} days. If approved, you'll earn {{points_range}} points — track your total here: {{leaderboard_url}}

### 2. Verified — points awarded
**WhatsApp:**
> ✅ Your submission was approved! You earned **{{points_awarded}} points** for {{campaign_name}}. Current total: {{total_points}}. See leaderboard: {{leaderboard_url}}

---

## 8.5 — Community Engine

### 1. Welcome message (Founders Circle / community join)
**Email — Subject:** `Welcome to {{community_name}}`
> Hi {{first_name}},
>
> Welcome to {{community_name}}! You now have access to:
> - {{benefit_1}}
> - {{benefit_2}}
> - {{benefit_3}}
>
> Community guidelines: {{guidelines_url}}
>
> Say hi in the group: {{community_link}}
>
> Glad to have you,
> The {{legal_entity_name}} Team

### 2. Drip content sample (weekly/periodic value-add)
**WhatsApp:**
> Hi {{first_name}} — this week in {{community_name}}: {{content_teaser}}. Full piece here: {{content_url}}

---

## 8.6 — Signal-Based Outreach Engine

*Highest legal exposure (CASL/CAN-SPAM/PECR) — every message below must include a working unsubscribe/opt-out, and must not be sent to Canada/UK/EU contacts without confirmed legal basis (see `01-Outbound-Compliance-Notes.md`).*

### 1. Initial outreach (signal-triggered)
**Email — Subject:** `Saw {{trigger_context}} — quick thought`
> Hi {{first_name}},
>
> Noticed {{trigger_context}} (e.g. "your team is hiring for growth roles") — congrats on the momentum.
>
> We help businesses like {{company_name}} with {{relevant_value_prop}}. Worth a quick 15-min chat?
>
> {{cta_book_call}}
>
> Best,
> {{sender_name}}, {{legal_entity_name}}
>
> ---
> Don't want future emails like this? [Unsubscribe]({{unsubscribe_url}})

### 2. Opt-out confirmation (matches `02-opt-out-confirmation-page.html`)
**Email — Subject:** `You've been unsubscribed`
> Hi {{first_name}},
>
> Confirming you've been removed from {{legal_entity_name}} outreach lists as of {{opt_out_date}}. You won't receive further messages like this.
>
> If this was a mistake, reply to this email or contact {{support_email}}.

---

## Notes for wiring into n8n

1. Har `noOp` "configure" node ke `text`/HTML body me is file ka corresponding template paste karo, merge-fields ko actual upstream node se map karo (e.g. `{{first_name}}` → `$json.entry_data.first_name`).
2. WhatsApp version har jagah **short** rakha hai (Waha/WhatsApp Business API ke character-limit-friendly), Email version **full context** ke saath — dono alag nodes honge agar multi-channel bhejna hai.
3. `{{legal_entity_name}}`, `{{support_email}}`, dates — same Category-B placeholders jo baaki files me hain, same find-replace pass isse bhi cover karega.
4. 8.6 ke templates **legal review ke baad hi activate karo** — already flagged in the main completion plan.
