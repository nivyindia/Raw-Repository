# S4.2 — 2.3 Booking Sync → Hub

Per the Star-Topology plan, S4.2 only:

> 2.3 Booking Sync: after `Postgres - Mark Booked`, add "Report to Hub" →
> `event_type: lead.booked` (this currently isn't called by anything upstream
> via Execute Workflow — it's webhook-triggered by Cal.com directly, which
> stays as-is; only its *outbound* hand-off changes).

## What changed in `2.3-booking-sync/workflow.json` (10 nodes → 11)

1. **`Postgres - Mark Booked`** — added `RETURNING id, odoo_lead_id, email` to
   the UPDATE query. It had no RETURNING before, so there was nothing for a
   new node to read off it. Same convention as 1.4's `Update clients_master
   with Score` node from the S3 batch.
2. **New node `Report to Hub`** (`n8n-nodes-base.executeWorkflow`) — calls
   Hub-Intake with:
   - `event_type: "lead.booked"`
   - `client_id`, `odoo_lead_id` — read straight off `Postgres - Mark
     Booked`'s own output (point 1 above)
   - `source_module: "2.3"`
   - `payload` — booking_uid, start_time, end_time, meeting_url, title, all
     pulled from `Normalize Cal.com Payload`'s output (same node the existing
     `Odoo Discuss - Booking Confirmed` node already reads from, so no new
     dependency introduced)
3. **Connection** — `Postgres - Mark Booked` now fans out to *both* `Odoo
   Discuss - Booking Confirmed` (existing) and `Report to Hub` (new), running
   in parallel. Nothing about the existing cancel path, webhook trigger, or
   Odoo calendar-event creation changed.

`workflowId` on the new node is the same
`REPLACE_WITH_0.0_HUB_INTAKE_WORKFLOW_ID` placeholder used in the S3 batch —
fill in once you've imported `0.0-hub-intake` and know its real workflow ID,
same as 1.3/1.4/1.5's Report to Hub nodes.

## What did NOT change (confirmed against the plan)

- Trigger stays `Cal.com Booking Webhook` — 2.3 is not being given an
  `Execute Workflow Trigger` input. The plan is explicit that 2.3 "isn't
  called by anything upstream via Execute Workflow" today, so there's no
  inbound side to wire — only the outbound `lead.booked` report is new.
- Cancel path (`IF Cancelled` → `Postgres - Revert to Nurture` → `Odoo
  Discuss - Booking Cancelled`) untouched — S4.2 only covers the booked path.
- README.md for the module carried over unchanged, same as 1.1/1.2 in the S3
  batch — no functional claim in it needed updating for this specific node
  addition.

## Known edge case (inherited, not introduced)

The module's own note on `Postgres - Mark Booked` already flags: if the
attendee's email doesn't match any row in `clients_master`, the UPDATE
matches zero rows and `RETURNING` comes back empty — `$json.id` is then
`undefined`/null. `Report to Hub` will still fire in that case and insert a
`funnel_events` row with `client_id: null`. That's not a new failure mode —
Hub-Dispatcher's `flagged_events` fallback (S2.4, already built) is exactly
what catches unmatched/incomplete events, so this needs no extra handling
here.

## Not in this batch

S4.1, S4.3–S4.8 (the other 8 Phase 2 modules) are still open per the plan —
say the word for the next piece.
