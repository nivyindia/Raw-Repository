# F6.1 — Support Ticketing Provider — ✅ CLOSED THIS BATCH

**Module affected:** `6.1.1-Account-Health-Snapshot-Rollup` (feeds `6.2.2-Milestone-Missed-Alert` and `6.4.1-Upsell-Crosssell-Trigger`, which both consume the health score this computes).

**Kya tha:** `MOCK_TICKETING_PROVIDER - Tickets Pull` node disabled tha, health score ticket-volume ke bina compute ho raha tha.

**Kaise close hua:** Nivy ka koi naya decision nahi liya — jo pehle se files me tha wahi follow kiya: `6.3.1-Support-Ticketing-Wiring` **already** Linear me tickets banata hai aur `clients_master.support_ticket_count` column khud maintain karta hai (har naye Linear ticket par +1). Ab `6.1.1` seedha yehi column read karta hai — koi naya API call, koi naya credential nahi chahiye, sirf ek already-real data source ko wire kiya.

**Kya badla** (`6.1.1-Account-Health-Snapshot-Rollup.json`, is batch me updated):
- `MOCK_TICKETING_PROVIDER - Tickets Pull` node **hata diya** (mock/disabled state se ab pura gone, kyunki real path ban gaya).
- `Get Active Accounts` query me `support_ticket_count` add kiya SELECT list me.
- `Merge Data Sources` ab 3 ki jagah 2 input combine karta hai (Last-Contact + Usage — ticket count ab seedha account row se aata hai, alag merge branch ki zaroorat nahi).
- `Health-Score Compute` ab `account.support_ticket_count` use karta hai (real), `ticket_data_source` field ab `'REAL - clients_master.support_ticket_count...'` bolta hai, `MOCK` wala caveat hata diya.
- `00-MASTER-MIGRATIONS.sql` me `support_ticket_count`, `health_score`, `health_score_snapshot_at` columns add kiye (pehle sirf inline `ALTER TABLE IF NOT EXISTS` mein the — ab master migration me bhi hain, taaki 6.1.1 pehli baar chale to bhi column already exist kare, chahe 6.3.1 abhi tak ek baar bhi na chala ho).

**Abhi bhi open (chhota, alag issue):** `Health-Score Compute` ke andar ke **scoring weights** (jaise `>60 din = -40 points`, `>3 tickets = -10 points`) abhi bhi placeholder hain — data source real ho gaya hai, lekin weightage ka business-rule confirmation abhi bhi Nivy se chahiye. Code me `health_score_methodology_status: 'PLACEHOLDER - needs business confirmation, not yet approved'` flag jaisa tha waisa hi rakha hai — ye is batch ka scope nahi tha.

---

## Other open items surfaced during the audit (for the same kind of sign-off, lower priority)

| Item | Module | What's needed |
|---|---|---|
| `referral_code_used` isn't populated by any workflow yet | 6.8 Referral Program | Needs a small patch in 1.3/1.4 to capture `?ref=<code>` from the inbound lead source. Say the word and I'll patch it. |
| `advocate_flag` isn't auto-set by any workflow yet | 6.9 Advocacy | Currently set manually after human review — tell me if you want an auto-set-on-approval step instead. |
| Slack vs. other tool for support tickets | 6.3.1 Support Ticketing Wiring | The workflow currently has a Slack trigger node wired in. If you're not using Slack for this, tell me which tool and I'll swap the trigger. |
