# S5.3 — 4.3.3 Reply Merge/Nurture Suppression → Hub (this batch)

Scope: only S5.3 from the plan. S5.1, S5.2, S5.4–S5.9 (the rest of Phase 4/5)
are still open.

## What changed in `4.3.3-Reply-Merge-Nurture-Suppression.json`

1. **New `Report to Hub` node**, inserted right after `Update clients_master
   (reply + suppress)` (before the existing `Done` no-op) →
   `event_type: reply.received`, `source_module: "4.3.3"`, `client_id` /
   `odoo_lead_id` from the update's own `RETURNING` clause, `payload` with
   `channel` / `reply_content` / `occurred_at` / `workflow_source` /
   `active_sequence_suppressed`.
2. **`Update clients_master`'s `RETURNING` clause extended** to also return
   `odoo_lead_id` (it previously only returned `id, status,
   last_reply_channel, last_reply_at, active_sequence_suppressed`) — needed
   it for the Hub report, same field every other spoke's report includes.

## Why S5.1 and S5.2 weren't also done this batch

Checked 4.3.3's own README before starting: it explicitly says 4.3.1 (Waha)
and 4.3.2 (LinkedIn) are each supposed to be **rewired** to call 4.3.3
instead of writing `clients_master` directly — that rewiring is a listed
pending step in 4.3.3's own doc, separate from S5.3. Once it's applied,
4.3.3 becomes the single point all three reply channels funnel through, and
this batch's one `Report to Hub` node covers all of them. Adding two more
separate Hub-report nodes to 4.3.1/4.3.2 as well (a literal reading of
S5.1/S5.2) would double-report every reply once the rewiring lands. Checked
the actual `4.3.1-Waha-WhatsApp-Reply-Tracking.json` and
`4.3.2-LinkedIn-Reply-Check-Polling.json` files on disk — confirmed neither
has been rewired yet (both still end in their own direct `Postgres update`
node, no `Execute Workflow` call into 4.3.3). Recommend closing S5.1/S5.2 as
"satisfied by design" once the rewiring is done, rather than building them
as separate Hub-report nodes — flagging for a decision rather than deciding
silently.

## Gap found before starting (disk-checked)

The last three star-topology batches (S4.1, S4.3, S4.4) each shipped their
own copy of `docs/S0-EVENT-TYPE-TAXONOMY.md`, and the copies had already
diverged from each other — S4.3's copy has the `proposal.sent` row but not
S4.4's `contract.signed` row, and vice versa. This is exactly the kind of
stale/diverging doc the whole star-topology plan exists to prevent (per the
original audit's §1.1). Merged all three into one file this batch, plus
added this batch's `reply.received` row. Treat the copy in this zip as
current going forward.

**Bigger finding, not fixed in this batch:** while locating that taxonomy
doc, found that `S4.1-multichannel-outreach-migration.zip` and `s4.3.zip`
already exist on disk with 2.1 and 2.4 fully migrated to the Hub — but the
S7.5 batch's `DEPLOYMENT-GUIDE.md`/`README.md` update (delivered earlier)
labeled both as "⏳ Mesh (purana) — pending," which is now wrong. There's
also `s4.6.zip` and `S4.7-star-topology.zip` on disk that haven't been
checked at all yet — they may cover 2.7 and 2.8/2.9. **Recommend a
dedicated reconciliation session** that audits every `S4.*`/`s4.*` zip
against `DEPLOYMENT-GUIDE.md`'s Section 9.3 table and the top-level
`README.md`'s module table, and corrects both — separate task from S5.3,
flagging here so it doesn't get lost.

## Files in this delivery

- `4.3.3-Reply-Merge-Nurture-Suppression.json` — updated (see above)
- `4.3.3-README.md` — updated: new "Why only this file reports to the Hub"
  section, Hub-Intake ID wiring step, test-checklist item 6
- `docs/S0-EVENT-TYPE-TAXONOMY.md` — merged S4.1+S4.3+S4.4 copies, added
  `reply.received` row + note

## Suggested test

Manually trigger 4.3.3's entry node with a dummy
`{client_id: <test id>, channel: "whatsapp", reply_content: "test", occurred_at: "<now>", workflow_source: "test"}`
— confirm `communication_events` insert, `clients_master` update, and a new
`funnel_events` row with `event_type = 'reply.received'` all happen in one
run. Full live-traffic test waits until the 4.3.1/4.3.2 rewiring is applied.

## Still open

- S5.1, S5.2 (recommend "satisfied by design" per above, pending a decision)
- S5.4–S5.6 (Phase 5 qualification spokes), S5.7–S5.9 (Phase 4 outreach/dialer)
- The reconciliation pass flagged above (S4.1/s4.3/s4.6/S4.7 vs. the S7.5
  docs)
- 4.3.1/4.3.2 → 4.3.3 rewiring itself (pre-existing pending item, not part
  of the star-topology plan but blocks `reply.received` from firing live)

Say the word for any of these.
