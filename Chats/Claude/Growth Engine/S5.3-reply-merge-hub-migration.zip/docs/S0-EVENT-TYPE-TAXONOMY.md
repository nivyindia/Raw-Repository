# S0.2 / S0.3 — `event_type` Taxonomy (living reference)

One row per cross-module hand-off, current or planned. "Wired" = a Hub-Dispatcher
Switch branch actually exists for it as of this batch. Everything else falls
through to `flagged_events` + the Odoo Discuss alert (S2.4) until it's built.

> **S5.3 note on this file:** the last few batches (S4.1, S4.3, S4.4) each shipped their own copy of this doc, and the copies had already started to diverge — exactly the staleness problem this file exists to prevent. This version merges all of them (S4.1's `lead.replied` row, S4.3's `proposal.sent` row, S4.4's `contract.signed` row) plus this batch's `reply.received` update. **Treat this merged copy as the current one going forward** — see the batch README for the reconciliation flag.

| event_type | Reported by | Consumed by | Wired in Dispatcher? |
|---|---|---|---|
| `lead.captured` | 1.3 | *(nothing subscribes yet — logged for traceability)* | No — falls to flagged_events, harmless (informational event, no action expected) |
| `lead.qualified` | 1.4, 1.5 | 2.1 Outreach | **Yes** |
| `lead.booked` | 1.5 | 2.4 Proposal Generation | **Yes** |
| `proposal.ready` | 1.5 | 2.5 Contract E-sign | **Yes** |
| `client.won` | 1.5 | 2.7 Onboarding | **Yes** |
| `lead.replied` | 2.1 (built, S4.1) | *(nothing subscribes yet — logged for traceability, same as `lead.captured`)* | No — falls to flagged_events, harmless until a Phase 5 module needs it |
| `proposal.sent` | 2.4 (built, S4.3) | *(nothing subscribes yet — logged for traceability; 2.5 still starts from its own Proposal Accept Webhook, not this event)* | No — falls to flagged_events, harmless (informational event, same pattern as `lead.captured`) |
| `contract.signed` | 2.5 (built, S4.4) | 2.6 Invoice Payment | No — Dispatcher branch not wired yet, falls to flagged_events |
| `reply.received` | **4.3.3 (built, S5.3)** | 5.1.1 BANT/MEDDIC Extraction (planned, S5.4) | No — S5, falls to flagged_events. **Not live yet even on the reporting side**: 4.3.1/4.3.2 haven't been rewired to call 4.3.3 (see 4.3.3's own README), so this event only fires from a manual/test call for now |
| `payment.received` | 2.6 (planned, S4.5) | 2.7 Onboarding | No — S4 |
| `client.onboarded` | 2.7 (planned, S4.6) | — | No — S4 |
| `renewal.due` / `payment.failed` | 2.8/2.9 (planned, S4.7) | 6.x churn/win-back | No — S4 |
| `health.scored` | 6.1.1 (planned, S6.1) | 6.2.2, 6.4.1 | No — S6 |
| `qualification.scored` / `qualification.written` | 5.1.1 / 5.1.2 (planned, S5.4/S5.5) | — | No — S5 |
| `deliverability.alert` | 7.1 (planned, S6.7) | — | No — S6 |
| `nps.promoter_flagged` | 6.6 (planned, S6.4) | 6.7, 6.8 | No — S6 |
| `advocate.flagged` | 6.9 (planned, S6.6) | — | No — S6 |
| `winback.escalated` | 6.5 (planned, S6.3) | — | No — S6 |

## Note on `lead.captured`

The plan's S0.2 minimum set didn't include this one, but S3.1 explicitly asks
1.3 to report `event_type: lead.captured` after `Insert into clients_master`.
It's wired into 1.3 and lands in `funnel_events` for traceability, but since
nothing currently needs to *react* to a raw capture (1.4 is triggered by its
own webhook, not by this event), it isn't given a Dispatcher branch yet — it'll
fall to `flagged_events` every time, which is expected, not a bug. If a future
module wants to react to raw captures, add its branch then; don't remove the
report from 1.3 in the meantime.

## Note on `lead.replied` (S4.1)

2.1 Multichannel Outreach reports `lead.replied` when a reply comes in on its
own channels. Nothing subscribes yet — reported for traceability, same
pattern as `lead.captured`. Worth checking against `reply.received` (S5.3,
below) once Phase 5 is being wired: there may be two separate "someone
replied" events in the taxonomy (one from 2.1's own outreach threads, one
from the unified 4.3.x channel-merge) — decide at S5.4/S5.5 time whether
5.1.1 BANT/MEDDIC Extraction should subscribe to one, the other, or both.

## Note on `proposal.sent` (S4.3)

2.4 Proposal Generation is no longer called directly — its trigger
(`From Hub-Dispatcher (lead.booked)`) now accepts the same input shape as
Hub-Intake's own trigger, and Hub-Dispatcher calls it off the already-wired
`lead.booked` branch (this branch existed since S2, built ahead of the
receiving end). After it marks a proposal sent, it reports `proposal.sent` to
the Hub, same pattern as `lead.captured` from S3.1: nothing consumes it yet
because 2.5 Contract E-sign is triggered by its own `Proposal Accept Webhook`
(client action), not by this event. It's still reported for traceability —
if a future module needs to react to "a proposal went out" (e.g. a
follow-up-nudge module), wire a Dispatcher branch then; don't remove the
report from 2.4 in the meantime.

## Note on `contract.signed` (S4.4)

2.5 Contract E-Sign now reports `contract.signed` to the Hub instead of
calling 2.6 directly (`Execute Workflow - 2.6 Invoice + Payment` removed).
This is spoke-side only — Hub-Dispatcher's Switch node does **not** have a
`contract.signed` branch yet (that's the rest of S4, not built in this
step). Until that branch + 2.6's real workflow ID are added to the
Dispatcher, every `contract.signed` event lands in `funnel_events` and then
falls through to `flagged_events`, same as any other unwired event type —
invoices just need triggering manually until then, nothing breaks.

## Note on `reply.received` (S5.3)

The plan's S5a batch lists this as three separate steps (S5.1 on 4.3.1,
S5.2 on 4.3.2, S5.3 on 4.3.3). Only S5.3 was built this batch, and by
design it's meant to be the **only** reporter: 4.3.1 and 4.3.2 are supposed
to be rewired to call 4.3.3 instead of writing `clients_master` themselves
(per 4.3.3's own README), at which point 4.3.3 becomes the single merge
point for all three reply channels and one `Report to Hub` node covers all
of them. That rewiring hasn't happened yet, so as of this batch
`reply.received` doesn't fire from real traffic yet — see 4.3.3-README.md
for the exact pending step. Recommend treating S5.1/S5.2 as satisfied by
this design once the rewiring lands, rather than adding two more separate
Hub-report nodes to 4.3.1/4.3.2 (which would double-report every reply).

## Status

S3 (Phase 1) + S4.1 (2.1) + S4.3 (2.4) + S4.4 (2.5) + S5.3 (4.3.3) snapshot,
merged from previously-diverging per-batch copies. Still open: S4.2 already
shipped (2.3, no taxonomy change), S4.5–S4.7 (2.6/2.7/2.8/2.9), S5.4–S5.9
(rest of Phase 4/5), S6 (Phase 6/7), S7 (cutover + docs). **Recommend a
dedicated reconciliation pass** across the individual-workflow zips
(`S4.1-*`, `s4.3.zip`, `S4.4-*`, `s4.6.zip`, `S4.7-*` all exist on disk and
weren't all accounted for in the last DEPLOYMENT-GUIDE.md/README.md update —
flagging so the "one place" doesn't quietly go stale again).
