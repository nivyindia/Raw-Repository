# UGC / Share Program — Submission Terms & Content License
**[TEMPLATE — 8.4 UGC/Share Engine. `campaign_slug: nivy-showcase-2026`]**

*Last updated: {{last_updated_date}} · Version 1.0*

## 1. Overview
The Nivy Next Showcase program rewards clients and community members ("Contributors") for publicly sharing proof of results, testimonials, reels/posts, or screenshots ("Submissions") related to Nivy Next / Nivy Advisory / Nivy Academy work, tagging or mentioning Nivy Next.

## 2. Who can participate
Any current or past Nivy Next client, Nivy Academy alumni, or community member, aged 18+, in any country Nivy Next operates in. One Submission counted per post/platform per week unless the campaign's Official Rules state otherwise.

## 3. What counts as a valid Submission
- A public post (Instagram/LinkedIn/X/TikTok/YouTube/Google review) that visibly mentions or tags Nivy Next / the relevant brand, **or**
- A results screenshot (e.g., traffic, revenue, ranking improvement) submitted via the Showcase form, with reasonable supporting detail, **or**
- A written testimonial of at least 50 words submitted via the form.

Submissions must reflect **genuine, personal experience** — not compensated third-party content, stock imagery, or content copied from elsewhere.

## 4. Verification & Points
1. Every Submission is reviewed — automated checks first (proof-URL validity, duplicate detection, basic authenticity heuristics), then human verification before points are confirmed.
2. `verification_status` moves from `pending` → `verified` (points awarded) or `rejected` (with reason, where feasible).
3. **No Submission is auto-approved** — this mirrors the human-approval-gate pattern used across every Growth Engine module.

### Points table (edit freely per campaign)
| Submission type | Points |
|---|---|
| Social post/reel with tag | 50 |
| Written testimonial (50+ words) | 30 |
| Results screenshot with data | 40 |
| Video testimonial (30s+) | 100 |

Points accumulate on a public leaderboard (opt-in) and can be redeemed per the active campaign's `config.redemption` rules (e.g., points → service credit, points → entry boost into an active 8.1 contest, or points → Founders Circle community access tiers under 8.5).

## 5. Content License
By submitting, you grant Nivy Next a **non-exclusive, royalty-free, worldwide, perpetual license** to use, reproduce, adapt (e.g., crop/caption), and display your Submission — including your name, business name, and likeness where included — across Nivy Next's website, social channels, sales/marketing materials, and press, for the purpose of promoting Nivy Next's services. You retain ownership of your original content; this license does not transfer copyright.

You may request removal of your Submission from **future** use at any time by emailing {{support_email}} — this does not retract materials already published/printed prior to the request.

## 6. What's excluded
Nivy Next will not accept or will remove Submissions that: contain another party's confidential business data without consent, make claims Nivy Next cannot verify (e.g., specific revenue figures without supporting evidence), or violate the platform's own terms (e.g., fake engagement, purchased followers).

## 7. No purchase necessary
Participation is free. This is a recognition/rewards program, not a lottery — points/rewards are earned through genuine content contribution, not chance.

## 8. Governing terms
Also subject to the general Privacy Notice (`../8.1-Contest-Engine/03-Privacy-Notice-Contest-Data.md`).

## 9. Contact
{{support_email}} · {{support_whatsapp}}
