# Signal-Based Outreach — Compliance Notes & Opt-Out Policy
**[TEMPLATE — 8.6 Signal-Based Outreach Engine. Not campaign-scoped; applies to all automated outbound triggered by `signal_leads`.]**

*Last updated: {{last_updated_date}}*

## 1. What this engine does
8.6 monitors external signals (hiring activity, funding news, press mentions) and internal signals (reactivation triggers from `winback.escalated`), AI-scores them, and queues automated outreach sequences to prospects who have **not** previously opted in as clients or entrants elsewhere in the Growth Engine.

This is **cold outbound**, unlike every other Phase 8 engine (8.1–8.5), which is inbound/opt-in. It carries different, stricter compliance obligations.

## 2. Applicable law by channel

| Channel | Key law | Core requirement |
|---|---|---|
| Email (US) | CAN-SPAM Act | Accurate sender/subject, physical postal address, working unsubscribe honored within 10 business days |
| Email (Canada) | CASL | **Consent required before sending** commercial email in most cases — implied consent narrow exceptions only (existing business relationship, publicly published business email tied to role); express consent safest |
| Email (UK/EU) | PECR / GDPR | Similar to CASL — B2B "soft opt-in" exists in limited form, but unsolicited B2C email needs consent |
| Email (Australia) | Spam Act 2003 | Consent + clear unsubscribe + accurate sender identification |
| Email (UAE) | TDRA anti-spam regulations | Consent-based, unsubscribe required |
| WhatsApp / Telegram outreach | Platform ToS + local law | WhatsApp Business API prohibits unsolicited bulk messaging outside approved template categories — do not use for cold first-touch |
| LinkedIn outreach | Platform ToS | Automated connection/message requests at scale violate LinkedIn's terms — any 8.6 LinkedIn signal action should route to a **human** for manual send, not full automation |

## 3. Recommended safe design for 8.6
- **Email only** for the fully-automated first touch — lowest cross-jurisdiction risk when unsubscribe is honored immediately and sender identity is accurate.
- Treat **Canada, UK, and EU signal leads with extra caution** — CASL/PECR are stricter than CAN-SPAM. Consider requiring a documented "existing business relationship" or public professional-context match before auto-sending to these regions, or route them to a human-reviewed queue instead of full automation.
- **WhatsApp/Telegram/LinkedIn**: do not use for cold first-touch under 8.6. These channels remain opt-in only (used elsewhere in Phase 8 once a lead has engaged).
- Every outbound email must include: sender's real identity, {{legal_entity_name}} postal address, and a one-click unsubscribe link.
- Maintain a **suppression list** — anyone who unsubscribes or replies "STOP" must never receive another 8.6-triggered message, enforced at the `signal_leads.outreach_status` level (`ignored`/opted-out) and cross-checked against `clients_master`.

## 4. Unsubscribe / opt-out handling
- Unsubscribe requests must be honored within the timeframe required by the strictest applicable law among the channels used (practically: **immediately**, no more than a few days).
- One-click unsubscribe, no login or "tell us why" gate required before processing the opt-out itself (a feedback field is fine only if it doesn't block the opt-out).
- Provide the standalone opt-out confirmation page (`02-opt-out-confirmation-page.html`) as the unsubscribe link's landing destination.

## 5. Data retention for signal leads
`signal_leads` rows for leads who never respond and are never converted should be purged or anonymized after **12 months** of inactivity, consistent with data-minimization principles under GDPR/UK GDPR for any EU/UK-linked signal data.

## 6. Contact
{{support_email}} — for anyone contacted who wants to raise a compliance concern.

---
> ⚠️ This is the highest legal-risk engine in Phase 8 because it's the only non-opt-in one. Recommend a compliance/legal review before activating 8.6 in Canada/UK/EU specifically — CASL and PECR enforcement has real financial penalties (CASL fines up to CAD 10M for organizations).
