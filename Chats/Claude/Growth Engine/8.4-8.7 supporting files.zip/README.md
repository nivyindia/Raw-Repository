# Phase 8b — Supporting Files (Contest / Referral / Free-Audit)

Ye package **8.1, 8.2, 8.3 engines ke non-workflow.json supporting files** hain — T&C, official contest rules, privacy notice, country-specific legal notes, landing pages, aur SQL seed data. `01-PHASE-8-MIGRATIONS.sql` (aapne pehle diya) already `campaigns` + engine tables banata hai; ye package uske upar 3 real-looking sample campaigns aur unke legal/web assets add karta hai.

Sab prize amounts, dates, categories, reward tiers **international-level pe khud se placeholder-realistic bana diye hain** — koi bhi number, date, ya clause edit karna ho to seedha markdown/HTML/SQL file me kar sakte ho, sab `{{...}}` ya "REPLACE_" marked hai jahan real value daalni hai.

## Folder structure

```
├── README.md                                  ← ye file
├── 02-CAMPAIGN-SEED-DATA.sql                   ← 4 sample campaigns.rows (contest, referral x2, audit)
├── 03-Country-Specific-Legal-Notes.md          ← US/UK/CA/AU/AE/IN promo-law cheat sheet
│
├── 8.1-Contest-Engine/
│   ├── 01-Terms-and-Conditions.md              ← reusable master T&C, every future contest links here
│   ├── 02-Official-Contest-Rules-nivy-top-100-2026.md  ← full rules for the flagship "Top 100" contest
│   ├── 03-Privacy-Notice-Contest-Data.md       ← shared privacy notice (used by 8.1, 8.2, 8.3 all)
│   ├── 04-landing-page-contest-entry.html      ← live entry form + countdown, campaign-aware (?c= slug)
│   └── 05-winner-announcement-page.html        ← winners showcase page template
│
├── 8.2-Referral-Engine/
│   ├── 01-Referral-Program-Terms.md            ← Refer & Earn program terms + tier table
│   └── 02-landing-page-referral.html           ← referral link generator landing page
│
├── 8.3-Free-Audit-Engine/
│   ├── 01-Free-Audit-Terms.md                  ← lightweight ToS for the free-audit lead magnet
│   └── 02-landing-page-free-audit.html         ← audit request form
│
├── 8.4-UGC-Engine/
│   ├── 01-UGC-Submission-Terms.md              ← content license + points table
│   └── 02-landing-page-showcase.html           ← submission form + leaderboard
│
├── 8.5-Community-Engine/
│   ├── 01-Community-Guidelines-Partner-Terms.md ← code of conduct + partner terms
│   └── 02-landing-page-founders-circle.html    ← invite-request form
│
└── 8.6-Signal-Outreach-Engine/
    ├── 01-Outbound-Compliance-Notes.md         ← CAN-SPAM/CASL/PECR/Spam-Act cheat sheet
    └── 02-opt-out-confirmation-page.html       ← unsubscribe landing page
```

## The 3 sample campaigns (matching plan Section 3.3: 1 contest + 1 referral + 1 audit)

| Campaign | Engine | Type | Prize/reward (placeholder, USD) |
|---|---|---|---|
| `nivy-top-100-2026` | 8.1 | Merit-judged contest, 100 winners / 10 categories | ≈$4,150 in services per winner (no cash) |
| `refer-and-earn-global` | 8.2 | Evergreen referral | $50 meeting-booked + 10% of first invoice (capped $1,000) |
| `diwali-referral-2026` | 8.2 | Time-boxed referral boost, same engine, parallel to the evergreen one | $100 meeting-booked (2x) + same 10% stage 2 |
| `free-global-audit` | 8.3 | Free lead-magnet audit | N/A — no prize, lead capture only |
| `nivy-showcase-2026` | 8.4 | UGC/testimonial points program | 30–100 pts per submission → service credit / contest boost |
| `founders-circle-global` | 8.5 | Invite-only community | N/A — membership, not a reward |
| *(none — 8.6 not campaign-scoped)* | 8.6 | Continuous signal-based outreach | N/A — see compliance notes instead |

All campaign rows are inserted with `status = 'draft'` — nothing goes live until you run `UPDATE campaigns SET status = 'active' WHERE campaign_slug = '...'`.

## Why prizes are services, not cash
Deliberate design choice, explained in `03-Country-Specific-Legal-Notes.md`: cash/chance-based prizes trigger sweepstakes registration in several target markets (NY/FL/RI in the US, Quebec in Canada, UAE trade-promotion permits). Service-based prizes (marketing packages, features, badges) sit in a much lower-risk category and were used throughout — swap to cash only after checking that section.

## What's genuinely legal-review-required vs. safe to edit freely
- **Safe to edit without legal re-review:** prize amounts/components, dates, categories, copy/wording, reward tier percentages, branding/colors on the landing pages.
- **Should get a lawyer's eyes before going live:** anything that introduces a **random-draw/chance element**, a **paid-entry** requirement, or **cash prizes above ~$5,000 equivalent** — see the per-country notes.

## Wiring into n8n
Each landing page has a `WEBHOOK_URL` placeholder at the bottom of its `<script>` block — point it at the corresponding Hub-Intake-connected n8n webhook once each engine's `workflow.json` is imported (8.1/8.2/8.3 already built per the plan; 8.4/8.5 workflows are the "❌ Not built yet" items from Section 1 of the Implementation Plan — these supporting files are ready ahead of that build so nothing blocks on them).

## 8.6 is different from the rest
8.6 (Signal-Based Outreach) is the only **non-opt-in / cold outbound** engine in Phase 8, so it carries real legal exposure (CASL in Canada especially — fines up to CAD 10M) that the other five don't. It gets a compliance-notes doc instead of a T&C/entry page, plus a standalone unsubscribe confirmation page for its outbound emails. Recommend this gets legal review before it's ever turned on for Canada/UK/EU signal leads specifically.

## Suggested next step
Run `01-PHASE-8-MIGRATIONS.sql` → then `02-CAMPAIGN-SEED-DATA.sql` → review/edit all campaign configs and the T&C/rules/guidelines docs → wire webhook URLs once each engine's workflow is imported → flip `status` to `active` on the 2-3 you want to launch first (per Section 3.3 of the Implementation Plan, don't launch all six at once).
