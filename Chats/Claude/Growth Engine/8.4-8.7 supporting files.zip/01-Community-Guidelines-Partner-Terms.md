# Nivy Founders Circle — Community Guidelines & Partner Terms
**[TEMPLATE — 8.5 Community Engine. `campaign_slug: founders-circle-global`]**

*Last updated: {{last_updated_date}} · Version 1.0*

## Part A — Community Guidelines (for members)

### 1. What this is
The **Nivy Founders Circle** is a private community (WhatsApp/Telegram group + periodic virtual events) for Nivy Next clients, contest winners, top referrers, and approved partners to connect, share resources, and get early access to Nivy Next content and offers.

### 2. Membership
- Free for: active Nivy Next/Advisory/Academy clients, verified contest winners (8.1), referrers who've completed 3+ successful referrals (8.2), and top UGC contributors (8.4).
- Membership is **at Nivy Next's discretion** and can be revoked for violations of these guidelines.
- Roles: `member` (default), `moderator` (appointed community lead), `partner` (approved agency/vendor with expanded posting rights — see Part B).

### 3. Code of conduct
Members agree to:
- Keep discussion relevant to business growth, marketing, and mutual support — no unrelated spam.
- No unsolicited selling/promotion of unrelated products or services without moderator approval.
- Respect confidentiality — do not share other members' business details, numbers, or private conversations outside the group without consent.
- No harassment, discrimination, or abusive behavior of any kind. Zero tolerance — immediate removal.
- Self-promotion of your **own** business/wins is welcome and encouraged (this is a big part of the point) but keep it proportionate.

### 4. Moderation
Moderators may remove content or members that violate these guidelines. Decisions can be appealed by emailing {{support_email}}; Nivy Next's final decision stands.

### 5. Data
Membership data (`community_members`) tracks join date and role only — group chat content itself lives on the messaging platform (WhatsApp/Telegram) under that platform's own terms and is not separately stored by Nivy Next beyond what's needed for moderation.

### 6. Leaving
Members may leave at any time by exiting the group or emailing {{support_email}}. No penalty for leaving.

---

## Part B — Partner / Agency-to-Agency Terms (for `role = 'partner'`)

### 7. Who this applies to
Approved marketing agencies, freelancers, or complementary service providers (e.g., web developers, accountants outside Nivy Advisory's direct competition set) invited into the Circle as **Partners** for cross-referral and collaboration purposes.

### 8. Partner expectations
- Partners may share relevant resources, job/collaboration opportunities, and their own case studies.
- Partners referring clients to Nivy Next are covered under the standard Referral Program Terms (`../8.2-Referral-Engine/01-Referral-Program-Terms.md`), Partner tier.
- Partners must disclose any conflict of interest (e.g., competing directly for the same client) before engaging with another member's opportunity.
- Nivy Next does not vet or guarantee the work of any Partner — introductions made within the Circle are at each member's own risk and diligence.

### 9. Removal
Partner status (and associated referral tier) may be revoked at Nivy Next's discretion for conduct that damages trust within the community, independent of standard member removal grounds.

## 10. Contact
{{support_email}} · {{support_whatsapp}}
