# S4.6 — 2.7 Client Onboarding → Star Topology (this batch)

## Scope
Only step **S4.6** from `N8N-Star-Topology-Integration-Plan.md`. Not the rest
of S4 (2.1, 2.3, 2.4, 2.5, 2.6, 2.8, 2.9 are still on the old mesh — say the
word for those).

## What I found before editing
- Two copies of `2.7-client-onboarding/workflow.json` exist in your uploads
  (`Growth Engline-n8n-workflow` and `n8n - growth-engine-individual
  workflows`) — diffed them, byte-for-byte identical except a trailing
  workflow `id`. Used the first as the base; whichever copy you keep, drop
  this file into it.
- **0.0 Hub-Dispatcher already has `Execute Workflow - 2.7 Onboarding`
  wired on its `client.won` branch** (built during the S2 hub batch, ahead of
  need) — so the Dispatcher-calling-2.7 half of S4.6 was already done. Nothing
  to change on the Dispatcher side.
- 2.7 already had an `executeWorkflowTrigger` entry node (`From Module 2.6
  (Payment Received)`) — it was originally built for the old *direct* 2.6→2.7
  call. Renamed and re-noted rather than rebuilt, since the node type was
  already correct.

## What changed in `2.7-client-onboarding/workflow.json`
1. **Trigger node renamed**: `From Module 2.6 (Payment Received)` →
   `From Hub-Dispatcher (client.won)`, notes updated to reflect Dispatcher is
   now the caller. Input shape is unchanged (`{ odoo_lead_id, ... }`),
   because the Dispatcher passes the `funnel_events` row through unmapped.
2. **New `Report to Hub` node**, wired off `Postgres - Mark Onboarded` in
   parallel with the existing `Odoo Discuss - Onboarding Complete Alert` —
   same "don't block the existing notification" pattern used in 1.3 and 1.4.
   Reports `event_type: client.onboarded`, `source_module: 2.7`, payload
   `{ odoo_project_id, nextcloud_folder_url, odoo_discuss_channel_id }`.
3. **`settings.errorWorkflow` added** (`REPLACE_WITH_0.0_ERROR_HANDLER_WORKFLOW_ID`)
   — matching the convention every other migrated spoke (1.3, 1.4, 1.5) got in
   the S0–S3 batch. Not explicitly listed under the S4.6 line item, but
   flagging it since I added it for consistency rather than leaving 2.7 as
   the one migrated spoke without it.

## Data-quality / launch-readiness flags
- `REPLACE_WITH_0.0_HUB_INTAKE_WORKFLOW_ID` and
  `REPLACE_WITH_0.0_ERROR_HANDLER_WORKFLOW_ID` are still placeholders — same
  as every other spoke, fill in once real workflow IDs exist after import.
- `client.onboarded` is not consumed by anything downstream yet — that's
  expected, it's S6 (Phase 6) scope (health/renewal modules), not a bug here.
- Not tested against a live n8n instance — validated as well-formed JSON and
  correct node wiring only.

## Suggested test (mirrors S3.5's pattern)
Trigger `From Hub-Dispatcher (client.won)` manually with a dummy
`{ odoo_lead_id: <existing test lead> }` input, confirm the workflow runs
through to `Postgres - Mark Onboarded`, and that a `client.onboarded` row
lands in `funnel_events` via `Report to Hub`.
