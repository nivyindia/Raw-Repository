# Email & Message Template Library — Full Funnel

> Do parts: (A) already-existing templates in the KB — reference only, reuse
> as-is; (B) newly drafted templates for the gap modules (Phase 3/8/9) that
> don't yet have one. Same formatting rules as `16 Email Outreach/templates.md`:
> short (5–8 lines), one clear ask, subject <50 chars.

---

## Part A — Already exist in KB (reuse, don't rewrite)

| Module | File | Covers |
|---|---|---|
| 16 Email Outreach | `Sales Funnel/16 Email Outreach/templates.md` | Cold email 3-step sequence |
| 17 LinkedIn Outreach | `.../17 LinkedIn Outreach/templates.md` | Connection + follow-up messages |
| 19 WhatsApp Outreach | `.../19 WhatsApp Outreach/templates.md` | WhatsApp opener + follow-up |
| 20 SMS Outreach | `.../20 SMS Outreach/templates.md` | Transactional/confirmation SMS |
| 33 Proposal Creation | `.../33 Proposal Creation/templates.md` | Proposal email + doc merge |
| 39 Payment and Invoicing | `.../39 Payment and Invoicing/templates.md` | Invoice + reminder cascade |
| 40 Client Onboarding | `.../40 Client Onboarding/templates.md` | Welcome email |
| 49 Renewal Management | `.../49 Renewal Management/templates.md` | 90/60/30/7-day renewal reminders |
| 50 Churn Prevention | star `6.5-churn-winback` README | Win-back sequence |
| 51 Customer Feedback and NPS | star `6.6-nps-feedback` README | NPS survey email |
| 53 Referral Programs | star `6.8-referral-program` README | Referral link email |

---

## Part B — New templates (Phase 3 / 8 / 9 gap modules)

### 3.3 Competitor Shift Alert (internal, Slack/Discuss)
```
🔍 Competitor shift detected: [Competitor Name]
Page: [URL]
Change: [AI diff summary — 1-2 lines]
Previous vs new pricing: [old] → [new]
Reviewed by: _______  Action: _______
```

### 3.10 Hot Lead Alert (internal, Slack/Discuss)
```
🔥 Hot Lead: [Company Name]
Score: [total]/100 (Fit: [x], Behavior: [y])
Contact: [Name] — [Email] — [Phone]
Reason: [score_reason]
→ Assign to: [rep] | Next action: outreach within 2 hrs
```

### 8.1 Objection-Match Surfaced (internal, to rep)
```
Objection detected in reply from [Client Name]:
"[reply excerpt]"

Matched library entry: [objection_type] (confidence: [x]%)
Suggested response (ARP framework):
[arp_response]

Review before sending → [Approve & Send] [Edit] [Escalate]
```

### 8.5 Demo Confirmation Email
```
Subject: Demo confirmed — [Date] at [Time]

Hi [First Name],

Confirming our demo on [Date] at [Time] ([Timezone]).

What we'll cover:
- [Agenda point 1]
- [Agenda point 2]

Join here: [meeting link]

See you then,
[Your name]
```

### 8.6 Quote / Pricing Email
```
Subject: Your [Service Line] quote — [Company Name]

Hi [First Name],

Here's the quote we discussed:

[Tier Name] — [Currency] [Amount]/mo
Includes: [line items]

Full breakdown attached. Happy to walk through it — let me know a good time.

[Your name]
```

### 8.8 Deal Desk Approval Request (internal)
```
Subject: Approval needed — [Client Name] ([discount_pct]% discount)

Requested by: [rep name]
Deal: [Company Name] — [Quote total]
Discount requested: [discount_pct]%
Reason: [notes]

[Approve] [Reject] — decision needed within 24h
```

### 8.9 Customer Success Milestone Emails

**Day 1 — Welcome follow-up**
```
Subject: You're all set, [First Name]!

Hi [First Name],

Great having you onboard. Quick recap of what happens next:
[Day 7 / Day 30 preview]

Questions anytime — just reply here.

[Your name]
```

**Day 7 — Check-in**
```
Subject: How's the first week going?

Hi [First Name],

One week in — anything blocking you or unclear so far?

[Your name]
```

**Day 30 — Review**
```
Subject: 30-day review — let's look at results

Hi [First Name],

30 days in. Here's what we've delivered: [summary/link to dashboard]

Worth a quick call to review and plan next steps?

[Your name]
```

**Quarterly / Annual review**
```
Subject: [Quarter/Year] review — [Company Name]

Hi [First Name],

Time for our [quarterly/annual] check-in. Summary attached: [link]

Let's schedule 30 min to walk through it and discuss what's next.

[Your name]
```

### 9.4 Editorial Reminder (internal, Slack)
```
📅 Content due: [Title]
Type: [pillar/social/newsletter]
Owner: [name]
Due: [date] — Status: [planned/drafted/reviewed]
```

### 9.9 Partnership Follow-Up
```
Subject: Following up — [Partner Name] x Nivy

Hi [First Name],

Circling back on [previous topic]. Still worth exploring [partnership idea]?

[Your name]
```

---

## Formatting rules (applies to all new templates above)
- Max 5–8 lines per email body
- One clear ask/CTA per message
- Subject lines under 50 characters
- No ALL CAPS, avoid spam-trigger words (Free, Guarantee, Limited time, Act now)
- Internal alerts (Slack/Discuss) can be denser — these aren't outbound, no deliverability risk
