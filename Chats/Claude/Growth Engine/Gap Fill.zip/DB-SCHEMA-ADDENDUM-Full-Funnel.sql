-- ============================================================
-- DB-SCHEMA-ADDENDUM-Full-Funnel.sql
-- Extends 00-MASTER-MIGRATIONS.sql with tables/columns needed
-- for the NEW Phase 3 (Lead Intelligence), Phase 8 (Sales-Cycle
-- Judgment Layer), and Phase 9 (Marketing Foundation) modules
-- described in N8N-IMPLEMENTATION-PLAN-SalesMarketing.md.
-- Run AFTER 00-MASTER-MIGRATIONS.sql. Safe to re-run (idempotent).
-- ============================================================

-- ------------------------------------------------------------
-- PHASE 3 — Lead Intelligence & Research Foundation
-- ------------------------------------------------------------

-- 3.1 Market Research Digest
CREATE TABLE IF NOT EXISTS market_research_briefs (
  id SERIAL PRIMARY KEY,
  source_name TEXT,
  source_url TEXT,
  country TEXT,
  raw_snapshot TEXT,
  ai_summary TEXT,
  detected_at TIMESTAMP DEFAULT now(),
  reviewed BOOLEAN DEFAULT false
);

-- 3.2 ICP / Persona Store
CREATE TABLE IF NOT EXISTS icp_profiles (
  id SERIAL PRIMARY KEY,
  icp_name TEXT UNIQUE,
  service_line TEXT,
  firmographic_criteria JSONB,
  persona_notes TEXT,
  created_at TIMESTAMP DEFAULT now(),
  updated_at TIMESTAMP DEFAULT now()
);

-- 3.3 Competitor Monitor
CREATE TABLE IF NOT EXISTS competitor_snapshots (
  id SERIAL PRIMARY KEY,
  competitor_name TEXT,
  page_url TEXT,
  raw_content TEXT,
  pricing_extracted JSONB,
  snapshot_at TIMESTAMP DEFAULT now()
);
CREATE TABLE IF NOT EXISTS competitor_shift_alerts (
  id SERIAL PRIMARY KEY,
  competitor_name TEXT,
  previous_snapshot_id INTEGER REFERENCES competitor_snapshots(id),
  new_snapshot_id INTEGER REFERENCES competitor_snapshots(id),
  ai_diff_summary TEXT,
  detected_at TIMESTAMP DEFAULT now(),
  reviewed BOOLEAN DEFAULT false
);

-- 3.4 Lead Source Registry
CREATE TABLE IF NOT EXISTS lead_sources (
  id SERIAL PRIMARY KEY,
  source_name TEXT UNIQUE,
  source_type TEXT, -- e.g. 'linkedin', 'google_maps', 'directory'
  priority INTEGER DEFAULT 0,
  active BOOLEAN DEFAULT true,
  config JSONB
);

-- 3.5 Lead Extraction Engine
CREATE TABLE IF NOT EXISTS raw_leads (
  id SERIAL PRIMARY KEY,
  source_id INTEGER REFERENCES lead_sources(id),
  raw_payload JSONB,
  company_name TEXT,
  contact_name TEXT,
  linkedin_url TEXT,
  extracted_at TIMESTAMP DEFAULT now(),
  is_duplicate BOOLEAN DEFAULT false,
  promoted_to_client_id INTEGER REFERENCES clients_master(id)
);
CREATE INDEX IF NOT EXISTS idx_raw_leads_dedup ON raw_leads (company_name, contact_name) WHERE is_duplicate = false;

-- 3.6 Contact Discovery
CREATE TABLE IF NOT EXISTS contacts (
  id SERIAL PRIMARY KEY,
  raw_lead_id INTEGER REFERENCES raw_leads(id),
  email TEXT,
  email_confidence INTEGER, -- 0-100
  phone TEXT,
  title TEXT,
  discovered_via TEXT, -- 'hunter', 'snov', 'manual'
  discovered_at TIMESTAMP DEFAULT now()
);

-- 3.7 Lead Enrichment
CREATE TABLE IF NOT EXISTS enrichment_log (
  id SERIAL PRIMARY KEY,
  raw_lead_id INTEGER REFERENCES raw_leads(id),
  provider TEXT, -- 'clearbit', 'apollo'
  fields_added JSONB,
  enriched_at TIMESTAMP DEFAULT now()
);

-- 3.8 Data Cleaning
CREATE TABLE IF NOT EXISTS dedup_flags (
  id SERIAL PRIMARY KEY,
  raw_lead_id_a INTEGER REFERENCES raw_leads(id),
  raw_lead_id_b INTEGER REFERENCES raw_leads(id),
  match_score NUMERIC, -- fuzzy-match confidence 0-1
  flagged_at TIMESTAMP DEFAULT now(),
  resolved BOOLEAN DEFAULT false
);

-- 3.9 Lead Verification
CREATE TABLE IF NOT EXISTS verification_log (
  id SERIAL PRIMARY KEY,
  contact_id INTEGER REFERENCES contacts(id),
  provider TEXT, -- 'zerobounce', 'neverbounce'
  status TEXT, -- 'valid','invalid','catch-all','unknown'
  checked_at TIMESTAMP DEFAULT now()
);
ALTER TABLE contacts ADD COLUMN IF NOT EXISTS verification_status TEXT DEFAULT 'unverified';

-- 3.10 Lead Scoring Engine (extends clients_master, already has score/score_reason)
ALTER TABLE clients_master ADD COLUMN IF NOT EXISTS fit_score INTEGER DEFAULT 0;
ALTER TABLE clients_master ADD COLUMN IF NOT EXISTS behavior_score INTEGER DEFAULT 0;
ALTER TABLE clients_master ADD COLUMN IF NOT EXISTS score_tier TEXT; -- Hot/Warm/Cold
ALTER TABLE clients_master ADD COLUMN IF NOT EXISTS score_updated_at TIMESTAMP;

-- 3.11 Lead Segmentation (clients_master.list_segment already exists from 7.2)
-- no new columns needed, reused as-is

-- 3.13 List Management
CREATE TABLE IF NOT EXISTS list_sync_log (
  id SERIAL PRIMARY KEY,
  source_sheet TEXT,
  rows_synced INTEGER,
  synced_at TIMESTAMP DEFAULT now()
);

-- ------------------------------------------------------------
-- PHASE 8 — Sales-Cycle Judgment Layer
-- ------------------------------------------------------------

-- 8.1 Objection Library Lookup
CREATE TABLE IF NOT EXISTS objection_library (
  id SERIAL PRIMARY KEY,
  objection_type TEXT,
  objection_example TEXT,
  arp_response TEXT, -- Acknowledge-Reframe-Proof framework response
  approved BOOLEAN DEFAULT false,
  created_at TIMESTAMP DEFAULT now()
);
CREATE TABLE IF NOT EXISTS objection_matches (
  id SERIAL PRIMARY KEY,
  client_id INTEGER REFERENCES clients_master(id),
  reply_text TEXT,
  matched_objection_id INTEGER REFERENCES objection_library(id),
  match_confidence NUMERIC,
  matched_at TIMESTAMP DEFAULT now(),
  rep_reviewed BOOLEAN DEFAULT false
);

-- 8.2 / 8.3 Call Transcript → Needs Analysis
CREATE TABLE IF NOT EXISTS call_transcripts (
  id SERIAL PRIMARY KEY,
  client_id INTEGER REFERENCES clients_master(id),
  call_type TEXT, -- 'discovery','demo'
  raw_transcript TEXT,
  ai_summary TEXT,
  needs_analysis JSONB, -- structured extracted fields
  recorded_at TIMESTAMP DEFAULT now()
);

-- 8.6 Pricing Lookup + Quote Calc
CREATE TABLE IF NOT EXISTS price_catalog (
  id SERIAL PRIMARY KEY,
  service_line TEXT,
  tier_name TEXT,
  market TEXT, -- 'India','International'
  base_price NUMERIC,
  currency TEXT,
  effective_from DATE,
  active BOOLEAN DEFAULT true
);
CREATE TABLE IF NOT EXISTS quotes (
  id SERIAL PRIMARY KEY,
  client_id INTEGER REFERENCES clients_master(id),
  line_items JSONB,
  total_amount NUMERIC,
  currency TEXT,
  generated_at TIMESTAMP DEFAULT now()
);

-- 8.7 Negotiation Log
CREATE TABLE IF NOT EXISTS negotiation_log (
  id SERIAL PRIMARY KEY,
  client_id INTEGER REFERENCES clients_master(id),
  note TEXT,
  logged_by TEXT,
  logged_at TIMESTAMP DEFAULT now()
);

-- 8.8 Deal Desk Approval
CREATE TABLE IF NOT EXISTS deal_approvals (
  id SERIAL PRIMARY KEY,
  client_id INTEGER REFERENCES clients_master(id),
  quote_id INTEGER REFERENCES quotes(id),
  discount_pct NUMERIC,
  requested_by TEXT,
  status TEXT DEFAULT 'pending', -- pending/approved/rejected
  decided_by TEXT,
  decided_at TIMESTAMP,
  created_at TIMESTAMP DEFAULT now()
);

-- 8.9 Customer Success Plan Reminders
CREATE TABLE IF NOT EXISTS cs_plan_milestones (
  id SERIAL PRIMARY KEY,
  client_id INTEGER REFERENCES clients_master(id),
  milestone_type TEXT, -- 'day1','day7','day30','quarterly','annual'
  due_date DATE,
  completed BOOLEAN DEFAULT false,
  completed_at TIMESTAMP,
  created_at TIMESTAMP DEFAULT now()
);

-- ------------------------------------------------------------
-- PHASE 9 — Marketing Foundation + Content Engines
-- ------------------------------------------------------------

-- 9.1 Brand/Positioning Store
CREATE TABLE IF NOT EXISTS brand_positioning (
  id SERIAL PRIMARY KEY,
  doc_type TEXT, -- 'messaging_house','value_prop','brand_guideline'
  icp_id INTEGER REFERENCES icp_profiles(id),
  content TEXT,
  version INTEGER DEFAULT 1,
  updated_at TIMESTAMP DEFAULT now()
);

-- 9.2 Keyword Research Automation
CREATE TABLE IF NOT EXISTS keyword_map (
  id SERIAL PRIMARY KEY,
  keyword TEXT,
  country TEXT,
  search_volume INTEGER,
  difficulty INTEGER,
  mapped_service_line TEXT,
  pulled_at TIMESTAMP DEFAULT now()
);

-- 9.3 Off-Page/Authority Tracking
CREATE TABLE IF NOT EXISTS backlink_snapshots (
  id SERIAL PRIMARY KEY,
  domain TEXT,
  referring_domains INTEGER,
  domain_authority INTEGER,
  checked_at TIMESTAMP DEFAULT now()
);

-- 9.4 Editorial Calendar Automation
CREATE TABLE IF NOT EXISTS content_calendar (
  id SERIAL PRIMARY KEY,
  title TEXT,
  service_line TEXT,
  content_type TEXT, -- 'pillar','social','newsletter'
  planned_publish_date DATE,
  status TEXT DEFAULT 'planned', -- planned/drafted/reviewed/published
  owner TEXT,
  created_at TIMESTAMP DEFAULT now()
);

-- 9.5 / 9.6 Platform-Specific Social + Video Engine
CREATE TABLE IF NOT EXISTS social_posts (
  id SERIAL PRIMARY KEY,
  content_calendar_id INTEGER REFERENCES content_calendar(id),
  platform TEXT, -- 'linkedin','instagram','youtube','twitter','facebook'
  post_body TEXT,
  media_url TEXT,
  scheduled_at TIMESTAMP,
  published_at TIMESTAMP,
  status TEXT DEFAULT 'queued'
);

-- 9.7 Growth-Hacking Experiment Tracker
CREATE TABLE IF NOT EXISTS growth_experiments (
  id SERIAL PRIMARY KEY,
  tactic_name TEXT,
  impact_score INTEGER, -- 1-5
  effort_score INTEGER, -- 1-5
  status TEXT DEFAULT 'idea', -- idea/testing/scaled/killed
  result_notes TEXT,
  created_at TIMESTAMP DEFAULT now(),
  updated_at TIMESTAMP DEFAULT now()
);

-- 9.9 Partnerships/PR Tracker
CREATE TABLE IF NOT EXISTS partnership_outreach (
  id SERIAL PRIMARY KEY,
  partner_name TEXT,
  contact_email TEXT,
  status TEXT DEFAULT 'contacted',
  last_touch_at TIMESTAMP,
  next_followup_at TIMESTAMP,
  notes TEXT
);

-- ============================================================
-- END — run this after 00-MASTER-MIGRATIONS.sql. Every table
-- above is idempotent (IF NOT EXISTS / ADD COLUMN IF NOT EXISTS).
-- ============================================================
