# n8n Implementation Plan — Sales Funnel (54) + Marketing (22) Full Automation

> Scope correction: ye plan **Sales Funnel + Marketing funnel** ka hai (not
> the research repo). Base: `00_Sales_Funnel.zip`'s `N8N-AUTOMATION-INDEX.md`
> (har stage ka 🟢/🟡/🔴 feasibility flag + real n8n template links already
> defined hai) + `00_Marketing.zip`'s `IMPLEMENTATION-PLAN.md`, cross-checked
> against `RECONCILED-star-topology-v6.zip` (jo already ban chuka hai).
> Companion files: `DB-SCHEMA-ADDENDUM-Full-Funnel.sql`,
> `EMAIL-TEMPLATES-and-Message-Library.md`.

**Legend:** 🟢 High (end-to-end automate) · 🟡 Partial (data/reminder layer
automates, judgment stays human) · 🔴 Low (log/remind only) · ✅ already
built in star-topology · ⬜ not built yet

---

## 1. Already built — no new work (star-topology existing 36 workflows)

Ye stages/modules already n8n workflows ke roop me exist karte hain
(`RECONCILED-star-topology-v6.zip`). Sirf reference ke liye, taaki naya kaam
duplicate na ho:

| Phase | Covers |
|---|---|
| 1 | M05/M06 SEO (partial), M10 content, M22 inbound-CRM bridge, Sales 06–10 (inbound-capture hissa) |
| 2 | Sales 16–25 outreach, 28 booking, 33 proposal, 36 contract, 39 payment, 40–42 onboarding, 49 renewal |
| 4 | Sales 18–20 reply/re-engagement layer |
| 5 | Sales 27 BANT/MEDDIC |
| 6 | Sales 43, 45–48, 50–54 |
| 7 | Sales 23, 14 (refresh only) |

---

## 2. NEW Phase 3 — Lead Intelligence & Research Foundation

Star-topology me Phase 3 ek numbering-hole tha — ye use isi ke liye fill
karte hain, kyunki ye stages logically Phase 1 (Marketing) se bhi pehle
aate hain aur data-foundation hain.

| Module | Stages | Flag | n8n sub-stages (max split) |
|---|---|---|---|
| **3.1 Market Research Digest** | Sales 01, Mkt M01 | 🟡/🔴 | 3.1.1 Scheduled HTTP-request poll (industry stat sources) → 3.1.2 Diff-check node → 3.1.3 Ollama summarize → 3.1.4 Notion/Odoo doc write → 3.1.5 Slack/Discuss alert |
| **3.2 ICP / Persona Store** | Sales 02–03, Mkt M03 | 🔴 (strategic) | 3.2.1 Odoo custom-field/tag schema create → 3.2.2 One-time data-entry form (n8n Form node) → 3.2.3 Store as structured record → 3.2.4 Expose via API for Stages 3.6/3.7 to consume |
| **3.3 Competitor Monitor** | Sales 04, Mkt M07 | 🟡 | 3.3.1 Scheduled scrape (Apify Website Crawler) → 3.3.2 Postgres store (raw snapshot) → 3.3.3 Diff vs last snapshot → 3.3.4 AI diff-summary → 3.3.5 Slack alert → 3.3.6 Report to Hub (`competitor.shift_detected`) |
| **3.4 Lead Source Registry** | Sales 05 | 🔴 (decision) | 3.4.1 Odoo config table (source list + priority) → 3.4.2 API expose for 3.5's extraction jobs to read |
| **3.5 Lead Extraction Engine** | Sales 06 | 🟢 (already has automation.md; not yet a star spoke) | 3.5.1 Apify/Google-Maps/LinkedIn scraper trigger → 3.5.2 Raw-lead Postgres insert → 3.5.3 Dedup Code-node → 3.5.4 Report to Hub (`lead.extracted`) |
| **3.6 Contact Discovery** | Sales 07 | 🟢 | 3.6.1 Hunter.io/Snov HTTP node (batch) → 3.6.2 Match back to raw-lead row → 3.6.3 Update `contacts` table |
| **3.7 Lead Enrichment** | Sales 08 | 🟢 | 3.7.1 Clearbit/Apollo API call → 3.7.2 Firmographic fields write → 3.7.3 Enrichment-log insert |
| **3.8 Data Cleaning** | Sales 09 | 🟢 | 3.8.1 Scheduled dedup job (Code-node fuzzy match email+company) → 3.8.2 Flag duplicates → 3.8.3 Slack digest for review |
| **3.9 Lead Verification** | Sales 10 | 🟢 | 3.9.1 ZeroBounce/NeverBounce batch HTTP → 3.9.2 Verification-status write → 3.9.3 Bounce-risk flag |
| **3.10 Lead Scoring Engine** | Sales 11 | 🟢 | 3.10.1 Rule-based Code-node scoring (fit+behavior points) → 3.10.2 `clients_master.score`/`score_reason` update → 3.10.3 Hot-lead Slack alert → 3.10.4 Report to Hub (`lead.scored`) |
| **3.11 Lead Segmentation** | Sales 12 | 🟢 | 3.11.1 Segment-rule Code-node → 3.11.2 `list_segment` update → 3.11.3 (already feeds existing 7.2) |
| **3.12 CRM Field Sync** | Sales 13 (ongoing part) | 🟢 | 3.12.1 One-time Odoo field/stage setup (manual, not n8n) → 3.12.2 Scheduled sync job for drift-detection |
| **3.13 List Management** | Sales 14 | 🟢 | 3.13.1 Sheets/NocoDB → CRM sync template → 3.13.2 (overlaps existing 7.2 refresh) |
| **3.14 Outreach Channel Config** | Sales 15 | 🔴 (strategic) | 3.14.1 Config table (channel mix per ICP/segment) → 3.14.2 Feeds Phase 2's 2.1 Multi-channel Outreach as input |

**Dispatcher wiring:** 3.5 → reports `lead.extracted` → feeds into existing
**1.3/1.4** intake pattern (same shape, new source). 3.10 → `lead.scored`
→ can fan into 2.1 Outreach (same as existing `lead.qualified`).

---

## 3. Phase 8 — Sales-Cycle Judgment Layer (data/reminder automation only)

Sales stages 26, 29–32, 34–35, 37–38, 44 — per the KB's own honest flag,
**core judgment stays human**; automation limited to logging/reminders/prep.

| Module | Stage | Flag | n8n sub-stages |
|---|---|---|---|
| **8.1 Objection Library Lookup** | 26 | 🔴 | 8.1.1 Reply-text arrives (from existing 4.3.x reply tracking) → 8.1.2 AI-classify objection type → 8.1.3 Match closest library entry (Postgres lookup) → 8.1.4 Surface to rep (Odoo task/Slack) for review-before-send |
| **8.2 Call Transcript → CRM Sync** | 29 | 🔴/🟡 | 8.2.1 Transcript webhook (from dialer/Zoom) → 8.2.2 AI summary → 8.2.3 CRM notes field update |
| **8.3 Needs-Analysis Extraction** | 30 | 🟡 | 8.3.1 Same transcript → 8.3.2 AI extracts structured needs fields → 8.3.3 CRM custom-field write |
| **8.4 Solution Mapping** | 31 | 🔴 (N/A) | No workflow — expert judgment only |
| **8.5 Demo Scheduling/Assets** | 32 | 🟡 | 8.5.1 Cal.com booking (reuse 2.3 pattern) → 8.5.2 Asset-delivery email → 8.5.3 Reminder sequence |
| **8.6 Pricing Lookup + Quote Calc** | 34 | 🟡 (lookup only) | 8.6.1 Price-catalog Postgres table → 8.6.2 Tier+addon lookup Code-node → 8.6.3 Quote total → feeds existing 2.4 Proposal Generation |
| **8.7 Negotiation Log** | 35 | 🔴 (N/A) | 8.7.1 Manual log entry form only — no workflow logic |
| **8.8 Deal Desk Approval** | 38 | 🟢 | 8.8.1 Discount/terms threshold check (Code-node) → 8.8.2 Approve/Reject buttons (n8n Form/Webhook) → 8.8.3 Odoo approval-chain update → 8.8.4 Report to Hub (`deal.approved`) |
| **8.9 Customer Success Plan Reminders** | 44 | 🟡 | 8.9.1 Milestone-schedule Code-node (Day 1/7/30/quarterly, anchored to onboarding date from existing 2.7) → 8.9.2 Trigger fires each touchpoint → 8.9.3 Monthly NPS dispatch (reuses existing 6.6) |

---

## 4. Phase 9 — Marketing Foundation + Content Engines (currently missing)

| Module | Mkt stages | Flag | n8n sub-stages |
|---|---|---|---|
| **9.1 Brand/Positioning Store** | M01–M03 | 🔴 (strategic) | 9.1.1 Structured doc store (Odoo/Notion) — no workflow logic, feeds 3.2/2.1 personalization |
| **9.2 Keyword Research Automation** | M04 | 🟡 | 9.2.1 Scheduled Ubersuggest/GSC API pull → 9.2.2 Keyword-map table update → 9.2.3 (extends existing 1.2 SEO Automation) |
| **9.3 Off-Page/Authority Tracking** | M07 | 🟡 | 9.3.1 Backlink monitor (free-tier API) → 9.3.2 Weekly digest |
| **9.4 Editorial Calendar Automation** | M08 | 🟢 | 9.4.1 Content-calendar Postgres/Airtable → 9.4.2 Scheduled reminder → 9.4.3 Status sync to 1.1 Content-Social Factory |
| **9.5 Platform-Specific Social Engines** | M11–M16 | 🟡 | 9.5.1 Per-platform Postiz/native-API posting node (extends existing 1.1) → 9.5.2 Platform-specific formatting Code-node |
| **9.6 YouTube/Video Engine** | M13 | 🟡 | 9.6.1 Upload-queue trigger → 9.6.2 Metadata/thumbnail automation → 9.6.3 Publish schedule |
| **9.7 Growth-Hacking Experiment Tracker** | M18 | 🟢 | 9.7.1 Airtable/NocoDB Impact×Effort tracker → 9.7.2 Weekly experiment-status digest |
| **9.8 Community Building** | M19 | 🔴 | 9.8.1 Discord/WhatsApp new-member welcome automation only |
| **9.9 Partnerships/PR Tracker** | M20 | 🔴 | 9.9.1 Outreach-log + reminder cadence only |
| **9.10 Marketing Analytics Digest** | M21 | 🟢 | 9.10.1 GA4 → Looker Studio (existing connector) → 9.10.2 Weekly Metabase/Odoo digest email (reuse 2.8 Delivery+Reporting pattern) |

---

## 5. Build order (waves — automate high-feasibility first)

| Wave | Modules | Why first |
|---|---|---|
| **1** | 3.5–3.11 (extraction → scoring pipeline) | 🟢 flags, already have full `automation.md` depth in KB, direct n8n.io templates exist |
| **2** | 3.1, 3.3, 3.13, 9.2, 9.4, 9.10 | 🟡 but well-scoped, high reuse of existing patterns (7.2, 1.2, 2.8) |
| **3** | 8.6, 8.8, 8.9 | 🟢/🟡, plug directly into existing 2.4/2.7/6.6 |
| **4** | 8.1, 8.2, 8.3, 8.5 | 🟡/🔴, needs reply-tracking (4.3.x) already live first |
| **5** | 9.1, 9.5, 9.6, 9.7, 9.8, 9.9 | Marketing content engines, lower urgency, mostly 🟡/🔴 |
| **6** | 3.2, 3.4, 3.12, 3.14, 8.4, 8.7 | 🔴 strategic/setup-only, no real workflow logic — do these as one-time config sessions, not sprints |

**Per-module build checklist (repeat for every module above):**
1. Confirm/extend DB schema (`DB-SCHEMA-ADDENDUM-Full-Funnel.sql`)
2. Build trigger node (cron/webhook/DB-poll)
3. Build core logic (Code/HTTP/AI nodes per sub-stage)
4. Add `Report to Hub` node where cross-module hand-off exists
5. Wire Hub-Dispatcher Switch branch (only if a real consumer exists)
6. Add error handling → `automation_errors` table (existing 0.0 shared pattern)
7. Validate: JSON parses, no dangling connections, no duplicate node IDs
8. Update `docs/S0-EVENT-TYPE-TAXONOMY.md` with new event types

---

## 6. New event types to add to taxonomy

| event_type | Reported by | Consumed by |
|---|---|---|
| `lead.extracted` | 3.5 | 3.6/3.7 (internal chain) |
| `lead.scored` | 3.10 | 2.1 Outreach (parallel to existing `lead.qualified`) |
| `competitor.shift_detected` | 3.3 | Informational (Slack), no auto-consumer yet |
| `deal.approved` | 8.8 | 2.4/2.5 (unblocks proposal/contract send) |
| `cs_plan.milestone_due` | 8.9 | Internal reminder only |

---

## 7. Companion files
- `DB-SCHEMA-ADDENDUM-Full-Funnel.sql` — every new table/column needed above
- `EMAIL-TEMPLATES-and-Message-Library.md` — templates already in KB (reference) + newly drafted ones for gap stages
