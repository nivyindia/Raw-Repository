# Country-Specific Legal Notes — Contests, Referrals & Promotions
**Reference doc for whoever finalizes T&C/rules per market. Not legal advice — flags what to ask a local lawyer, per country Nivy Next targets.**

## 🇺🇸 United States
- Promotions with an element of **chance** and a prize are legally a "sweepstakes" and must offer a **free/no-purchase alternate method of entry (AMOE)** — required in most states.
- **NY, FL, RI**: prize promotions above certain thresholds (commonly $5,000 in NY/FL) require **bonding and state registration** before launch.
- Skill-based contests (judged, like the Top 100 Awards) avoid most sweepstakes-law triggers, provided selection is genuinely merit-based and not disguised chance.
- If any element is a public **vote**, some states treat "most popular" mechanics with added disclosure requirements — keep vote weighting minority (e.g., ≤25%) alongside judge scoring, as drafted in the sample rules.
- Prizes over **$600** to a US person trigger 1099-NEC / 1099-MISC reporting obligations.

## 🇬🇧 United Kingdom
- Free prize draws are generally fine without a gambling license **only if genuinely free to enter** (no purchase or payment requirement) — the sample rules already do this.
- If any "pay-to-enter" or "premium-rate" entry route is ever added, this becomes a regulated lottery under the Gambling Act 2005 — avoid unless licensed.
- Advertising Standards Authority (ASA) rules require prize terms to be clear, accessible before entry, and not misleading about odds/chances.

## 🇨🇦 Canada
- **Quebec** requires promotions with total prizes above CAD 100 to be **registered with the Régie des alcools, des courses et des jeux (RACJ)**, along with a bilingual French/English rules requirement and specific structured-participation-rules format. This is the single biggest Canada-specific gotcha — consider **excluding Quebec** for early low-stakes campaigns to avoid registration until volume justifies it (as flagged in the T&C template, Section 1.3).
- Other provinces: no chance-element promotion may require a "purchase" as sole entry method (mirrors US AMOE requirement).

## 🇦🇺 Australia
- Trade promotion lotteries with a **chance element** require **permits in NSW and ACT** (and sometimes SA) above certain prize thresholds — a genuinely skill/merit-judged contest (like the sample Top 100 Awards) is generally exempt.
- Australian Consumer Law prohibits misleading conduct about odds, judging criteria, or prize value — keep judging criteria and prize ARV explicit (already done in the sample Official Rules).

## 🇦🇪 United Arab Emirates
- UAE has traditionally restricted promotional draws/raffles involving chance; **mainland promotions with a prize typically require a trade promotion permit** from the Department of Economic Development (or equivalent free-zone authority) before launch.
- Skill-based/merit-judged contests (no random draw) sit in a lower-risk category but **local counsel review is strongly recommended before running any UAE-facing prize contest**, more so than for the other four markets.
- Free-zone entities (e.g., a UAE branch registered in a free zone) may have separate rules from mainland — confirm which applies to Nivy Next's actual registration status in UAE, if any.

## 🇮🇳 India
- Prize competitions with a skill element are generally permitted; those with pure chance can implicate state-level gambling/lottery laws (which vary significantly by state — e.g., stricter in some southern states).
- Consumer Protection Act, 2019 and its e-commerce rules require clear, non-misleading disclosure of terms — already reflected in the T&C draft.
- As the home jurisdiction for Nivy Next/Billion Dreams United, India is the recommended default **governing law** for the general Terms (Section 10 of `01-Terms-and-Conditions.md`), with country-specific Official Rules layering in local consumer-protection carve-outs per market above.

## Practical sequencing recommendation
1. Launch the flagship contest (skill/merit-judged, no chance element, no purchase necessary) first — this is the lowest-risk structure across all six markets and matches what's already drafted.
2. Before adding any **random-draw** or **paid-entry** mechanic, get country-specific sign-off — start with US/UK/Australia (more predictable frameworks) before UAE/Quebec-inclusive Canada.
3. Keep prize components as **services/exposure rather than cash** where possible (as done in the sample Top 100 prize table) — this meaningfully reduces registration/bonding triggers across most of these jurisdictions.
