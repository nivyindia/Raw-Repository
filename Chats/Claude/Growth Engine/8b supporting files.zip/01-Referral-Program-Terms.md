# Nivy Next Refer & Earn — Program Terms
**[TEMPLATE — 8.2 Referral Engine. `campaign_slug: refer-and-earn-global`]**

*Last updated: {{last_updated_date}} · Version 1.0*

## 1. Overview
The Nivy Next Refer & Earn program rewards existing clients, partners, and community members ("Referrers") for introducing new businesses ("Referred Clients") to Nivy Next / Nivy Advisory / Nivy Academy services.

## 2. Who can participate
Any current Nivy Next client, alumni of Nivy Academy, or approved partner/agency, aged 18+, in good standing (no outstanding disputes or overdue invoices), located in any country Nivy Next operates in (US, UK, Canada, Australia, UAE, India, or other — see your unique referral link's terms).

**Not eligible to earn a reward:** self-referrals (referring your own business or a business you own >10% of), Nivy Next employees/contractors referring on behalf of the company's own outbound efforts, and referrals of businesses that were already in active conversation with Nivy Next in the 90 days prior to the referral being logged.

## 3. How it works
1. Referrer requests a unique referral code/link (format: `nivy.link/r/{{referral_code}}`) via the referral landing page or client portal.
2. Referrer shares the link with a business that could use Nivy Next's services.
3. Referred Client clicks the link and books a discovery call or submits an inquiry — this creates a `referral_ledger` row at `reward_stage = submitted`.
4. Reward is released in **two stages**:

| Stage | Trigger | Reward (default — see table below for tier-specific amounts) |
|---|---|---|
| **Stage 1 — Meeting Booked** | Referred Client attends a qualified discovery call | **USD 50** (or local equivalent) flat, paid within 14 days |
| **Stage 2 — Converted & Paid** | Referred Client signs and makes their first payment | **10% of the referred client's first invoice value**, capped at **USD 1,000** per referral |

5. Both stages require **human approval** (Odoo Discuss flag) before payout is queued — no reward is released automatically.

## 4. Reward payment
- Paid via bank transfer, PayPal, or Wise, in USD or the Referrer's local currency at the prevailing rate on the payout date, within **14 business days** of approval.
- Referrer is responsible for any tax on referral income in their jurisdiction. Nivy Next will issue relevant tax documentation (e.g., 1099-NEC for US Referrers earning over $600/year) where legally required.
- There is **no cap** on the number of successful referrals a single Referrer can make, but Nivy Next reserves the right to review unusually high-volume referral activity for compliance with Section 6 (Fraud).

## 5. Referral code validity
- Each `referral_code` is unique to one Referrer and does not expire unless the underlying `campaigns` row is set to `status = 'ended'`.
- A Referred Client is credited to the **first** valid referral code they engaged with (first-touch attribution), tracked via `referral_ledger.referred_client_id`.

## 6. Fraud prevention
Reward stages are only released after: (a) the referred business is confirmed to be a genuine, previously-unengaged prospect, and (b) no signs of self-referral or duplicate-account referral are found by the shared fraud-scoring logic used across the Growth Engine (see `8.1` fraud rules — same scoring code is reused). Attempted fraud voids all pending and future rewards for that Referrer.

## 7. Program changes
Nivy Next may change reward amounts, tiers, or eligibility for **new** referrals at any time by updating the relevant `campaigns.config`. Changes do not retroactively affect referrals already in the ledger at `reward_stage != submitted`.

## 8. Governing terms
This program is also subject to the general Privacy Notice (`../8.1-Contest-Engine/03-Privacy-Notice-Contest-Data.md`) and Nivy Next's standard Master Service Agreement where the Referrer is also a client.

## 9. Contact
{{support_email}} · {{support_whatsapp}}

---

## Appendix — Sample tiered config (edit freely)

| Tier | Who | Stage 1 (meeting booked) | Stage 2 (converted) |
|---|---|---|---|
| Standard | Any eligible Referrer | $50 | 10% of first invoice, capped $1,000 |
| Alumni (Nivy Academy graduates) | Academy alumni | $75 | 12%, capped $1,200 |
| Partner/Agency | Approved reseller partners | $100 | 15%, capped $2,000 |
| Diwali Special (time-boxed campaign) | Any Referrer, during campaign window | $100 (2x) | 10%, capped $1,000 |

> ⚠️ Legal note: referral/finder's-fee arrangements involving accounting/tax services (Nivy Advisory) may be restricted by professional-conduct rules in some jurisdictions (e.g., certain US state CPA boards limit fee-splitting for referrals). Confirm with a compliance advisor before extending this program to Nivy Advisory specifically.
