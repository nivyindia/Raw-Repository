-- ============================================================
-- Phase 8b — Sample campaign seed data
-- Run AFTER 01-PHASE-8-MIGRATIONS.sql.
-- Populates `campaigns` (and one linked config example) for the
-- 3 launch campaigns recommended in Section 3.3 of the
-- Implementation Plan: 1 contest + 1 referral + 1 free-audit.
--
-- All prize amounts, dates, and copy are PLACEHOLDER / EXAMPLE
-- values drafted for international launch — edit freely before
-- setting status = 'active'. Everything stays 'draft' here on
-- purpose so nothing goes live by accident on import.
-- ============================================================

-- ------------------------------------------------------------
-- 8.1 — Contest: "Nivy Next Top 100 Global Business Awards 2026"
-- ------------------------------------------------------------
INSERT INTO campaigns (
  campaign_slug, engine, campaign_type, status, config, channels, starts_at, ends_at
) VALUES (
  'nivy-top-100-2026',
  '8.1',
  'contest',
  'draft',                                  -- flip to 'active' when ready to launch
  '{
    "name": "Nivy Next Top 100 Global Business Awards 2026",
    "type": "merit_judged",
    "no_purchase_necessary": true,
    "eligible_countries": ["US","UK","CA","AU","AE","IN"],
    "excluded_regions": ["QC"],
    "categories": [
      "Best Digital-First Startup","Best Customer Experience","Best Use of AI in Business",
      "Fastest-Growing Small Business","Best Sustainability Initiative","Best Community Impact",
      "Best E-commerce Brand","Best Professional Services Firm",
      "Best Marketing Campaign of the Year","Founder of the Year"
    ],
    "winners_per_category": 10,
    "prize": {
      "currency": "USD",
      "components": [
        {"item": "3-month Nivy Next Growth marketing package", "value": 3000},
        {"item": "Feature story + backlink via PR partners", "value": 500},
        {"item": "Top 100 2026 digital badge + certificate", "value": 150},
        {"item": "Winner spotlight, 3+ social posts", "value": 300},
        {"item": "1-year Founders Circle community access", "value": 200}
      ],
      "total_arv_per_winner": 4150
    },
    "fraud_score_threshold": 50,
    "winner_response_window_days": 7
  }'::jsonb,
  ARRAY['email','whatsapp','telegram','linkedin'],
  '2026-10-01 00:00:00+05:30',
  '2026-11-15 23:59:00+05:30'
)
ON CONFLICT (campaign_slug) DO NOTHING;

-- ------------------------------------------------------------
-- 8.2 — Referral: "Nivy Next Refer & Earn (Global)"
-- ------------------------------------------------------------
INSERT INTO campaigns (
  campaign_slug, engine, campaign_type, status, config, channels, starts_at, ends_at
) VALUES (
  'refer-and-earn-global',
  '8.2',
  'referral',
  'draft',
  '{
    "name": "Nivy Next Refer & Earn",
    "currency": "USD",
    "tiers": {
      "standard":  {"stage1_flat": 50,  "stage2_pct": 10, "stage2_cap": 1000},
      "alumni":    {"stage1_flat": 75,  "stage2_pct": 12, "stage2_cap": 1200},
      "partner":   {"stage1_flat": 100, "stage2_pct": 15, "stage2_cap": 2000}
    },
    "payout_window_days": 14,
    "attribution": "first_touch",
    "self_referral_blocked": true,
    "fraud_score_threshold": 50
  }'::jsonb,
  ARRAY['email','whatsapp'],
  '2026-09-01 00:00:00+05:30',
  NULL                                       -- open-ended / evergreen program
)
ON CONFLICT (campaign_slug) DO NOTHING;

-- Example limited-time BOOSTED variant of the same engine, running
-- in parallel with the evergreen program above (demonstrates the
-- "N campaigns, one workflow" pattern from Section 3 of the plan):
INSERT INTO campaigns (
  campaign_slug, engine, campaign_type, status, config, channels, starts_at, ends_at
) VALUES (
  'diwali-referral-2026',
  '8.2',
  'referral',
  'draft',
  '{
    "name": "Diwali Referral Special 2026",
    "currency": "USD",
    "tiers": {
      "standard": {"stage1_flat": 100, "stage2_pct": 10, "stage2_cap": 1000}
    },
    "payout_window_days": 14,
    "attribution": "first_touch",
    "self_referral_blocked": true,
    "fraud_score_threshold": 50,
    "note": "2x Stage-1 flat reward vs standard tier, time-boxed"
  }'::jsonb,
  ARRAY['email','whatsapp','telegram'],
  '2026-10-15 00:00:00+05:30',
  '2026-11-10 23:59:00+05:30'
)
ON CONFLICT (campaign_slug) DO NOTHING;

-- ------------------------------------------------------------
-- 8.3 — Free-Value: "Free Global Marketing & Website Audit"
-- ------------------------------------------------------------
INSERT INTO campaigns (
  campaign_slug, engine, campaign_type, status, config, channels, starts_at, ends_at
) VALUES (
  'free-global-audit',
  '8.3',
  'free_audit',
  'draft',
  '{
    "name": "Free Marketing & Website Audit",
    "sub_types": ["website","marketing","both"],
    "delivery_hours_sla": 24,
    "follow_up_touches": 1,
    "eligible_countries": ["US","UK","CA","AU","AE","IN","*"],
    "duplicate_domain_window_days": 30
  }'::jsonb,
  ARRAY['email','whatsapp'],
  '2026-09-01 00:00:00+05:30',
  NULL
)
ON CONFLICT (campaign_slug) DO NOTHING;

-- ============================================================
-- Sanity check
-- ============================================================
-- SELECT campaign_slug, engine, status, starts_at, ends_at FROM campaigns ORDER BY id;
--
-- To go live on any campaign:
--   UPDATE campaigns SET status = 'active' WHERE campaign_slug = '<slug>';
-- ============================================================
