# Official Rules — "Nivy Next Top 100 Global Business Awards 2026"
`campaign_slug: nivy-top-100-2026` · `engine: 8.1` · `campaign_type: contest` (merit-based, no purchase necessary)

*This is a sample, fully-drafted Official Rules doc for the flagship contest referenced in the Phase 8 plan ("Nivy Top 100"). Copy this file's structure for every future `contest_entries`-linked campaign; just swap the details below.*

## 1. Contest Name & Sponsor
**Nivy Next Top 100 Global Business Awards 2026**, sponsored by Nivy Next, a brand of Billion Dreams United, Lucknow, India.

## 2. Contest Period
- **Opens:** {{starts_at}} — e.g. 01 Oct 2026, 00:00 IST
- **Nomination/Entry deadline:** {{entry_deadline}} — e.g. 15 Nov 2026, 23:59 in entrant's local time
- **Judging window:** 16 Nov – 05 Dec 2026
- **Winners announced:** 15 Dec 2026, at the virtual "Nivy Top 100 Awards" livestream

## 3. Eligibility
Open to small and mid-sized businesses (annual revenue under **USD 10M**) legally operating in: 🇺🇸 United States · 🇬🇧 United Kingdom · 🇨🇦 Canada · 🇦🇺 Australia · 🇦🇪 UAE · 🇮🇳 India. One nomination per business (self-nomination or third-party nomination both accepted). No cost to enter.

## 4. Categories (10 winners per category = 100 total)
1. Best Digital-First Startup
2. Best Customer Experience
3. Best Use of AI in Business
4. Fastest-Growing Small Business
5. Best Sustainability Initiative
6. Best Community Impact
7. Best E-commerce Brand
8. Best Professional Services Firm
9. Best Marketing Campaign of the Year
10. Founder of the Year

*(Categories are illustrative — adjust to match your actual audience segments before launch.)*

## 5. How to Enter
1. Visit the campaign landing page (`04-landing-page-contest-entry.html` for the reference build) with the campaign link (contains `?c=nivy-top-100-2026`).
2. Submit: business name, website/social handle, country, category, a 150–300 word "why we deserve this" pitch, and one supporting image/logo.
3. Entrant receives an automated confirmation (email/WhatsApp) with entry ID.

## 6. Judging Criteria (100 points total)
| Criterion | Weight |
|---|---|
| Impact & results demonstrated | 30 |
| Innovation / differentiation | 25 |
| Customer/community testimonials & evidence | 20 |
| Growth trajectory | 15 |
| Overall pitch quality | 10 |

Judged by a panel of 3–5 Nivy Next leadership/marketing advisors. Top 3 per category go to a public "community vote" round (25% weight blended with judge score) before the final 10 winners per category are confirmed. **All final selections pass through the human-approval gate before public announcement — no automated auto-declare.**

## 7. Prizes
**Approximate Retail Value (ARV) per winning business, in USD:**

| Prize component | Est. value (USD) |
|---|---|
| Nivy Next digital marketing package (3 months, "Growth" tier) | $3,000 |
| Feature story + backlink on Nivy Next's international press/PR partners | $500 |
| "Top 100 2026" digital badge + certificate for winner's website | $150 |
| Winner spotlight across Nivy Next's social channels (min. 3 posts) | $300 |
| Invitation to Nivy Next's private "Founders Circle" community (8.5 Engine) — 1 year | $200 |
| **Total ARV per winner** | **≈ $4,150** |
| **Total prize pool (100 winners)** | **≈ $415,000 in services/exposure (not cash)** |

*Prizes are marketing services and exposure, not cash — this is a deliberate design choice to reduce lottery-law exposure across jurisdictions (see `03-Country-Specific-Legal-Notes.md`). Adjust freely; if you switch any component to a cash-equivalent, re-check chance-vs-skill classification and per-state US registration thresholds.*

No cash alternative is offered for the service-based components; a cash-equivalent substitution is offered only where a component cannot be technically delivered to the winner's country.

## 8. Winner Notification & Publicity
Winners are notified by email and WhatsApp within 3 business days of the announcement date and asked to confirm acceptance within **7 days**. See main Terms, Section 5 (Publicity) for usage rights.

## 9. General Conditions
This Contest is also governed by the general **Terms and Conditions** (`01-Terms-and-Conditions.md`). Where these Official Rules and the general Terms conflict, these Official Rules control for this specific Contest.

## 10. Governing Law
These rules are governed by the laws of India for global entrants, **except** that entrants resident in the United States, United Kingdom, Canada, or Australia may additionally rely on the mandatory consumer-protection provisions of their own country's law, to the extent such provisions cannot be excluded by contract.

## 11. Sponsor Contact
{{support_email}} · {{support_whatsapp}} · Billion Dreams United, Lucknow, Uttar Pradesh, India

---
> ⚠️ Placeholder values throughout (dates, prize amounts, categories) — edit freely. Recommend legal review before this goes live, especially the "community vote" component in the US (voting-based promotions have their own state-level disclosure rules).
