# Privacy Notice — Contest, Referral & Free-Audit Entrant Data
**[TEMPLATE — applies across 8.1 Contest, 8.2 Referral, and 8.3 Free-Audit engines. Link this from every landing page footer.]**

*Last updated: {{last_updated_date}}*

This notice explains how **{{legal_entity_name}}** (Nivy Next / Billion Dreams United) collects and uses personal data when you enter a contest, submit a referral, or request a free audit through our Growth Engine campaigns.

## 1. What we collect
- **Identity & contact data:** name, business name, email, phone/WhatsApp number, country
- **Submission content:** entry pitch, images, website/social URLs, audit target URL
- **Technical data:** IP address, submission timestamp, referral source, `campaign_slug`, fraud-score signals
- **Communications data:** replies/engagement via WhatsApp, Telegram, or email tied to your entry

## 2. Why we collect it (legal basis)
| Purpose | Legal basis (where GDPR/UK GDPR applies) |
|---|---|
| Running the contest/referral/audit you entered | Contract (performance of these Terms) |
| Fraud/duplicate-entry prevention | Legitimate interest |
| Winner verification & prize fulfillment, tax documentation | Legal obligation / contract |
| Marketing follow-up about Nivy Next services | Consent (opt-in at entry; opt-out anytime) |

## 3. Who we share it with
- Internal CRM (`clients_master`) and campaign database (`campaigns`, `contest_entries`, `referral_ledger`, `audit_requests`)
- Messaging infrastructure providers (WhatsApp Business API/Waha, Telegram, email/SMTP provider) strictly to deliver contest communications
- Judging panel members, for the entries they are assigned to evaluate
- We do **not** sell personal data to third parties.

## 4. International transfers
Data is stored and processed on servers accessible to our team in India. For entrants in the UK/EU, transfers out of the UK/EEA rely on Standard Contractual Clauses or an equivalent safeguard where required. For US/Canada/Australia/UAE entrants, data is processed under the contractual necessity basis described above.

## 5. Retention
- Non-winning entry data: retained **12 months** post-contest-close, then deleted or anonymized, unless you opted in to ongoing marketing contact.
- Winner data (for tax/legal compliance): retained per local statutory requirement (typically 5–7 years for tax records).
- Referral ledger data: retained for the life of the referred client relationship + 3 years.

## 6. Your rights
Depending on your country, you may have the right to access, correct, delete, or port your data, and to object to or restrict certain processing. **UK/EU residents:** rights under UK/EU GDPR. **California residents:** rights under CCPA/CPRA (no sale of personal information occurs). **Australian residents:** rights under the Privacy Act 1988 (Cth) / Australian Privacy Principles. **Canadian residents:** rights under PIPEDA.

To exercise any right, contact **{{privacy_contact_email}}**. We will respond within the timeframe required by applicable law (typically 30 days).

## 7. Automated decision-making
Fraud scoring is used to flag (not auto-reject) suspicious entries — all disqualifications and all winner selections involve human review before being finalized. You may request human review of any automated flag on your entry.

## 8. Children
Contests are not directed at, and entry is not permitted for, individuals under 18.

## 9. Contact
{{legal_entity_name}} · Lucknow, Uttar Pradesh, India · {{privacy_contact_email}}

---
> ⚠️ Template only — have counsel confirm GDPR Article 27 EU-representative requirements (if you'll actively target EU residents) and CCPA notice-at-collection wording before go-live.
