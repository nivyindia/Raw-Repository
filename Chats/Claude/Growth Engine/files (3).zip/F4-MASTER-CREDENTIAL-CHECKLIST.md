# F4 — Master Credential Checklist

> Har `.json` file (40 real modules + shared error handler + merged funnel) scan kiya — jitni bhi node me credential lagti hai, sab yahan ek jagah hai. Ye woh checklist hai jo pehle sirf Phase 1/2 (DEPLOYMENT-GUIDE.md §8-9) ke liye thi — ab **Phase 4-7 bhi cover** hai.
>
> **Kaise use karo:** n8n me har credential TYPE ke liye ek baar credential banao (neeche 4 types hain), phir har node me us type ka ID paste karo. Ek hi credential ID sab jagah reuse hoga — 134 postgres nodes ka matlab 134 alag credential nahi, sirf 1 credential 134 jagah reference hota hai.

---

## Summary — 4 credential types, 171 node references total

| Credential Type | Kitni jagah use hua | Kitne files me | Kya banana hai |
|---|---|---|---|
| **Postgres** (`Odoo Postgres`) | 134 nodes | 36 files | 1 Postgres credential (`growthengine` DB) |
| **SMTP** (`Postal SMTP`) | 27 nodes | 15 files | 1 SMTP credential (Postal server) |
| **HTTP Basic Auth** (`Nextcloud WebDAV`, `Odoo API`) | 9 nodes | 4 files | 2 credentials — Nextcloud WebDAV + Odoo API |
| **Slack API** | 1 node | 1 file | 1 Slack credential (only if using Slack for 6.3.1 support tickets, else skip) |

---

## Step-by-step

### Step 1 — Create the credentials (n8n UI → Credentials → New)

1. **Odoo Postgres** — Postgres type, host/port/db/user/password for the `growthengine` DB (per `DEPLOYMENT-GUIDE.md` §2).
2. **Postal SMTP** — SMTP type, your Postal server's SMTP host/port/user/password (per §4).
3. **Nextcloud WebDAV** — HTTP Basic Auth type, Nextcloud username + app-password (per §5).
4. **Odoo API** — HTTP Basic Auth type, used by the new `0.0-error-handler` workflow's Discuss-alert node — same Odoo credentials as elsewhere, just needs its own entry since it's a Basic Auth field.
5. **Slack API** (only if 6.3.1 uses Slack, not Chatwoot/other) — Slack type, bot token.

### Step 2 — Copy each credential's ID into every node listed below

n8n shows the credential's ID when you open it. Every node below currently has a placeholder (`REPLACE_WITH_CREDENTIAL_ID`, `REPLACE_WITH_ODOO_POSTGRES_CREDENTIAL_ID`, or empty `''`) — paste the real ID over it.

---

## Postgres — 134 nodes, 36 files

<details>
<summary>Phase 1 (11 nodes across 5 files)</summary>

- `1.1-content-social-factory`: Get New Published Blog Posts, Mark Post as Processed
- `1.2-seo-automation`: Get Pages Missing Meta Description, Update Page Meta Description
- `1.3-website-lead-capture`: Insert into clients_master
- `1.4-inbound-form-qualification`: Fetch Lead from clients_master, Update clients_master with Score
- `1.5-central-crm-sync`: Detect CRM Stage Changes, Upsert clients_master
</details>

<details>
<summary>Phase 2 (33 nodes across 9 files)</summary>

- `2.1-multichannel-outreach`: Fetch Lead Detail, Update clients_master (Contacted), Mark Lead as Replied
- `2.2-nurture-sequence`: Fetch Leads Due for Nurture, Update Nurture Step
- `2.3-booking-sync`: Find Lead (Booked Path), Postgres - Mark Booked, Postgres - Revert to Nurture
- `2.4-proposal-generation`: Fetch Lead Detail, Postgres - Mark Proposal Sent
- `2.5-contract-esign`: Fetch Lead + Proposal, Postgres - Mark Contract Sent, Postgres - Mark Won
- `2.6-invoice-payment`: Fetch Lead + Deal Detail, Postgres - Mark Invoiced, Find Lead by Invoice ID, Postgres - Mark Paid
- `2.7-client-onboarding`: Fetch Lead + Deal Detail, Postgres - Mark Onboarded
- `2.8-delivery-reporting`: Fetch Active Clients, Postgres - Log Report Sent
- `2.9-renewal-revenue-ops`: Fetch Renewals Due (30 days), Postgres - Mark Renewal Reminder Sent, Fetch Overdue (Past Renewal Date), Postgres - Mark Churn Risk, Find Lead by Invoice ID, Postgres - Mark Payment Failed
</details>

<details>
<summary>Phase 4 (21 nodes across 6 files)</summary>

- `4.1.3-sms-reengagement`: Fetch Re-engagement Candidates, Postgres - Mark SMS Sent (suppress-repeat)
- `4.2.1-dnc-call-list-prep`: Postgres - Fetch Callable Leads, Postgres - Mark call_dnc = true
- `4.2.2-dialer-trigger-outcome-webhook`: Postgres - Mark Call Queued, Postgres - Idempotency Check, Postgres - Write event_id (before processing), Postgres - Update Call Outcome, Postgres - Mark Event Processed
- `4.3.1-Waha-WhatsApp-Reply-Tracking`: ONE-TIME SETUP - Add Reply Tracking Columns, Find Client By Phone, 4.3.1.3 - Update last_reply_channel/at
- `4.3.2-LinkedIn-Reply-Check-Polling`: ONE-TIME SETUP - Create Tables/Columns, Check Already Processed, Match Lead (profile_url strong, name weak), 4.3.2.4 - Update Reply Tracking + Suppress, Insert communication_events (matched), Mark Processed (matched), Insert communication_events (unmatched), Mark Processed (unmatched)
- `4.3.3-Reply-Merge-Nurture-Suppression`: Log Invalid Reply Signal, Resolve client_id, Insert communication_events, Update clients_master (reply + suppress), Log Unmatched Reply, [Manual] Schema Setup - run once
</details>

<details>
<summary>Phase 5 (5 nodes across 2 files)</summary>

- `5.1.1-BANT-MEDDIC-Extraction`: Log Invalid Input, Insert qualification_records
- `5.1.2-Write-Qualification-To-Odoo`: Fetch Record + odoo_lead_id, Log Missing Lead Link, Log Odoo Write Failure
</details>

<details>
<summary>Phase 6 (33 nodes across 9 files)</summary>

- `6.1.1-Account-Health-Snapshot-Rollup`: Get Active Accounts, Last-Contact Data Pull, Write clients_master.health_score, Log Low-Health Account for Review
- `6.2.1-Adoption-Checklist-Auto-Create`: Check Not Already Created, Log Task-Create Failure, Mark Checklist Created
- `6.2.2-Milestone-Missed-Alert`: Get Clients With Active Projects
- `6.3.1-Support-Ticketing-Wiring`: Attempt Client Match, Increment support_ticket_count, Log Unmatched Ticket
- `6.4.1-Upsell-Crosssell-Trigger`: Get Candidate Accounts, Log Activity-Create Failure
- `6.5-churn-winback`: Fetch Churn-Risk Clients Due for Next Touch, Postgres - Mark Win-back Step Sent
- `6.6-nps-feedback`: Fetch Active Clients Due for Survey, Postgres - Mark Survey Sent, Postgres - Insert NPS Response, Postgres - Flag Promoter
- `6.7-case-studies`: Fetch Un-Asked Promoters, Postgres - Mark Ask Sent, Postgres - Insert Draft Case Study
- `6.8-referral-program`: Fetch Promoters Without Referral Link, Postgres - Insert Referral Record, Fetch Referrals with Closed-Won Conversion, Postgres - Mark Reward Pending
- `6.9-advocacy`: Fetch Advocate Candidates
</details>

<details>
<summary>Phase 7 (1 node) + Error Handler (1 node)</summary>

- `7.2-list-refresh`: Postgres - Refresh list_segment Tags
- `0.0-error-handler`: Log to automation_errors
</details>

---

## SMTP (Postal) — 27 nodes, 15 files

`1.2-seo-automation` (Send Weekly SEO Report), `1.4-inbound-form-qualification` (Send Auto-Response), `2.1-multichannel-outreach` (Send Outreach Email), `2.2-nurture-sequence` (Send Nurture Email), `2.4-proposal-generation` (Send Proposal Email), `2.6-invoice-payment` (Send Invoice Email, Send Receipt Email), `2.7-client-onboarding` (Send Welcome Email), `2.8-delivery-reporting` (Send Weekly Report Email), `2.9-renewal-revenue-ops` (Send Renewal Reminder Email, Send Dunning Email), `6.2.2-Milestone-Missed-Alert` (Email Alert), `6.5-churn-winback` (Send Win-back Email), `6.6-nps-feedback` (Send NPS Survey Email), `6.7-case-studies` (Send Testimonial-Ask Email), `6.8-referral-program` (Send Referral Ask Email).

## HTTP Basic Auth — 9 nodes, 4 files

- **Nextcloud WebDAV** (7 nodes): `2.4-proposal-generation` (Upload PDF, Create Public Share Link), `2.7-client-onboarding` (Create Client Folder, Create Client Share Link) — 4 nodes; merged-funnel file has 4 more of the same (already counted once here per source module).
- **Odoo API** (2 nodes): `0.0-error-handler` (Odoo Discuss - Failure Alert), plus any Discuss-alert node elsewhere still using `httpBasicAuth` credential type instead of env-var header auth — cross-check during import since most Discuss alerts use `$env.ODOO_URL` + header auth, not a stored credential.

## Slack API — 1 node, 1 file

- `6.3.1-Support-Ticketing-Wiring`: Slack Trigger - New Ticket Message — **only needed if you're routing support tickets through Slack.** If using something else (Chatwoot, Linear directly), this node/credential isn't needed — flag it during F6 sign-off.

---

## Note

This checklist was generated by scanning the actual patched files (post F0-F2), so it reflects what's really in each workflow right now, not what a README claims. Re-run the same scan after any future edit to catch new nodes before deployment — that's the "one-command credential audit" step referenced in the original fix plan (F4.3).
