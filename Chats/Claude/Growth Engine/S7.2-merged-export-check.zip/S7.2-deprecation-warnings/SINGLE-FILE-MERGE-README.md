# growth-engine-FULL-FUNNEL-merged.json

> ## ⚠️ STALE AS OF STAR-TOPOLOGY MIGRATION (S7.2 flag) — DO NOT IMPORT YET
> This 161-node single-canvas export **collapses every `Execute Workflow` → `Execute Workflow Trigger` pair into a direct connection**, by design (see "What changed" below). That is the exact opposite of star topology — it hard-bakes the module-to-module mesh into one flow with no Hub at all. Importing this file bypasses the Hub-Dispatcher entirely, no matter how far the star-topology rewiring has progressed in the 14 separate module files.
> **Deeper issue, not just staleness:** even after S0–S7 are fully done, this single-canvas merge concept is fundamentally at odds with the star topology's design goal (one Hub deciding what runs next, spokes that don't know about each other). Collapsing everything onto one canvas re-introduces direct spoke-to-spoke wiring by construction. Recommend retiring this artifact rather than regenerating it — see the S7.2 report for the reasoning.

All 14 modules combined into **one workflow, one canvas, 161 nodes**. Import this
single file (n8n → Import from File) and the entire Marketing + Sales funnel exists
as one flow — no separate imports, no ID wiring needed.

## What changed vs. the 14 separate files

- Every node renamed with a `[1.1]` / `[2.6]` etc. prefix so nothing collides.
- Every `Execute Workflow` → `Execute Workflow Trigger` pair was **collapsed into a
  direct connection** (the calling module now flows straight into the called
  module's first node — no sub-workflow hop).
- The step that used to run *after* an Execute Workflow call (mostly the "Odoo
  Discuss - Notify" alerts) now fires **in parallel** with the sub-flow instead of
  strictly after it finishes. In the 14-file version the Execute Workflow node waited
  for the sub-workflow to complete before notifying; collapsing to one canvas removes
  that wait, so notify and the next stage now start at the same time. Functionally
  near-identical, just not sequential anymore.
- **One exception, not something I invented:** `1.5 → 2.5 (Contract E-sign)` was
  never a real hand-off — 2.5 is actually started by a client clicking the
  "Accept Proposal" link (a webhook), not by 1.5 calling it. So that Execute Workflow
  node was dropped and 1.5 just fires its Discuss notify there; 2.5 still runs fine,
  triggered independently by its own webhook, same as before.

## Trade-off, honestly

One 161-node canvas is harder to read, harder to debug (one crashed node can be
tougher to spot), and any edit means opening this whole thing instead of one small
module. The 14-file version is still what I'd actually run in production — this is
for the "paste once, see everything" case.

## Import

n8n → Workflows → **Import from File** → select `growth-engine-FULL-FUNNEL-merged.json`.
After import, still needed (same as before, not automatable): fill in the
`REPLACE_WITH_CREDENTIAL_ID` credential references and the env vars in the top-level
`README.md`, then activate the workflow.
