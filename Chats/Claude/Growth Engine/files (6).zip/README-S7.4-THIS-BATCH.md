# S7.4 — Full End-to-End Regression Test (this batch)

Scope: only step **S7.4** of `N8N-Star-Topology-Integration-Plan.md`. This
batch does not build S7.1–S7.3 or S7.5–S7.6 — just the regression test.

## Ground truth check first — the plan's checkbox tracker is stale

Before building the test I grepped every real `workflow.json` in your repo
(canonical `growth-engine-automation/` tree + all the individual S-batch
zips) for actual `Report to Hub` nodes, instead of trusting the plan
document's checklist — every `[ ]` in `N8N-Star-Topology-Integration-Plan.md`
is still unchecked, but the JSON shows real progress **and** a few gaps the
tracker doesn't mention. This is exactly the kind of drift the original
audit flagged (§1.1), so here's the actual state as of this batch:

| Module | Reports to Hub? | Triggered by Hub? | Note |
|---|---|---|---|
| 1.3 Website Lead Capture | ✅ `lead.captured` | n/a (Typebot webhook — correct) | |
| 1.4 Inbound Form Qualification | ✅ `lead.qualified` | n/a (own webhook — correct) | |
| 1.5 Central CRM Sync | ⚠️ dynamic event_type | n/a (still on `Every 5 Min` schedule) | Legacy version still present — expected per the plan's own rollback note on S3.3 being highest-risk |
| 2.1 Multi-channel Outreach | — | ✅ Dispatcher-triggered | Doesn't report onward yet (no next hop defined) |
| 2.3 Booking Sync | ✅ `lead.booked` | n/a (Cal.com webhook — correct) | |
| 2.4 Proposal Generation | ✅ `proposal.sent` | ❌ **still `From Module 1.5` directly** | Output migrated, input still a direct mesh link — this is a real gap, not covered by any closed S-step |
| 2.5 Contract + E-sign | ✅ `contract.signed` | n/a (e-sign webhook — correct) | |
| 2.6 Invoice + Payment | ❌ **no Report to Hub node at all** | ❌ **still `From Module 2.5` directly** | S4.5 not actually done despite what any tracker says |
| 2.7 Client Onboarding | ✅ `client.onboarded` | ✅ Dispatcher-triggered | Reference implementation — both sides done correctly |
| 2.9 Renewal + Revenue Ops | ✅ `renewal.due`, `payment.failed` | n/a (own schedule — correct) | Reports fine, but nothing subscribes yet (no Dispatcher branch — S6 scope) |
| 4.x (all), 5.1.1/5.1.2, 6.x (all), 7.1/7.2 | ❌ none report to Hub | ❌ none triggered by Hub | Untouched — still the original independent-polling/mesh design |
| 5.1.1 → 5.1.2 | — | — | Still a literal `Execute Workflow` mesh link between them, same pattern §0 was written to eliminate |

**Practical consequence for S7.4:** the plan's literal ask — "run a
synthetic lead from Typebot capture through onboarding through a simulated
renewal, confirm every hop routes through `funnel_events`" — cannot fully
pass yet, because roughly half the chain (2.6, all of Phase 4/5/6/7) has no
Hub reporting to check. Building a test that fakes those hops as green would
be worse than not testing them. So this batch builds a regression test that:

1. **Actually drives and verifies every hop that's really wired today**
   (1.3 → 1.4 → 2.3 → 2.4 → 2.5 → 2.7 → 2.9×2 — 8 hops), live, through
   `funnel_events`.
2. **Reports the unwired hops as known gaps**, by name, with the reason,
   pulled from the same source-of-truth list — not silently skipped.

That gives you a real pass/fail signal today, and the same test becomes the
full S7.4 as the plan describes it once S4.5, S5, and S6 are actually
migrated — no rebuild needed, the gap list just shrinks to zero.

## What `workflow.json` does

**`S7.4 - Full E2E Regression Test`** (15 nodes, manual trigger):

1. **Build Test Context** — generates `test_run_id` and a sentinel
   `test_client_id` in the `900,000,000+` range (guaranteed to never collide
   with a real `clients_master.id`, and trivial to exclude from the S7.3
   Metabase dashboard with `client_id < 900000000`).
2. **Define Expected Hop Chain** — the 9-row table above, encoded as data
   (8 wired + 1 known gap: `2.6 payment.received`).
3. **Only Wired Hops (Live-Testable)** → **Loop Over Wired Hops** →
   **Report to Hub (Simulated)** — calls the real Hub-Intake sub-workflow
   for each wired hop in order, with `source_module` suffixed
   `(S7.4-simulated)` so these rows are unambiguous in `funnel_events` /
   the Metabase dashboard.
4. **Wait for Dispatcher Poll Cycle** (3 min, > the Dispatcher's 2-min
   interval) → **Fetch Test Client Funnel Events**.
5. **Verify Chain & Build Report** — per hop: fail if no row landed, fail
   if still `pending`/`dispatched` after the wait, fail if `status='failed'`
   (with the error), pass if `done` — including the *expected* fall-through
   to `flagged_events` for `renewal.due`/`payment.failed` (no Phase 6
   subscriber yet — that's correct behaviour, not a bug, per
   `S0-EVENT-TYPE-TAXONOMY.md`). Known gaps are appended separately so they
   never get counted as either a pass or a fail.
6. **Cleanup Enabled?** — deletes the synthetic `funnel_events` rows by
   default (keeps the dashboard clean); flip `cleanup_after_test` to
   `false` in step 1 if you want a run to stay visible on the dashboard as
   a live demo.
7. **All Wired Hops Passed?** → Odoo Discuss alert, pass or fail, same
   `growth-engine-alerts` channel and node shape as Hub-Dispatcher's
   flagged-event alert (S2.4).

## What this test deliberately does **not** do

It calls Hub-Intake directly to simulate each spoke's own "Report to Hub"
node, instead of firing the real external triggers (Typebot form submit,
Cal.com booking, Documenso signature, payment gateway webhook). Those need
live signed/HMAC'd payloads (see the `3.0.1.x` HMAC patch files) that a test
harness can't safely fabricate, and firing them for real would create real
Odoo leads, real Nextcloud folders, and send real emails. So:

- **This validates the Hub layer** — routing, ordering, no silent drops,
  dashboard visibility — for everything currently wired.
- **It does not re-verify each spoke's internal Odoo/CRM logic** — that's
  already covered by each batch's own test step (S3.4, S4.9/S4.10, S5.6,
  S6.13).
- **Firing the real external webhooks in a staging n8n + Odoo instance is
  still a manual pass** before you can call the plan's original S7.4 fully
  done. Do this in staging only — never point synthetic test data at
  production Odoo/Nextcloud/Postal.

## What's NOT done (by design — S7.4 only)

- S7.1 (grep for zero remaining direct `Execute Workflow` links) — this
  batch's own audit above already found two that S7.1 will need to catch:
  `2.4`'s input and `2.6`'s input/output. Worth running S7.1 next.
- S7.2, S7.3, S7.5, S7.6 — untouched.
- S4.5 (2.6), S5 (4.3.x/5.1.x), S6 (6.x/7.1) migrations themselves — this
  batch only *detects and reports* those gaps, it doesn't close them.

## Test

1. Import `workflow.json`, fill in `REPLACE_WITH_0.0_HUB_INTAKE_WORKFLOW_ID`
   and `REPLACE_WITH_0.0_ERROR_HANDLER_WORKFLOW_ID` (same one-place
   convention as every other spoke in this migration) and
   `$env.ODOO_DISCUSS_WEBHOOK_URL`.
2. Run manually. Expect: 8/8 wired hops pass, 1 known gap
   (`2.6 payment.received`) reported, Odoo Discuss alert fires — **passing**
   overall (a "known gap" isn't a failure; a hop that's wired but broken is).
3. Confirm the 8 synthetic rows appear and disappear from `funnel_events`
   (cleanup runs by default) and, if you've built S7.3's dashboard already,
   confirm they briefly showed up there filtered correctly by
   `source_module LIKE '%(S7.4-simulated)%'`.
4. Re-run this same workflow unmodified after each of S4.5/S5/S6 lands —
   the gap list should shrink by exactly the hops that get wired, with zero
   changes needed here.
