# Phase 8a — Foundation (Done)

Implementation Plan ke Section 6 wale **8a — Foundation** tasks complete ho gaye. Ye batata hai exactly kya badla, taaki import se pehle review kar sako.

---

## 1. Migration file rewrite ho gayi — `01-PHASE-8-MIGRATIONS.sql`

Pehli baar jo migration file di thi usme column names **invented the**, aapke asli 8.1/8.2/8.3 workflow files ke saath match nahi karte the (maine ab har Postgres node ki actual query check ki hai). Ye v2 hai — sahi, workflows ke saath verified match:

| Table | Kis engine ke liye | Kya naya |
|---|---|---|
| `campaigns` | Sabke liye (master registry) | wahi hai jo pehle tha — slug, engine, status, config JSONB, channels |
| `contests` | **naya** — 8.1 | pehle missing thi; 8.1 ka `contest_id` isi ko reference karta hai |
| `contest_entries` | 8.1 | columns fix kiye: `entry_channel`, `proof_url`, `verified`, `is_winner` (pehle wrong schema di thi) |
| `referral_codes` | **naya** — 8.2 | pehle missing thi; 8.2 referral-code resolve isi se hota hai |
| `referral_ledger` | 8.2 | columns fix kiye: `referral_code_id`, `referred_client_id`, `stage`, `reward_status` (pehle wrong schema di thi) |
| `audit_requests` | 8.3 | columns fix kiye: `audit_type`, `input_url`, `score_breakdown` (pehle wrong schema di thi) |
| `ugc_submissions`, `community_members`, `signal_leads` | 8.4/8.5/8.6 (reserved, abhi tak koi workflow use nahi karta) | waisa hi hai |

**Zaroori:** agar aapne pehli wali migration file already run kar li hai, to naye tables extra ban jaayenge (koi conflict nahi, dono `CREATE TABLE IF NOT EXISTS` hain) — bas purani `contest_entries`/`referral_ledger`/`audit_requests` (agar bani thi) manually drop karke re-run karna better hai, kyunki column names badle hain.

File ke aakhir me **commented-out example seed rows** bhi diye hain — 2 contests + 1 referral campaign ek saath 'active' — dikhane ke liye multi-campaign kaise dikhta hai DB level pe.

---

## 2. 8.1 Reward/Contest Engine — kya change hua

**Naye nodes (5):**
- `Postgres - Lookup Contest Config` — entry ke turant baad, `contest_id` se `contests` table check karta hai
- `IF - Contest Active` — agar contest `active` nahi hai to entry reject
- `Respond - Campaign Not Active` — closed contest ka response
- `Postgres - Lookup Contest Config (Winner Run)` — winner-selection manual trigger me bhi validate karta hai
- `IF - Contest Selection Valid` + `Odoo Discuss - Invalid Contest Selected` — agar galat contest_id daala to winner-selection safely abort ho jaata hai, koi crash nahi

**Kya dynamic hua:**
- Fraud threshold ab per-contest hai (`contests.config.fraud_threshold`), default 50 — pehle globally hardcoded 50 tha
- Winner-eligible-entries query bhi ab wahi per-contest threshold use karti hai

**Result:** ab is ek hi workflow se **N contests ek saath** chal sakte hain — bas `contests` table me N rows daalo, har ek apna fraud threshold rakh sakta hai.

---

## 3. 8.2 Referral Engine — kya change hua

**Naye nodes (4):**
- `IF - Campaign Active` — referral code resolve hone ke baad check karta hai ki uska campaign abhi active hai ya nahi
- `Respond - Campaign Not Active` — inactive campaign ka response
- Do naye Postgres lookup nodes (`Meeting Booked` aur `Converted` stages ke liye) jo purane hardcoded `Set - Reward Config (EDIT ME)` node ki jagah lete hain

**Kya dynamic hua:**
- `Postgres - Resolve Referral Code` ab `campaigns` table se JOIN karta hai
- Reward amounts (`meeting_booked_reward`, `converted_reward`) ab har campaign ke apne `campaigns.config` se aate hain, fallback $50/$250 agar config me na ho
- Purana hardcoded `Set - Reward Config` node poora hata diya — ab koi bhi ek jagah "EDIT ME" nahi karni padegi, sab DB-driven hai

**Result:** ab **multiple referral campaigns** (jaise "general referral" + "Diwali special referral") ek saath, alag-alag reward amounts ke saath, isi ek workflow se chal sakte hain.

---

## 4. 8.3 Free Audit Engine — kya change hua

**Naya node (1):**
- `Postgres - Lookup Active Campaign (Optional)` — entry input se optional `campaign_slug` leta hai

**Kya dynamic hua:**
- Webhook ab optional `campaign_slug` field accept karta hai — agar diya hai to us campaign se link hoga, nahi diya to bhi normal kaam karega (organic/direct audit, `campaign_id = NULL`)
- `audit_requests` insert me ab `campaign_id` bhi save hota hai

**Result:** alag-alag landing pages (jaise "Free Website Audit" vs "Free AI-Readiness Score") ek hi webhook/workflow use kar sakti hain, bas apna `campaign_slug` bhej ke — reporting me alag-alag dikhega.

---

## 5. Validation

Teeno files programmatically check ki gayi hain: JSON valid parse hota hai, koi duplicate node ID nahi, koi dangling connection nahi, har node reachable hai. Sab ✅.

---

## 6. Agla step (Phase 8b se match karta hai)

1. `01-PHASE-8-MIGRATIONS.sql` Postgres par run karo
2. In teeno files ko n8n me import karo (Hub-Intake pehle se ban chuka ho, uska ID `REPLACE_WITH_0.0_HUB_INTAKE_WORKFLOW_ID` har jagah bharo — ye ab 8.1 me 2 jagah, 8.2 me 3 jagah, 8.3 me 1 jagah hai)
3. Test karo: `campaigns` table me ek dummy active row daal ke, webhook test karo
4. WhatsApp/Telegram/Email NoOp nodes wire karo apne real credentials se
5. Hub-Dispatcher me naye branches add karo (Implementation Plan Section 2)

Implementation Plan ke Progress Tracker me Section 8a ke sab 4 rows ✅ kar sakte ho ab.
