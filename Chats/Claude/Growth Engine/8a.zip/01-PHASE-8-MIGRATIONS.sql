-- ============================================================
-- Phase 8 — Growth Hacking Engines: Postgres migrations
-- v2 (Phase 8a) — corrected to match the ACTUAL columns used
-- inside the built 8.1/8.2/8.3 workflow.json files (checked
-- node-by-node against the SQL each Postgres node runs).
-- v1 of this file had invented column names that didn't match
-- the workflows — this replaces it. Safe to run fresh; every
-- statement is IF NOT EXISTS.
--
-- Run once, in this order, BEFORE importing/activating any
-- 8.x workflow.json file into n8n. Run on the SAME Postgres
-- database where v6's 00-MASTER-MIGRATIONS.sql already ran
-- (Phase 8 tables reference clients_master).
-- ============================================================

-- ------------------------------------------------------------
-- 0. Campaign control table — the master registry.
--    Every engine-specific table below (contests, referral_codes,
--    audit_requests, ...) links back to this via campaign_id,
--    so ANY engine can run multiple simultaneous campaigns and
--    8.7 Dashboard can roll all of them up in one place.
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS campaigns (
  id SERIAL PRIMARY KEY,
  campaign_slug TEXT UNIQUE NOT NULL,      -- e.g. 'diwali-referral-2026', 'nivy-top-100'
  engine TEXT NOT NULL,                    -- '8.1', '8.2', '8.3', '8.4', '8.5', '8.6'
  campaign_type TEXT,                      -- e.g. 'contest', 'referral', 'free_audit', 'ugc', 'community'
  status TEXT DEFAULT 'draft',             -- draft / active / paused / ended
  config JSONB NOT NULL DEFAULT '{}'::jsonb, -- reward amounts, fraud_threshold, copy, etc. — engine reads this at runtime
  channels TEXT[] DEFAULT '{}',            -- e.g. ARRAY['whatsapp','telegram','email']
  starts_at TIMESTAMP,
  ends_at TIMESTAMP,
  created_at TIMESTAMP DEFAULT now(),
  updated_at TIMESTAMP DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_campaigns_slug_status ON campaigns (campaign_slug, status);
CREATE INDEX IF NOT EXISTS idx_campaigns_engine_status ON campaigns (engine, status);

-- ------------------------------------------------------------
-- 1. Module 8.1 — Reward / Contest Engine
--    `contests` = one row per specific contest (config.fraud_threshold
--    overrides the default-50 fraud gate per contest).
--    `contest_entries` columns match exactly what the workflow's
--    Postgres nodes insert/update/select.
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS contests (
  id SERIAL PRIMARY KEY,
  campaign_id INTEGER REFERENCES campaigns(id),
  name TEXT,
  status TEXT DEFAULT 'draft',             -- draft / active / ended
  config JSONB NOT NULL DEFAULT '{}'::jsonb, -- e.g. {"fraud_threshold": 50, "reward_structure": "...", "required_action": "..."}
  starts_at TIMESTAMP,
  ends_at TIMESTAMP,
  created_at TIMESTAMP DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_contests_status ON contests (status);

CREATE TABLE IF NOT EXISTS contest_entries (
  id SERIAL PRIMARY KEY,
  contest_id INTEGER REFERENCES contests(id),
  client_id INTEGER REFERENCES clients_master(id),
  entry_channel TEXT,
  proof_url TEXT,
  fraud_score INTEGER DEFAULT 0,
  verified BOOLEAN DEFAULT false,
  is_winner BOOLEAN DEFAULT false,
  submitted_at TIMESTAMP DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_contest_entries_contest ON contest_entries (contest_id);

-- ------------------------------------------------------------
-- 2. Module 8.2 — Referral Engine (universal / multi-campaign)
--    NOTE: separate from v6's `referrals` table (added for the
--    6.8 Client Referral Program) — that one is single-purpose
--    client-to-client; these two are campaign-driven and reused
--    across any referral push (multiple referral campaigns can
--    be active at once, each with its own code prefix + rewards).
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS referral_codes (
  id SERIAL PRIMARY KEY,
  campaign_id INTEGER REFERENCES campaigns(id),
  code TEXT UNIQUE NOT NULL,
  referrer_client_id INTEGER REFERENCES clients_master(id),
  referrer_type TEXT DEFAULT 'client',     -- client / partner / ambassador
  created_at TIMESTAMP DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_referral_codes_code ON referral_codes (code);
CREATE INDEX IF NOT EXISTS idx_referral_codes_campaign ON referral_codes (campaign_id);

CREATE TABLE IF NOT EXISTS referral_ledger (
  id SERIAL PRIMARY KEY,
  referral_code_id INTEGER REFERENCES referral_codes(id),
  referred_client_id INTEGER REFERENCES clients_master(id),
  stage TEXT DEFAULT 'submitted',          -- submitted / meeting_booked / converted / paid
  reward_amount NUMERIC DEFAULT 0,
  reward_status TEXT DEFAULT 'pending',    -- pending / approved / paid
  created_at TIMESTAMP DEFAULT now(),
  updated_at TIMESTAMP DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_referral_ledger_code ON referral_ledger (referral_code_id);
CREATE INDEX IF NOT EXISTS idx_referral_ledger_referred ON referral_ledger (referred_client_id);

-- ------------------------------------------------------------
-- 3. Module 8.3 — Free-Value Engine (audit sub-type built first;
--    other free-value sub-types — free toolkit, free micro-tool,
--    free design/video/website — can reuse this same table with
--    a different audit_type value + a different campaigns row).
--    campaign_id is NULLABLE — direct/organic audit requests
--    (no campaign_slug on the form) are valid and expected.
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS audit_requests (
  id SERIAL PRIMARY KEY,
  campaign_id INTEGER REFERENCES campaigns(id),   -- NULL = organic/direct, not tied to a campaign
  client_id INTEGER REFERENCES clients_master(id),
  audit_type TEXT,
  input_url TEXT,
  score INTEGER,
  score_breakdown JSONB,
  completed_at TIMESTAMP DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_audit_requests_campaign ON audit_requests (campaign_id);

-- ------------------------------------------------------------
-- 4. Module 8.4 — UGC / Share Engine (not built yet — table
--    shape reserved so the migration file stays complete/ahead
--    of Phase 8c; safe to run now, no workflow depends on it yet)
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS ugc_submissions (
  id SERIAL PRIMARY KEY,
  campaign_id INTEGER REFERENCES campaigns(id),
  client_id INTEGER REFERENCES clients_master(id),
  proof_url TEXT,
  verification_status TEXT DEFAULT 'pending', -- pending / verified / rejected
  points_awarded INTEGER DEFAULT 0,
  created_at TIMESTAMP DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_ugc_submissions_campaign ON ugc_submissions (campaign_id);

-- ------------------------------------------------------------
-- 5. Module 8.5 — Community Engine (not built yet — reserved)
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS community_members (
  id SERIAL PRIMARY KEY,
  campaign_id INTEGER REFERENCES campaigns(id),
  client_id INTEGER REFERENCES clients_master(id),
  role TEXT DEFAULT 'member',              -- member / moderator / partner
  joined_at TIMESTAMP DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_community_members_campaign ON community_members (campaign_id);

-- ------------------------------------------------------------
-- 6. Module 8.6 — Signal-Based Outreach Engine (not built yet —
--    reserved). Not campaign_id-scoped by design: signals are
--    continuous, not tied to one campaign window.
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS signal_leads (
  id SERIAL PRIMARY KEY,
  signal_type TEXT,                        -- 'hiring' / 'funding' / 'news' / 'reactivation'
  raw_signal JSONB,
  ai_score INTEGER,
  outreach_status TEXT DEFAULT 'new',      -- new / queued / sent / replied / ignored
  created_at TIMESTAMP DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_signal_leads_status ON signal_leads (outreach_status);

-- ------------------------------------------------------------
-- 7. Module 8.7 — Dashboard (no new tables; reporting views only,
--    uncomment/extend once 8.1-8.3 have live data)
-- ------------------------------------------------------------
-- CREATE OR REPLACE VIEW growth_campaign_performance AS
-- SELECT c.id, c.campaign_slug, c.engine, c.status,
--        COUNT(fe.id) AS total_events
-- FROM campaigns c
-- LEFT JOIN funnel_events fe ON (fe.payload->>'campaign_id')::int = c.id
-- GROUP BY c.id;

-- ============================================================
-- 8. Example seed rows — ek reference ke liye, DELETE karo ya
--    apne real campaigns se replace karo. Ye 3 rows dikhate hain
--    ki multi-campaign kaise ek saath chalta hai (Section 3 of
--    the Implementation Plan) — 2 alag 8.1 contests + 1 8.2
--    referral campaign, teeno 'active', ek saath.
-- ============================================================
-- INSERT INTO campaigns (campaign_slug, engine, campaign_type, status, config, channels)
-- VALUES
--   ('reel-contest-q1', '8.1', 'contest', 'active', '{"fraud_threshold": 50}'::jsonb, ARRAY['instagram','whatsapp']),
--   ('nivy-top-100', '8.1', 'contest', 'active', '{"fraud_threshold": 40}'::jsonb, ARRAY['email','linkedin']),
--   ('general-referral', '8.2', 'referral', 'active', '{"meeting_booked_reward": 50, "converted_reward": 250, "currency": "USD"}'::jsonb, ARRAY['whatsapp','telegram','email']);
--
-- INSERT INTO contests (campaign_id, name, status, config)
-- SELECT id, 'Reel Contest Q1', 'active', config FROM campaigns WHERE campaign_slug = 'reel-contest-q1';
-- INSERT INTO contests (campaign_id, name, status, config)
-- SELECT id, 'Nivy Top 100', 'active', config FROM campaigns WHERE campaign_slug = 'nivy-top-100';
--
-- INSERT INTO referral_codes (campaign_id, code, referrer_type)
-- SELECT id, 'GEN-DEMO01', 'client' FROM campaigns WHERE campaign_slug = 'general-referral';

-- ============================================================
-- End of Phase 8a migrations.
-- Safe to re-run (all IF NOT EXISTS). Run this on the same
-- Postgres instance/database that v6's master-migrations
-- already ran on — Phase 8 tables reference clients_master
-- and share funnel_events/flagged_events with the rest of
-- the star topology.
-- ============================================================
