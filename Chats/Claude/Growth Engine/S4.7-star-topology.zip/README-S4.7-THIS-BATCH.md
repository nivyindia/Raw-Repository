# S4.7 — Migrate 2.8 / 2.9 to Star Topology (this batch)

Scope: only step **S4.7** of the plan (`N8N-Star-Topology-Integration-Plan.md`).
Built on top of your existing `S0-S3-hub-and-phase1-migration.zip` — same
Hub-Intake schema (`event_type`, `client_id`, `odoo_lead_id`, `source_module`,
`payload`), same node-naming and parallel-branch pattern used in 1.3/1.4.

## What changed

### `2.9-renewal-revenue-ops/workflow.json` — 16 nodes → 18 nodes
- **`Report to Hub (renewal.due)`** — new node, runs in parallel with
  `Odoo Discuss - Renewal Reminder Alert` off `Postgres - Mark Renewal
  Reminder Sent`. Sends `event_type: renewal.due`, `payload: {company,
  renewal_date}`.
- **`Report to Hub (payment.failed)`** — new node, runs in parallel with
  `Send Dunning Email (Postal SMTP)` off `Postgres - Mark Payment Failed`
  (which already has `RETURNING *`, so `id`/`odoo_lead_id` are on `$json`
  directly — no extra lookup needed). Sends `event_type: payment.failed`,
  `payload: {company, dunning_attempts, failure_reason, transaction_id}`.
- `settings.errorWorkflow` added — same placeholder convention as every
  other migrated spoke.

### `2.8-delivery-reporting/workflow.json` — unchanged except settings
- No new event: the plan's S4.7 line only names `renewal.due` and
  `payment.failed`, and both belong to 2.9's flows — 2.8's weekly
  report-send has no matching transition (same "leave as-is" treatment as
  1.1/1.2 in the earlier batch). Only `settings.errorWorkflow` was added,
  for consistency with every other spoke in the migration.
- Reasoning is written into `docs/S0-EVENT-TYPE-TAXONOMY.md` so it doesn't
  get silently "fixed" by a future session.

### `docs/S0-EVENT-TYPE-TAXONOMY.md`
- `renewal.due` / `payment.failed` rows split out and marked done (reported
  by 2.9), still **not wired in the Dispatcher** — nothing subscribes yet
  because Phase 6 churn/win-back (S6.3) hasn't been migrated. They fall
  through to `flagged_events` for now, exactly like `lead.captured` did in
  the S3 batch — expected, not a bug.

## What's NOT done (by design — S4.7 only)

- S4.1–S4.6 (2.1, 2.3, 2.4, 2.5, 2.6, 2.7) — the other 7 Phase 2 modules —
  still open.
- S4.8 end-to-end test not run.
- Hub-Dispatcher's Switch node still has no branch for `renewal.due` /
  `payment.failed` — harmless today (falls to `flagged_events`), but will
  need one when S6.3 (6.5 Churn Win-back) is built, per the plan's own note
  that Dispatcher wiring for these is S6 scope, not S4.
- Real workflow IDs (`REPLACE_WITH_0.0_HUB_INTAKE_WORKFLOW_ID`,
  `REPLACE_WITH_0.0_ERROR_HANDLER_WORKFLOW_ID`) still placeholders — same
  one-place convention as the rest of the migration.

## Test

1. Import updated 2.9, trigger `Fetch Renewals Due (30 days)` manually (or
   wait for the 7AM run) — confirm a `renewal.due` row lands in
   `funnel_events` with `status='pending'` and the Dispatcher (once IDs are
   filled in) routes it to `flagged_events` since nothing subscribes yet.
2. POST a test payload to the `payment-failed` webhook — confirm both the
   dunning email fires **and** a `payment.failed` row lands in
   `funnel_events`.
