# F6.1 — Sign-off Needed: Support Ticketing Provider

**Module affected:** `6.1.1-Account-Health-Snapshot-Rollup` (feeds `6.2.2-Milestone-Missed-Alert` and `6.4.1-Upsell-Crosssell-Trigger`, which both consume the health score this computes).

**Current state:** the `MOCK_TICKETING_PROVIDER - Tickets Pull` node is disabled. Account health score is being computed **without ticket-volume data** — it's real, but partial. Every score this workflow writes right now should be read as directional, not final, until this is resolved.

**What's needed from you:** pick a real ticketing provider, so this node can be swapped from mock to a real API call.

**Options** (per `6.1.1`'s original README, which flagged this the same way):

| Option | What changes |
|---|---|
| **Chatwoot** | Already referenced elsewhere in the stack docs as a candidate — if you're already using or planning Chatwoot for support, this is the path of least resistance. |
| **Linear** | Module `6.3.1-Support-Ticketing-Wiring` already creates tickets in Linear (`Linear Ticket-Create` node) — if that's your actual support tool, 6.1.1 should pull from the same place 6.3.1 writes to, so the two modules agree on ticket counts. |
| **Something else** | Tell me and I'll wire it. |

**Once you decide**, tell me and I'll: replace the mock node with a real HTTP call to that provider's API, re-enable it, and remove the "scores are partial" caveat from the `Health-Score Compute` node's notes.

---

## Other open items surfaced during the audit (for the same kind of sign-off, lower priority)

| Item | Module | What's needed |
|---|---|---|
| `referral_code_used` isn't populated by any workflow yet | 6.8 Referral Program | Needs a small patch in 1.3/1.4 to capture `?ref=<code>` from the inbound lead source. Say the word and I'll patch it. |
| `advocate_flag` isn't auto-set by any workflow yet | 6.9 Advocacy | Currently set manually after human review — tell me if you want an auto-set-on-approval step instead. |
| Slack vs. other tool for support tickets | 6.3.1 Support Ticketing Wiring | The workflow currently has a Slack trigger node wired in. If you're not using Slack for this, tell me which tool and I'll swap the trigger. |
