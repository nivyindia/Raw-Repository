# Phase A gap-fill (5.1.2, 6.6, 7.2) + client.won decision + S7a.1 audit

Continuation of `PHASE-0-RECONCILIATION-REPORT.md`. Starting point was
`RECONCILED-star-topology-v2.zip` — confirmed against it directly (not
assumed from the chat export) that 5.1.2, 6.6, 7.2 were genuinely still
un-migrated (`___NOT-STAR-MIGRATED` folder suffix / `README-OLD-PRESTAR.md`
present), matching where the exported session's narrative left off.

## 1. What got built

### 5.1.2 — Write Qualification to Odoo → `qualification.written`
Added `Report to Hub` off the success path (`Write Failed?`'s false branch,
parallel to `Done - Write Confirmed`, doesn't block it). `client_id` comes
from the trigger item itself (`5.1.2 Trigger - From 5.1.1`) since the
in-between Postgres/code nodes don't carry it forward at top level;
`odoo_lead_id`/`framework`/`decision`/`assessed_at`/`assessed_by` come from
`Map Fields to Odoo Custom Fields` (the Odoo HTTP response afterward
overwrites `$json`, so that node is the last point those fields are still
directly on the item).

### 6.6 — NPS Survey + Routing → `nps.promoter_flagged`
Added `RETURNING *, (SELECT odoo_lead_id FROM clients_master WHERE id =
nps_responses.client_id) AS odoo_lead_id` to `Postgres - Insert NPS
Response` — it had `RETURNING *` already but `nps_responses` doesn't itself
store `odoo_lead_id`, so a correlated scalar subquery pulls it in without a
second DB round-trip. `Report to Hub` fires only off the **promoter branch**
(`Postgres - Flag Promoter`), parallel to `Respond 200 OK` — matches the
event name and the taxonomy's stated consumers (6.7, 6.8). The **detractor**
branch intentionally does not report to Hub — taxonomy only ever specified a
promoter-flag event; detractors stay on the existing internal Discuss alert.

### 7.2 — List Auto-Refresh → `list_segment.refreshed` ⚠️ pattern deviation, flagging explicitly
7.2 is a bulk, all-rows `UPDATE` with no `WHERE` — there's no single lead in
scope, so the usual `client_id`/`odoo_lead_id` shape doesn't fit. Rather than
force a fake per-lead shape, I sent `client_id: null, odoo_lead_id: null`
(Hub-Intake already supports this via `client_id ?? null`) with an aggregate
`payload.segment_counts`. Also added a `SELECT list_segment, count(*) ...
GROUP BY` after the `UPDATE` so there's something meaningful to report —
otherwise there was no output row at all to attach to the event. This is a
**new event type**, not in the plan's original S0.2 minimum set — added to
the taxonomy doc with its own note. Flagging this one specifically because
it's the one place this batch deviated from the established convention
rather than mechanically following it — worth a second look if it doesn't
sit right.

## 2. Hub-Dispatcher — `client.won → 2.7` decision: resolved (Option A)

The open decision flagged in `README-S4b-DISPATCHER-UPDATE.md` — I applied
the doc's own recommended **Option A**: removed the `client.won` Switch rule
and its `Execute Workflow - 2.7 Onboarding` node entirely. Onboarding now
fires **only** on `payment.received`. Reasoning: billing (2.6) now sits
between Won and Onboarded, so starting onboarding on `client.won` risks
onboarding a client before they've paid.

This changes production wiring behavior, so calling it out plainly rather
than burying it: **if unpaid/NET-30 onboarding is actually a real business
case for you, this is the wrong call — say so and I'll revert to Option B**
(keep both branches, add a duplicate-onboarding guard in 2.7 instead).
`1.5` still reports `client.won` regardless — that event just falls through
to `flagged_events` now instead of triggering anything, same as several
other already-unwired events.

Switch-node connections were **fully rebuilt**, not just had one entry
deleted — n8n Switch outputs are positional against the rules array, so
removing one rule without reindexing the rest would've silently mis-wired
`contract.signed`/`payment.received` to the wrong branches.

## 3. Taxonomy doc — refreshed

`docs/S0-EVENT-TYPE-TAXONOMY.md` now reflects the **actual current state**
of all 36 workflows, not just the S3/S4.4-S4.7 snapshot it was frozen at:
added `proposal.sent` and `health.scored` (built in the predecessor session
but never added to the table), added `qualification.written`,
`nps.promoter_flagged`, `list_segment.refreshed` (this batch), and updated
`client.won`'s row to reflect the Dispatcher branch removal.

## 4. S7a.1 grep audit — done, one real finding

Grepped all 36 `workflow.json` files for `executeWorkflow` nodes not
pointing at Hub-Intake. Result:

- **Expected, fine:** Hub-Dispatcher's 5 `Execute Workflow - 2.x` nodes
  (that's its entire job — Hub→spoke, not spoke→spoke).
- **🔴 One real violation found:** `4.2.1-dnc-call-list-prep` still has a
  direct `Execute Workflow - 4.2.2 Dialer Trigger` node — a genuine
  spoke→spoke link, exactly the pattern star-topology is meant to eliminate.
  Its own README even describes it as following "the 2.5→2.6 chaining
  pattern" — but that reference is now **stale**: 2.5→2.6 direct-chaining
  was deliberately removed during the conflict-merge (2.5 now reports
  `contract.signed` to the Hub instead). 4.2.1 was never updated to match.

**Not fixed in this batch** — out of scope for what was asked (Phase A was
5.1.2/6.6/7.2 specifically), and fixing it properly needs a decision on
what event_type a "call-list ready" hand-off should be (nothing in the
taxonomy currently covers it) plus confirming 4.2.2 has — or needs — its own
`Execute Workflow Trigger` entry point. Flagging it here so it doesn't get
silently missed; say the word if you want it done next.

## 5. Validation

All 36 `workflow.json` files across the final tree: JSON parses clean, no
duplicate node IDs, no dangling connections (checked programmatically, not
just eyeballed).

## 6. What's still open (unchanged from before this batch, restated for clarity)

- Phase 6 Dispatcher wiring: `health.scored` and `nps.promoter_flagged`
  branches — deliberately not wired yet, per taxonomy doc note.
- Merged reference file (`growth-engine-FULL-FUNNEL-merged.json`) — stale,
  needs regenerating from this final tree.
- S3.5, S4.9/S4.10, S6.13, S7.4 (end-to-end tests) and S7.3 (Metabase
  dashboard) — need a live n8n instance, can't be done from files.
- The 4.2.1→4.2.2 direct link found above.
