# S0.2 / S0.3 — `event_type` Taxonomy (living reference)

One row per cross-module hand-off, current or planned. "Wired" = a Hub-Dispatcher
Switch branch actually exists for it as of this batch. Everything else falls
through to `flagged_events` + the Odoo Discuss alert (S2.4) until it's built.

| event_type | Reported by | Consumed by | Wired in Dispatcher? |
|---|---|---|---|
| `lead.captured` | 1.3 | *(nothing subscribes yet — logged for traceability)* | No — informational, harmless |
| `lead.qualified` | 1.4, 1.5 | 2.1 Outreach | **Yes** |
| `lead.booked` | 1.5 | 2.4 Proposal Generation | **Yes** |
| `proposal.ready` | 1.5 | 2.5 Contract E-sign | **Yes** |
| `proposal.sent` | 2.4 (built, predecessor session) | *(nothing subscribes yet — informational)* | No — falls to flagged_events, harmless |
| `client.won` | 1.5 | ~~2.7 Onboarding~~ **none, as of this batch** | **No — deliberately un-wired this batch, see note below** |
| `lead.replied` | 2.1 | — | No — no consumer built yet |
| `contract.signed` | 2.5 | 2.6 Invoice Payment | **Yes** |
| `payment.received` | 2.6 | 2.7 Onboarding | **Yes** |
| `client.onboarded` | 2.7 | — (hook for future Phase 6 work) | No — no consumer built yet |
| `renewal.due` | 2.9 | 6.x churn/win-back | No — no consumer built yet |
| `renewal.overdue` | 2.9 | 6.5 Churn Win-back | No — no consumer built yet |
| `payment.failed` | 2.9 | — | No — no consumer built yet |
| `health.scored` | 6.1.1 (built, predecessor session) | 6.2.2, 6.4.1 | No — consumer modules exist as workflows but branch not wired yet |
| `qualification.written` | 5.1.2 (**built, this batch**) | — | No — informational, no consumer built yet |
| `nps.promoter_flagged` | 6.6 (**built, this batch**) | 6.7 Case Studies, 6.8 Referral Program | No — consumer modules exist as workflows but branch not wired yet |
| `list_segment.refreshed` | 7.2 (**built, this batch — new event type, not in original S0.2 minimum set**) | *(nothing subscribes yet — informational, aggregate-level)* | No — informational, harmless |
| `deliverability.alert` | 7.1 | — | No — no consumer built yet |
| `advocate.flagged` | 6.9 | — | No — no consumer built yet |
| `winback.escalated` | 6.5 | — | No — no consumer built yet |

## Note on `lead.captured`

The plan's S0.2 minimum set didn't include this one, but S3.1 explicitly asks
1.3 to report `event_type: lead.captured` after `Insert into clients_master`.
It's wired into 1.3 and lands in `funnel_events` for traceability, but since
nothing currently needs to *react* to a raw capture, it isn't given a
Dispatcher branch yet — expected, not a bug.

## Note on `list_segment.refreshed` (new, this batch)

7.2 (List Auto-Refresh) is a **bulk, all-rows-at-once cron job** — it has no
single client/lead in scope, so it can't follow the usual `client_id` /
`odoo_lead_id` shape every other Report to Hub node uses. Its Report to Hub
call sends `client_id: null` and `odoo_lead_id: null` explicitly (Hub-Intake
already handles this via `client_id ?? null`, see S1.1's notes) with an
aggregate `payload.segment_counts` (per-segment row counts from the daily
refresh). Treat this the same as `lead.captured`: informational only, no
consumer expected, safe to leave un-wired in Dispatcher indefinitely unless
something concrete needs to react to segment-refresh completion.

## Note on `client.won` — Dispatcher branch removed, this batch

Dispatcher used to route `client.won` straight to 2.7 Onboarding (a leftover
from S2, built before 2.6/2.7 existed, when "Won" was assumed to mean
"start onboarding immediately"). Now that billing (2.6) sits between Won and
Onboarded, the real flow is **Won → Invoiced → Paid → Onboarded**, so
onboarding should only fire on `payment.received` — which already has its
own wired branch. The `client.won → 2.7` rule and its Execute Workflow node
have been **removed** from Hub-Dispatcher (Option A from
`hub-dispatcher/README-S4b-DISPATCHER-UPDATE.md`, now marked resolved there).

**1.5 still reports `client.won`** — that part is untouched, it's a real
business event worth logging. It now simply falls through to
`flagged_events` like any other unwired event, same as `client.onboarded`
etc. If a future module wants to react to "deal won" specifically (distinct
from "payment received"), wire a new branch then.

## Note on `contract.signed`

2.5 Contract E-Sign reports `contract.signed` to the Hub instead of calling
2.6 directly. Dispatcher's `contract.signed` branch is **now wired** to
2.6 Invoice + Payment.

## Note on `proposal.sent` vs `proposal.ready`

These are two different signals, easy to conflate:
- `proposal.ready` (from 1.5) means "this lead is ready for a proposal to be
  generated" → triggers 2.4.
- `proposal.sent` (from 2.4) means "a proposal was actually emailed to the
  lead" → currently informational only, no consumer needs to react to it yet.

No Dispatcher branch was added for `proposal.sent` — there's nothing to
route it to.

## Status

This is the post-S4-gap-fill snapshot (5.1.2, 6.6, 7.2 star-migrated;
Hub-Dispatcher's `client.won → 2.7` open decision resolved). Every module
across phases 0, 1, 2, 4, 5, 6, 7 that exists as a built n8n workflow now
reports through the Hub where applicable. Remaining un-wired event types
above all share the same reason: **the downstream consumer module isn't
built yet**, not a wiring oversight — update this table the moment that
changes.

**Still open after this batch:**
- Phase 6 consumer wiring: `health.scored` → 6.2.2/6.4.1 and
  `nps.promoter_flagged` → 6.7/6.8 both need Dispatcher Switch branches once
  someone confirms those consumer workflows are ready to receive live
  traffic (they exist as files, wiring them into Dispatcher is a separate,
  deliberate step — don't wire silently as a side effect of a taxonomy
  update).
- S7a.1 grep audit (spoke→spoke direct links check) — not yet done.
- Merged reference file (`growth-engine-FULL-FUNNEL-merged.json`) — stale as
  of this batch, needs regenerating from the final tree before it's used for
  anything (Metabase dashboard, docs, etc).
