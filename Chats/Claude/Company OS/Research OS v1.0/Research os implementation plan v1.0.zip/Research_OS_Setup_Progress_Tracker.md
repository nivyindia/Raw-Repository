# Research OS — Setup Progress Tracker

**Use:** `Research_OS_Setup_Implementation_Plan.md` ke Phase 1–5 ko is table se track karo. Har task complete hote hi status update karo.

---

## Overall Status

| Field | Value |
|---|---|
| Setup Started On | |
| Current Phase | Phase 1 / 2 / 3 / 4 / 5 |
| Overall Status | 🟢 On Track / 🟡 In Progress / 🔴 Blocked |

---

## Phase 1 — Claude Skill Setup

| # | Task | Status | Notes / Blocker |
|---|---|---|---|
| 1.1 | Skills feature access confirm | ⬜ | |
| 1.2 | `research-os-skill` folder ready (`SKILL.md`) | ⬜ | |
| 1.3 | Skill uploaded to Claude.ai | ⬜ | |
| 1.4 | Trigger test kiya (random topic bola, skill auto-triggered) | ⬜ | |
| 1.5 | Name/description confirm | ⬜ | |

**Phase 1 Status:** ⬜ Not Started / 🟡 In Progress / ✅ Done

---

## Phase 2 — ChatGPT Custom GPT Setup

| # | Task | Status | Notes / Blocker |
|---|---|---|---|
| 2.1 | Custom GPT create shuru kiya | ⬜ | |
| 2.2 | Naam diya ("Research OS") | ⬜ | |
| 2.3 | Instructions paste ki | ⬜ | |
| 2.4 | Web Browsing ON kiya | ⬜ | |
| 2.5 | Conversation starters add kiye | ⬜ | |
| 2.6 | Save/Publish kiya | ⬜ | |
| 2.7 | Test query se verify kiya | ⬜ | |

**Phase 2 Status:** ⬜ Not Started / 🟡 In Progress / ✅ Done

---

## Phase 3 — Perplexity Space Setup

| # | Task | Status | Notes / Blocker |
|---|---|---|---|
| 3.1 | Space create kiya | ⬜ | |
| 3.2 | Naam diya ("Research OS") | ⬜ | |
| 3.3 | Custom Instructions paste ki | ⬜ | |
| 3.4 | Focus/Model set kiya | ⬜ | |
| 3.5 | Test query se format verify kiya | ⬜ | |

**Phase 3 Status:** ⬜ Not Started / 🟡 In Progress / ✅ Done

---

## Phase 4 — End-to-End Test Run

| # | Task | Status | Notes / Blocker |
|---|---|---|---|
| 4.1 | Test topic choose kiya | ⬜ | *(topic likho yahan: __________)* |
| 4.2 | Claude: Steps 0–3 complete | ⬜ | |
| 4.3 | Perplexity: Step 3 queries run kiye | ⬜ | |
| 4.4 | Claude: Steps 5–8 complete | ⬜ | |
| 4.5 | Claude: Steps 9–12 complete | ⬜ | |
| 4.6 | Gaps/confusions note kiye | ⬜ | *(list yahan)* |
| 4.7 | Fixes apply kiye respective files mein | ⬜ | |

**Phase 4 Status:** ⬜ Not Started / 🟡 In Progress / ✅ Done

---

## Phase 5 — v1.1 Audit Layer Merge (Optional)

| # | Task | Status | Notes / Blocker |
|---|---|---|---|
| 5.1 | Steps 10A–10E `SKILL.md` mein add kiye | ⬜ | |
| 5.2 | Same steps ChatGPT GPT instructions mein add kiye | ⬜ | |
| 5.3 | Perplexity confirm kiya untouched hai | ⬜ | |

**Phase 5 Status:** ⬜ Not Started / 🟡 In Progress / ✅ Done / ⬜ Skipped (not needed abhi)

---

## Final Readiness Checklist

- [ ] Claude Skill live aur trigger karti hai
- [ ] ChatGPT Custom GPT/Project live aur Instructions follow karta hai
- [ ] Perplexity Space live aur sahi format mein reply deta hai
- [ ] Ek end-to-end test topic successfully 12 steps se guzra
- [ ] Teeno files (`SKILL.md`, ChatGPT instructions, Perplexity instructions) mutually consistent hain (koi drift nahi)

**Jab sab check ho jaye → Research OS production-ready hai, kisi bhi naye topic pe seedha use karo.**
