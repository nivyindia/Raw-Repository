# Lead Scraping – Step-by-Step Workflow

<aside>
💡

[End-to-End Data Scraping Process Guide](End-to-End%20Data%20Scraping%20Process%20Guide%202f5b3416c76d80dcaa36dd3974904fbb.md)

[Scraping Tools & Courses – Master Reference List](Scraping%20Tools%20&%20Courses%20%E2%80%93%20Master%20Reference%20List%202f5b3416c76d8083b9c1c34b6690e360.md)

</aside>

how the tools work together step by step for a novice.

---

```
[Step 1: Find Companies / Leads]
        |
        | Tools: LinkedIn Sales Navigator, Google Maps, Job Portals
        V
[Step 2: Scrape Raw Data]
        |
        | Tools: PhantomBuster, TexAu, Apify, Octoparse
        | Extract: Company names, websites, LinkedIn profiles, emails
        V
[Step 3: Clean & Enrich Data]
        |
        | Tools: Clay, Apollo.io, Snov.io, RocketReach
        | Action: Fill missing emails/phones, remove duplicates, enrich job titles
        V
[Step 4: Verify Emails]
        |
        | Tools: ZeroBounce, NeverBounce, Snov Verifier
        | Action: Remove invalid emails
        V
[Step 5: Store & Automate]
        |
        | Tools: Google Sheets, Notion, Zapier, n8n
        | Action: Organize data, automate workflows
        V
[Step 6: Outreach / Contact Leads]
        |
        | Tools: Email (Snov.io, Hunter.io), LinkedIn Automation (Waalaxy, Linked Helper)
        | Action: Send emails / LinkedIn messages to leads
        V
[Result: Verified, enriched leads ready for outreach]

```

---

Absolutely! Let me give you a **simple, step-by-step workflow** for how all these tools can work together for a **novice to scrape and enrich B2B leads**. I’ll keep it **short and easy to understand**:

---

## **Step‑by‑Step Lead Scraping Workflow (Novice-Friendly)**

### **Step 1 — Find Companies / Job Leads**

- **Tools:** LinkedIn Sales Navigator, Google Maps, Job Portals (Naukri, Indeed)
- **What you do:** Search for target companies or job postings to find hiring companies or decision-makers.

---

### **Step 2 — Scrape Raw Data**

- **Tools:** PhantomBuster, TexAu, Apify, Octoparse
- **What you do:** Extract company names, website links, LinkedIn profiles, emails (if visible).
- **Example:** Use PhantomBuster to scrape LinkedIn profiles from Sales Navigator results.

---

### **Step 3 — Clean & Enrich Data**

- **Tools:** Clay, Apollo.io, Snov.io, RocketReach
- **What you do:**
    - Fill missing emails, phone numbers, or job titles.
    - Remove duplicates and verify emails.
- **Example:** Upload your scraped list to Clay → auto-enrich contacts → export clean CSV.

---

### **Step 4 — Verify Emails**

- **Tools:** ZeroBounce, NeverBounce, Snov Verifier
- **What you do:** Make sure all emails are valid to prevent bounce-backs.

---

### **Step 5 — Store & Automate**

- **Tools:** Google Sheets, Notion, Zapier, n8n
- **What you do:**
    - Keep your lead list organized.
    - Automate follow-ups or send data to your CRM.

---

### **Step 6 — Outreach (Optional but Recommended)**

- **Tools:** Email (Snov.io, Hunter.io), LinkedIn Automation (Waalaxy, Linked Helper)
- **What you do:** Contact leads via email or LinkedIn messages for sales or services.

---

### **💡 Summary — Simple Flow**

1. **Search** → Sales Navigator / Maps / Job Portals
2. **Scrape** → PhantomBuster / TexAu / Apify
3. **Enrich** → Clay / Apollo / Snov
4. **Verify** → ZeroBounce / Snov Verifier
5. **Store & Automate** → Sheets / Notion / Zapier
6. **Reach Out** → Email / LinkedIn

---

✅ **Tip for a novice:** Think of it like a **pipeline**:

- **Find → Collect → Clean → Verify → Store → Contact**

All tools just make **each step faster and smarter**.

---

If you want, I can **draw a very simple diagram** showing all tools in this pipeline, so it’s super easy to visualize for beginners. Do you want me to do that?

✅ **Quick takeaway:**

- Each step **feeds the next**.
- Tools like PhantomBuster, TexAu, Apify → **collect raw data**.
- Clay, Apollo, Snov → **clean & enrich**.
- ZeroBounce → **verify emails**.
- Sheets/Notion/Zapier → **organize & automate**.
- Waalaxy / Email → **contact leads**.

---

If you want, I can make a **super-condensed one-line “arrow flow”** version too, so you can memorize the whole pipeline in **10 seconds**. Do you want me to do that?

Here’s a **practical, actionable guide** on how you can **combine Apollo, Sales Navigator, Prospeo, Clay, and ZoomInfo with Apify** to scrape leads in bulk — **at low cost or free where possible**.

---

## 🔎 What Each Tool Does (Quick Context)

| Tool | Primary Function |
| --- | --- |
| **Apollo** | Lead database + email & phone data |
| **Sales Navigator (LinkedIn)** | Advanced LinkedIn prospecting |
| **Prospeo** | Lead enrichment & B2B search |
| **Clay** | Data aggregation + workflow automation |
| **ZoomInfo** | Enterprise-grade B2B database |
| **Apify** | Web scraping & automation platform |

---

## 🛠️ Strategy: How to Use These Together

The goal is to *scrape and enrich B2B leads at scale without paying high subscription costs* by blending APIs, scraping, and automation.

---

## ✅ 1. Use **Apify** as the Core Scraping Engine

Apify lets you run scrapers (actors) on websites that **don’t have an API** or where APIs are expensive.

✔️ Best for:

- LinkedIn Search Results
- Google Maps Business Listings
- Company websites
- Job boards with employee data
- Public directories

---

## ✅ 2. Combine with Lead Sources

### 🧠 A. LinkedIn (Sales Navigator) + Apify

Sales Navigator gives filtered lists — but doesn’t export easily.

**Workflow:**

1. Use Sales Navigator to build **targeted lists** (role, industry, company size, location).
2. Run an Apify **LinkedIn search scraper**:
    - Scrapes names, titles, companies, URLs
    - Can extract *profile URLs*
3. Save scraped data to CSV / database.

➡️ Advantage: Bypasses manual copy-paste and saves time.

⚠️ Legal & Terms: LinkedIn restricts automation — use proxies / throttle speed.

---

### 🧠 B. Apollo / ZoomInfo / Prospeo Data Enrichment

These tools have richer email/phone data but cost $$.

**How to reduce cost:**

- Use free credits initially
- Run enrichment in small batches
- Only enrich priority leads

**Workflow with Apify:**

1. Scrape raw leads via LinkedIn or Google
2. Upload the scraped list to:
    - **Apollo API**
    - **ZoomInfo API**
    - **Prospeo API**
3. Fetch emails, phone numbers, company info
4. Store in your CRM

📌 You can automate this with Apify + API calls.

---

## ✅ 3. Make It Cheaper or Free

### 🪄 A. Free & Low-Cost Scraping with Apify

- Use **free Apify credits**
- Reuse existing actors
- Schedule scraping for off-peak to save cost

👉 You might not need premium API calls if your scrape covers most fields you need.

---

### 🪄 B. Use Clay for Automation

Clay can orchestrate workflows across tools without heavy coding:

🚀 Example Flow:

1. Trigger: New row in Google Sheet
2. Action: Scrape LinkedIn with Apify
3. Action: Enrich with Apollo API
4. Output: Save back to Sheet / CRM

No need to pay for expensive developer time.

---

## 🧩 Example End-to-End Workflow

### Step 1 — Define Your Target

- Use Sales Navigator filters:
    - Country
    - Industry
    - Position (CEO / Founder / Head of Marketing)

### Step 2 — Scrape with Apify

- Run LinkedIn search scraper
- Export raw leads

### Step 3 — Enrich with APIs

- Use Apollo API (cheapest credits per email)
- If needed, use Prospeo/ZoomInfo

### Step 4 — Deduplicate & Clean

- Use Google Sheets / Notion / Airtable
- Remove duplicates

### Step 5 — Export to CRM & Outreach

- Import into:
    - HubSpot
    - Zoho
    - Lemlist / Mailshake

---

## 🧪 Cheap / Free Tips

| Technique | Save Cost |
| --- | --- |
| Scrape publicly | ✔️ (Apify) |
| Only enrich selected leads | ✔️ |
| Schedule scrapers weekly | ✔️ |
| Use free API credits first | ✔️ |
| Use proxies instead of IP rotation | ✔️ cheaper |

---

## 🧠 Technical Implementation Ideas

### 🧩 Apify + LinkedIn Search Scraper

Use ready-made Apify actors like:

- LinkedIn Search Results Scraper
- LinkedIn Company Employees Scraper

You can run them via:

```jsx
await Apify.call('apify/linkedin-search-scraper', {
  searchQuery: 'Marketing Directors in India',
  maxItems: 1000
});

```

### 🧩 Enrichment API Example (Apollo)

```jsx
const axios = require('axios');

const response = await axios.post('https://api.apollo.io/v1/contacts/enrich', {
  api_key: 'YOUR_API_KEY',
  email: 'lead@example.com'
});

```

You can run this inside an Apify actor.

---

## ⚠️ Legal & Best Practices

❌ Avoid scraping personal email from LinkedIn without permission

✔️ Enrich business emails via APIs

✔️ Use Terms-of-Service compliant actors where possible

✔️ Respect robots.txt

---

## 📌 Summary

| Step | Who Scrapes | Who Enriches |
| --- | --- | --- |
| Bulk leads | **Apify** | — |
| Add contact data | — | **Apollo / Prospeo / ZoomInfo** |
| Workflow automation | **Clay** | **Clay** |

---

If you want, I can **generate the exact code** (Node/Python) for these workflows — just tell me which tools you want to prioritize! 🚀

Absolutely — I found **relevant tutorial videos from the internet** that will help you perform *each major step* of the workflow you asked about (lead gen with Apollo, Sales Navigator, Apify, n8n/Make automation, etc.). These videos will guide you visually and step-by-step.

---

## 📹 1. **Learn Web Scraping & Automation with Apify**

[How to EASILY Scrape LinkedIn Profiles & Posts (Apify tutorial)](https://www.youtube.com/watch?v=ZDoea8guN3E&utm_source=chatgpt.com)

This teaches you how to scrape LinkedIn data — great for building your raw leads list using Apify actors. ([YouTube](https://www.youtube.com/watch?v=ZDoea8guN3E&utm_source=chatgpt.com))

[Apify FULL GUIDE 2025 — Scrape Anything (Beginner)](https://www.youtube.com/watch?v=KQIo1gNFAeM&utm_source=chatgpt.com)

A complete beginner guide to using Apify for scraping *any* public web data — useful foundation before connecting with workflows like n8n/Make. ([YouTube](https://www.youtube.com/watch?v=KQIo1gNFAeM&utm_source=chatgpt.com))

[Apify Basics: How To Scrape Anything In Minutes (No Code)](https://www.youtube.com/watch?v=pKgup8tsPv8&utm_source=chatgpt.com)

Step-by-step tool setup (no code). Excellent if you’re non-technical. ([YouTube](https://www.youtube.com/watch?v=pKgup8tsPv8&utm_source=chatgpt.com))

---

## 📹 2. **LinkedIn Sales Navigator & Apollo Lead Generation**

[UPDATED 2025: LinkedIn Sales Navigator Lead Gen with AI & Apollo](https://www.youtube.com/watch?v=HL8AeTPufLU&utm_source=chatgpt.com)

Shows how to use Sales Navigator + Apollo — perfect for building your target lead lists before scraping/enrichment. ([YouTube](https://www.youtube.com/watch?v=HL8AeTPufLU&utm_source=chatgpt.com))

[How To Use Apollo.io and LinkedIn Sales Navigator To Build Leads](https://www.youtube.com/watch?v=VXChXeJuEhI&utm_source=chatgpt.com)

Walks through Apollo + LinkedIn workflow to find and capture leads. ([YouTube](https://www.youtube.com/watch?v=VXChXeJuEhI&utm_source=chatgpt.com))

[Apollo.io Lead Generation Tutorial For Beginners (2026)](https://www.youtube.com/watch?v=nXc13tFrMUY&utm_source=chatgpt.com)

A broader overview of Apollo — good for mastering filters and exporting lead lists. ([YouTube](https://www.youtube.com/watch?v=nXc13tFrMUY&utm_source=chatgpt.com))

---

## 📹 3. **Automation: Apify + n8n / Connected Workflows**

[Scrape Anything with Apify & n8n (Step‑by‑Step Guide)](https://www.youtube.com/watch?v=4OhrZFQ2ZQE&utm_source=chatgpt.com)

This ties together Apify and n8n (similar to how you’ll chain scrapers and lead enrichment workflows). ([YouTube](https://www.youtube.com/watch?v=4OhrZFQ2ZQE&utm_source=chatgpt.com))

*(Note: there’s also tutorials online covering Make.com + Apify automations — one popular topic is “How to scrape LinkedIn emails automatically with Apify & Make” which can be found as videos similar to this type.)* ([YouTube](https://www.youtube.com/watch?v=IoRR7SPs5Z0&utm_source=chatgpt.com))

---

## 📹 4. **Sales Navigator Practice & Outreach**

[LinkedIn Sales Navigator Tutorial (Updated for 2026)](https://www.youtube.com/watch?v=Z0b3OUlERJA&utm_source=chatgpt.com)

Shows exactly how to build and manage lead lists inside Navigator — essential before exporting into Apollo/Clay. ([YouTube](https://www.youtube.com/watch?v=Z0b3OUlERJA&utm_source=chatgpt.com))

---

## 🎥 Optional Playlists & Collections

🎞️ **LinkedIn Scraper Playlist (multiple videos)** — search for the hashtag “LinkedInScraper” on YouTube to find a playlist of various scraper tutorials and techniques. ([YouTube](https://www.youtube.com/hashtag/linkedinscraper?utm_source=chatgpt.com))

---

### 📌 Additional Notes

- Many tutorials also include **email scraping / enrichment** steps with Make.com or n8n automations (meaning you don’t always have to code). ([LinkedIn](https://www.linkedin.com/posts/sudarsanahazarika_automation-linkedin-profile-scraping-collecting-activity-7379184962966663168-Orjl?utm_source=chatgpt.com))
- Community posts also list tutorials for scraping into Google Sheets — which is great if you use Sheets to manage leads before pushing into tools like Clay or CRM. ([LinkedIn](https://www.linkedin.com/posts/sudarsanahazarika_automation-linkedin-profile-scraping-collecting-activity-7379184962966663168-Orjl?utm_source=chatgpt.com))

---

If you’d like, I can also assemble a **step-by-step playlist order** (exact links in sequence) that corresponds to each numbered step of your workflow plan (Sales Navigator list → Scraping → Enrichment → Automation → CRM integration). Just let me know! 🎯

Here’s a **search criteria framework** you can use in **Apollo (Apollo.io)** to find **companies in the UAE that do SPC flooring** and also capture **decision-makers’ contact data** (titles, emails, phone numbers, etc.).

---

## ✅ **1. Company Search Filters**

### **Location**

- **Country:** United Arab Emirates
- You can also choose by emirate if needed (e.g., Dubai, Abu Dhabi).

### **Industry / Keyword**

Since SPC flooring companies may not have a standard industry tag, combine relevant keywords:

```
“SPC flooring”
“Stone Plastic Composite flooring”
“Rigid Core Flooring”
“Luxury Vinyl Flooring”
“Flooring solutions”
“Vinyl flooring”
“Flooring contractors”
“Flooring manufacturers”
“Interior flooring”
“Flooring suppliers”

```

Use **keyword search** across:

- Company name
- Company description
- Products & services

**Suggested company keyword boolean:**

```
SPC OR “Stone Plastic Composite” OR “Rigid Core” OR “Luxury Vinyl” OR “Vinyl flooring”

```

### **Company Size (optional)**

Depending on your focus:

- Small & Medium (10–200)
- Mid Market (200–2,000)
- Enterprise (>2,000)

### **Revenue (optional)**

- Useful if you want firms with larger budgets

### **Headquarters**

- Filter to only show **UAE-based companies**

---

## ✅ **2. Person / Decision-Maker Filters**

Once you have the target companies, refine your **people search**:

### **Job Titles / Functions**

Search within those companies for decision-makers relevant to purchasing, operations, or partnerships:

**Title filters (Boolean if allowed):**

```
CEO OR “Managing Director” OR “General Manager” OR “Head of Procurement” OR “Procurement Manager” OR “Operations Manager” OR “Business Development Manager” OR “Sales Director” OR “Director of Operations” OR “Purchasing Director”

```

### **Role / Seniority**

- **Executive**
- **Director**
- **Manager**
- **Owner / Founder**

### **Departments**

- Procurement
- Operations
- Sales
- Business Development
- Purchasing

---

## ✅ **3. Contact Data Options**

Depending on your Apollo subscription:

✔ Email addresses

✔ Phone numbers

✔ LinkedIn profiles

✔ Social handles

✔ Employment history

Make sure your output includes:

- **Email**
- **Direct phone**
- **LinkedIn URL**
- **Title**
- **Company name**
- **HQ location**

---

## ✅ **4. Search Output / Segmentation**

Exportable fields you want:

| Field | Why |
| --- | --- |
| Company Name | Primary target |
| Website | Verification |
| Industry | Relevance |
| Revenue | Qualification |
| Employee Count | Qualification |
| Contact Name | DM |
| Title | Role relevance |
| Email | Outreach |
| Work Phone | Outreach |
| LinkedIn | Alternate nurture |
| Location | UAE |

---

## ✅ **5. Example Boolean You Could Use**

### **Company Keyword Boolean**

```
SPC OR “Stone Plastic Composite” OR “Rigid Core Flooring” OR “Luxury Vinyl Flooring” OR “Vinyl Flooring” OR Flooring

```

### **Person Title Boolean**

```
(CEO OR “Managing Director” OR “General Manager” OR “Head of Procurement” OR “Procurement Manager” OR “Operations Manager” OR “Business Development Manager” OR “Sales Director”)

```

---

## ✅ **6. Optional Refinements for Better Quality**

### **Exclude irrelevant terms**

Add negative keywords if space/wood flooring companies pollute results:

```
NOT hardwood NOT carpet

```

### **Filter by intent / technographics**

If Apollo allows product tags, include:

```
“Flooring Products”

```

---

## 📌 **Putting It Together: Typical Apollo Workflow**

1. **Company search**
    - Location: UAE
    - Keywords: flooring + SPC-related terms
2. **Save list of companies**
3. **People search within selected companies**
    - Titles: procurement / operations / executive
4. **Export contacts**

---

If you want, I can also **draft a ready-to-paste Apollo query string** with tested syntax for your subscription level. Just tell me whether you’re on the **Basic, Advanced, or Custom Boolean plan**.

This is a **very common growth-stack question**, and there *is* a smart way to do this **without burning money or violating ToS**—but it requires **tool stacking, limits management, and workflow discipline**, not brute-force scraping.

I’ll break this into **clear, practical layers** so you can actually implement it.

---

## ⚠️ First — Important Reality Check (Short & Honest)

- **Blind “scraping” LinkedIn / Apollo / ZoomInfo at scale = accounts banned**
- The sustainable approach is **data enrichment + extraction + verification**, not raw scraping
- Goal: **80–90% of paid value using free tiers + low-cost tools**

What follows is a **legit, low-cost, scalable system** used by agencies and SDR teams.

---

# 🧠 CORE STRATEGY: “SOURCE → ENRICH → VERIFY → SCALE”

Instead of paying **one expensive tool**, you:

1. Use **free / cheap tools for raw data**
2. Enrich emails gradually
3. Verify aggressively
4. Rotate sources

---

# 🔹 LAYER 1: COMPANY & PERSON DISCOVERY (FREE / LOW COST)

### ✅ Best Tools (Discovery)

| Purpose | Tool | Cost Strategy |
| --- | --- | --- |
| Company discovery | **Apollo (Free)** | 25 exports/month |
| Decision-makers | **LinkedIn + Sales Nav Trial** | 30-day trial |
| Bulk LinkedIn extraction | **Instant Data Scraper / Panda Extract** | Free |
| Web scraping | **Apify (free actors)** | Free credits |

### 🔁 How to Use

- Use **Apollo free** → find companies only (not contacts)
- Use **LinkedIn filters** → manually load people
- Extract visible data with:
    - Instant Data Scraper
    - Panda Extract
- Capture:
    - Name
    - Title
    - Company
    - LinkedIn URL

👉 At this stage, **NO emails yet** (this avoids bans)

---

# 🔹 LAYER 2: EMAIL & PHONE ENRICHMENT (STACK FREE TIERS)

### ✅ Email Finders (Rotate them)

| Tool | Free Limit |
| --- | --- |
| **Hunter** | 25/month |
| **SalesQL** | 50/month |
| **ContactOut** | Limited daily |
| **Lusha** | 5–10/month |
| **Kendo** | Trial credits |
| **ListGenie** | Freemium |

### 🧠 Pro Tip

- Don’t use one tool for all leads
- **Rotate tools per batch (20–50 leads)**
- This keeps you under radar and maximizes free credits

---

# 🔹 LAYER 3: BULK EMAIL VERIFICATION (CRITICAL)

Never send unverified emails.

### ✅ Cheapest & Reliable Stack

| Tool | Why |
| --- | --- |
| **NeverBounce** | High accuracy |
| **Reoon** | Cheap bulk |
| **Debounce** | Good backup |
| **Million Verifier** | Pay-as-you-go |

### 🔁 Verification Rule

- Run **double verification** for cold outreach lists
- Keep only:
    - Valid
    - Accept-All (optional, warmed domains only)

---

# 🔹 LAYER 4: AUTOMATION WITHOUT EXPENSIVE CLAY

Clay is powerful but expensive.

### 🔁 Clay Alternatives (Cheap / Free)

| Purpose | Tool |
| --- | --- |
| Workflow automation | Google Sheets |
| API enrichment | Apify |
| LinkedIn to Sheet | Phantombuster (trial) |
| Email enrichment | Hunter API |
| Deduplication | Sheets + formulas |

**Basic stack:**

- Google Sheets
- Apps Script
- Apify actors

---

# 🔹 LAYER 5: SAFE BULK SCRAPING RULES (VERY IMPORTANT)

### ❌ What NOT to Do

- No headless LinkedIn scraping
- No logged-in automation without delay
- No >100 profiles/day/account

### ✅ What Works Safely

- 20–40 profiles/day/account
- 5–10 sec delays
- Multiple accounts (if applicable)
- Use **manual scrolling + extractors**

---

# 🔹 EXAMPLE LOW-COST BULK WORKFLOW (REALISTIC)

### 🎯 Target: 1,000 UAE Flooring Decision Makers

**Week 1**

- Apollo free → 200 companies
- LinkedIn → filter DMs
- Extract 300 profiles manually

**Week 2**

- Rotate email tools → enrich 150–200 emails
- Verify → keep ~120–150 valid

**Week 3**

- Repeat with new filters
- Different titles / emirates

💰 **Total cost:** ₹2,000–₹5,000 max

💸 **Compared to:** ₹40,000–₹1L subscriptions

---

# 🔹 OPTIONAL: WHEN TO PAY (SMARTLY)

Pay **only when ROI is proven**:

- Apollo (when exporting contacts)
- Sales Nav (for scale)
- Clay (when doing 10k+/month)

---

## 🚀 FINAL TAKEAWAY

You **don’t need all tools**

You need:

- 2 discovery tools
- 3 enrichment tools
- 2 verification tools
- 1 sheet

That’s it.

---

If you want, I can:

1. **Design a step-by-step SOP** for your team
2. **Create a Google Sheet automation template**
3. **Recommend the exact cheapest paid combo for your scale**

Just tell me:

👉 *Monthly lead target?*

👉 *Cold email or WhatsApp or LinkedIn outreach?*

Got it. I’ll explain this **from zero**, assuming you’re a **complete fresher**, with **no jargon**, and step-by-step. Think of this as a **foundation lesson** on lead generation & data extraction using tools like Apollo, LinkedIn, Sales Navigator, etc.

---

# 🧠 PART 1: WHAT IS THIS “WHOLE THING”?

### What you are trying to do

You want to:

- Find **companies** (example: SPC flooring companies in UAE)
- Find the **right people** inside those companies (decision makers)
- Get their **contact details** (email / phone)
- Do this **without paying huge subscription fees**

This process is called:

👉 **B2B Lead Generation**

---

# 🧱 PART 2: BASIC TERMS (VERY IMPORTANT)

### 1️⃣ Lead

A **lead** = one person you may contact

Example:

> Ahmed Khan – Procurement Manager – ABC Flooring – Dubai – Email
> 

### 2️⃣ Prospect

A **qualified lead** (right company + right role)

### 3️⃣ Decision Maker

Someone who can:

- Buy
- Approve
- Influence decisions
    
    Examples:
    
- CEO
- Managing Director
- Procurement Manager
- Operations Head

---

# 🧰 PART 3: WHAT EACH TOOL ACTUALLY DOES (IN SIMPLE WORDS)

### 🔹 LinkedIn

- A **social network for professionals**
- Shows:
    - Name
    - Job title
    - Company
- ❌ Does NOT show emails or phone numbers (mostly)

### 🔹 Sales Navigator (LinkedIn Premium)

- Advanced LinkedIn
- Better filters:
    - Company size
    - Industry
    - Geography
    - Job role
- Trial is **one-time only**
- Still ❌ doesn’t give emails

👉 Purpose: **Find the right people**

---

### 🔹 Apollo

- A **B2B database**
- Has:
    - Company info
    - People info
    - Emails & phone numbers (limited on free plan)

👉 Purpose:

- Find companies
- Sometimes get emails

---

### 🔹 ZoomInfo

- Very expensive
- Very big database
- Mostly used by large companies

👉 You **don’t need this as a fresher**

---

### 🔹 Email Finder Tools (Hunter, Lusha, SalesQL, etc.)

These tools:

- Take **name + company**
- Guess or find **work email**

Example:

> Ahmed Khan + abcgroup.ae → ahmed.khan@abcgroup.ae
> 

---

### 🔹 Email Verification Tools

They **check if an email actually exists**

- Prevents email bounce
- Protects your domain

---

# 🧩 PART 4: THE CORRECT ORDER (MOST IMPORTANT)

❌ Freshers’ mistake:

> Try to scrape everything at once
> 

✅ Correct flow:

```
Company → Person → Email → Verification

```

---

# 🔄 PART 5: STEP-BY-STEP PROCESS (BEGINNER FRIENDLY)

## STEP 1: FIND COMPANIES (FREE)

Use **Apollo Free**:

- Country: UAE
- Keyword: Flooring / SPC / Vinyl
- Export company names only

👉 Output:

- Company name
- Website
- Location

---

## STEP 2: FIND PEOPLE INSIDE COMPANIES

Use **LinkedIn (Free)**:

- Search company name
- Click “People”
- Filter job titles:
    - CEO
    - Manager
    - Procurement
    - Operations

👉 Copy:

- Name
- Title
- Company
- LinkedIn URL

Use **Instant Data Scraper / Panda Extract**

(no login automation, just browser scraping)

---

## STEP 3: FIND EMAILS (ROTATE TOOLS)

Now you have:

```
Name + Company

```

Use email tools one by one:

- Hunter (25 free/month)
- SalesQL
- ContactOut
- Lusha

👉 Don’t use all leads in one tool

👉 Use 20–30 leads per tool

---

## STEP 4: VERIFY EMAILS (MANDATORY)

Before contacting anyone:

- Upload emails to:
    - NeverBounce
    - Reoon
    - Debounce

Keep only:

- ✅ Valid
- ⚠️ Accept-All (optional)

Delete:

- ❌ Invalid
- ❌ Risky

---

## STEP 5: FINAL LEAD SHEET

Your final Google Sheet should have:

| Name | Title | Company | Email | Phone | LinkedIn | Location |
| --- | --- | --- | --- | --- | --- | --- |

Only this sheet is used for outreach.

---

# 🚨 PART 6: WHY WE DON’T “BULK SCRAPE”

### Why scraping is risky

- LinkedIn detects bots
- Accounts get:
    - Restricted
    - Banned
- Data quality becomes poor

### Safe limits

- 20–40 profiles/day
- Manual scrolling
- 5–10 sec gap

---

# 💸 PART 7: WHY WE AVOID BIG SUBSCRIPTIONS AT START

### As a fresher:

You don’t know:

- Conversion rate
- Response rate
- ICP accuracy

So spending ₹30k–₹1L is risky.

👉 First validate process with **free + cheap tools**

👉 Scale only after results

---

# 🧠 PART 8: SIMPLE MINDSET RULE

Think like this:

> “I’m building data, not stealing data”
> 

Quality > Quantity

---

# 🧩 PART 9: FREQUENT FRESHER QUESTIONS

### ❓ Can we use Sales Nav trial many times?

➡️ No. One-time only.

### ❓ Can we create multiple LinkedIn accounts?

➡️ Not recommended. High ban risk.

### ❓ Is this legal?

➡️ Yes, if:

- Public data
- Respect platform rules
- No harassment

---

# 🎯 FINAL SUMMARY (FOR A FRESHER)

You are learning **3 skills**:

1. Research
2. Data enrichment
3. Verification

Tools are **just helpers**.

---

If you want, next I can:

- Create a **beginner SOP PDF**
- Make a **Google Sheet template**
- Explain **cold email basics** from zero

Just tell me 👍