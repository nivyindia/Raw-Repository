# 💼 CEO Office

<aside>
💼

**What is this department?**

The CEO Office manages Nivy's strategic direction, founder priorities, investor relations, and cross-company initiatives.

**Who should use this:** CEO/Founder and senior leadership.

📝 **Owner:** CEO / Founder | 🌍 **Markets:** All

</aside>

---

## 📄 Key Pages

- **CEO Office Overview** — Strategic priorities and CEO operating framework
- **CEO Office Dashboard** — CEO's live dashboard: revenue, deals, team health
- **Executive Summary** — Company executive summary for partners and investors
- **Business Model Summary** — One-page business model reference

---

## 📊 CEO Weekly Focus

*Add weekly priorities here. Update every Monday.*

---

## 🔗 Quick Links

- 📋 Business Plan → Growth Strategy
- 💰 Finance & Accounting → Finance Dashboard
- 📚 Knowledge & Resources → Investor Pitch Decks

[💼 CEO Office](%F0%9F%92%BC%20CEO%20Office%2029bb3416c76d81a2bd87ee37a6de1201.md)